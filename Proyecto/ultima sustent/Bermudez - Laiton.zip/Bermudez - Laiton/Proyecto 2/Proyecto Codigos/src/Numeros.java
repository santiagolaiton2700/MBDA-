
public class Numeros {

	public static void main(String[] args) 
	{
		for (int  i = 1; i <=1000; i+=1) {
			String a = String.valueOf(i);
			String b = String.valueOf(i);
			String res = a+b;
			System.out.println(res);
		}
	}

}
