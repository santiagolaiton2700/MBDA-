/* Showing results for CONTROL.xlsx */

/* CREATE TABLE */
/* INSERT QUERY NO: 1 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1000
);

/* INSERT QUERY NO: 2 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1001
);

/* INSERT QUERY NO: 3 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1002
);

/* INSERT QUERY NO: 4 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1003
);

/* INSERT QUERY NO: 5 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1004
);

/* INSERT QUERY NO: 6 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1005
);

/* INSERT QUERY NO: 7 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1006
);

/* INSERT QUERY NO: 8 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1007
);

/* INSERT QUERY NO: 9 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1008
);

/* INSERT QUERY NO: 10 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1009
);

/* INSERT QUERY NO: 11 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1010
);

/* INSERT QUERY NO: 12 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1011
);

/* INSERT QUERY NO: 13 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1012
);

/* INSERT QUERY NO: 14 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1013
);

/* INSERT QUERY NO: 15 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1014
);

/* INSERT QUERY NO: 16 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1015
);

/* INSERT QUERY NO: 17 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1016
);

/* INSERT QUERY NO: 18 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1017
);

/* INSERT QUERY NO: 19 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1018
);

/* INSERT QUERY NO: 20 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1019
);

/* INSERT QUERY NO: 21 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1020
);

/* INSERT QUERY NO: 22 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1021
);

/* INSERT QUERY NO: 23 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1022
);

/* INSERT QUERY NO: 24 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1023
);

/* INSERT QUERY NO: 25 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1024
);

/* INSERT QUERY NO: 26 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1025
);

/* INSERT QUERY NO: 27 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1026
);

/* INSERT QUERY NO: 28 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1027
);

/* INSERT QUERY NO: 29 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1028
);

/* INSERT QUERY NO: 30 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1029
);

/* INSERT QUERY NO: 31 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1030
);

/* INSERT QUERY NO: 32 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1031
);

/* INSERT QUERY NO: 33 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1032
);

/* INSERT QUERY NO: 34 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1033
);

/* INSERT QUERY NO: 35 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1034
);

/* INSERT QUERY NO: 36 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1035
);

/* INSERT QUERY NO: 37 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1036
);

/* INSERT QUERY NO: 38 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1037
);

/* INSERT QUERY NO: 39 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1038
);

/* INSERT QUERY NO: 40 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1039
);

/* INSERT QUERY NO: 41 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1040
);

/* INSERT QUERY NO: 42 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1041
);

/* INSERT QUERY NO: 43 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1042
);

/* INSERT QUERY NO: 44 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1043
);

/* INSERT QUERY NO: 45 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1044
);

/* INSERT QUERY NO: 46 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1045
);

/* INSERT QUERY NO: 47 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1046
);

/* INSERT QUERY NO: 48 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1047
);

/* INSERT QUERY NO: 49 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1048
);

/* INSERT QUERY NO: 50 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1049
);

/* INSERT QUERY NO: 51 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1050
);

/* INSERT QUERY NO: 52 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1051
);

/* INSERT QUERY NO: 53 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1052
);

/* INSERT QUERY NO: 54 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1053
);

/* INSERT QUERY NO: 55 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1054
);

/* INSERT QUERY NO: 56 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1055
);

/* INSERT QUERY NO: 57 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1056
);

/* INSERT QUERY NO: 58 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1057
);

/* INSERT QUERY NO: 59 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1058
);

/* INSERT QUERY NO: 60 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1059
);

/* INSERT QUERY NO: 61 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1060
);

/* INSERT QUERY NO: 62 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1061
);

/* INSERT QUERY NO: 63 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1062
);

/* INSERT QUERY NO: 64 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1063
);

/* INSERT QUERY NO: 65 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1064
);

/* INSERT QUERY NO: 66 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1065
);

/* INSERT QUERY NO: 67 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1066
);

/* INSERT QUERY NO: 68 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1067
);

/* INSERT QUERY NO: 69 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1068
);

/* INSERT QUERY NO: 70 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1069
);

/* INSERT QUERY NO: 71 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1070
);

/* INSERT QUERY NO: 72 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1071
);

/* INSERT QUERY NO: 73 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1072
);

/* INSERT QUERY NO: 74 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1073
);

/* INSERT QUERY NO: 75 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1074
);

/* INSERT QUERY NO: 76 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1075
);

/* INSERT QUERY NO: 77 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1076
);

/* INSERT QUERY NO: 78 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1077
);

/* INSERT QUERY NO: 79 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1078
);

/* INSERT QUERY NO: 80 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1079
);

/* INSERT QUERY NO: 81 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1080
);

/* INSERT QUERY NO: 82 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1081
);

/* INSERT QUERY NO: 83 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1082
);

/* INSERT QUERY NO: 84 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1083
);

/* INSERT QUERY NO: 85 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1084
);

/* INSERT QUERY NO: 86 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1085
);

/* INSERT QUERY NO: 87 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1086
);

/* INSERT QUERY NO: 88 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1087
);

/* INSERT QUERY NO: 89 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1088
);

/* INSERT QUERY NO: 90 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1089
);

/* INSERT QUERY NO: 91 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1090
);

/* INSERT QUERY NO: 92 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1091
);

/* INSERT QUERY NO: 93 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1092
);

/* INSERT QUERY NO: 94 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1093
);

/* INSERT QUERY NO: 95 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1094
);

/* INSERT QUERY NO: 96 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1095
);

/* INSERT QUERY NO: 97 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1096
);

/* INSERT QUERY NO: 98 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1097
);

/* INSERT QUERY NO: 99 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1098
);

/* INSERT QUERY NO: 100 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1099
);

/* INSERT QUERY NO: 101 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1100
);

/* INSERT QUERY NO: 102 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1101
);

/* INSERT QUERY NO: 103 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1102
);

/* INSERT QUERY NO: 104 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1103
);

/* INSERT QUERY NO: 105 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1104
);

/* INSERT QUERY NO: 106 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1105
);

/* INSERT QUERY NO: 107 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1106
);

/* INSERT QUERY NO: 108 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1107
);

/* INSERT QUERY NO: 109 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1108
);

/* INSERT QUERY NO: 110 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1109
);

/* INSERT QUERY NO: 111 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1110
);

/* INSERT QUERY NO: 112 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1111
);

/* INSERT QUERY NO: 113 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1112
);

/* INSERT QUERY NO: 114 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1113
);

/* INSERT QUERY NO: 115 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1114
);

/* INSERT QUERY NO: 116 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1115
);

/* INSERT QUERY NO: 117 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1116
);

/* INSERT QUERY NO: 118 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1117
);

/* INSERT QUERY NO: 119 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1118
);

/* INSERT QUERY NO: 120 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1119
);

/* INSERT QUERY NO: 121 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1120
);

/* INSERT QUERY NO: 122 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1121
);

/* INSERT QUERY NO: 123 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1122
);

/* INSERT QUERY NO: 124 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1123
);

/* INSERT QUERY NO: 125 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1124
);

/* INSERT QUERY NO: 126 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1125
);

/* INSERT QUERY NO: 127 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1126
);

/* INSERT QUERY NO: 128 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1127
);

/* INSERT QUERY NO: 129 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1128
);

/* INSERT QUERY NO: 130 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1129
);

/* INSERT QUERY NO: 131 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1130
);

/* INSERT QUERY NO: 132 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1131
);

/* INSERT QUERY NO: 133 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1132
);

/* INSERT QUERY NO: 134 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1133
);

/* INSERT QUERY NO: 135 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1134
);

/* INSERT QUERY NO: 136 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1135
);

/* INSERT QUERY NO: 137 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1136
);

/* INSERT QUERY NO: 138 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1137
);

/* INSERT QUERY NO: 139 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1138
);

/* INSERT QUERY NO: 140 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1139
);

/* INSERT QUERY NO: 141 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1140
);

/* INSERT QUERY NO: 142 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1141
);

/* INSERT QUERY NO: 143 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1142
);

/* INSERT QUERY NO: 144 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1143
);

/* INSERT QUERY NO: 145 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1144
);

/* INSERT QUERY NO: 146 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1145
);

/* INSERT QUERY NO: 147 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1146
);

/* INSERT QUERY NO: 148 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1147
);

/* INSERT QUERY NO: 149 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1148
);

/* INSERT QUERY NO: 150 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1149
);

/* INSERT QUERY NO: 151 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1150
);

/* INSERT QUERY NO: 152 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1151
);

/* INSERT QUERY NO: 153 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1152
);

/* INSERT QUERY NO: 154 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1153
);

/* INSERT QUERY NO: 155 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1154
);

/* INSERT QUERY NO: 156 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1155
);

/* INSERT QUERY NO: 157 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1156
);

/* INSERT QUERY NO: 158 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1157
);

/* INSERT QUERY NO: 159 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1158
);

/* INSERT QUERY NO: 160 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1159
);

/* INSERT QUERY NO: 161 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1160
);

/* INSERT QUERY NO: 162 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1161
);

/* INSERT QUERY NO: 163 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1162
);

/* INSERT QUERY NO: 164 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1163
);

/* INSERT QUERY NO: 165 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1164
);

/* INSERT QUERY NO: 166 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1165
);

/* INSERT QUERY NO: 167 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1166
);

/* INSERT QUERY NO: 168 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1167
);

/* INSERT QUERY NO: 169 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1168
);

/* INSERT QUERY NO: 170 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1169
);

/* INSERT QUERY NO: 171 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1170
);

/* INSERT QUERY NO: 172 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1171
);

/* INSERT QUERY NO: 173 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1172
);

/* INSERT QUERY NO: 174 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1173
);

/* INSERT QUERY NO: 175 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1174
);

/* INSERT QUERY NO: 176 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1175
);

/* INSERT QUERY NO: 177 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1176
);

/* INSERT QUERY NO: 178 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1177
);

/* INSERT QUERY NO: 179 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1178
);

/* INSERT QUERY NO: 180 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1179
);

/* INSERT QUERY NO: 181 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1180
);

/* INSERT QUERY NO: 182 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1181
);

/* INSERT QUERY NO: 183 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1182
);

/* INSERT QUERY NO: 184 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1183
);

/* INSERT QUERY NO: 185 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1184
);

/* INSERT QUERY NO: 186 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1185
);

/* INSERT QUERY NO: 187 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1186
);

/* INSERT QUERY NO: 188 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1187
);

/* INSERT QUERY NO: 189 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1188
);

/* INSERT QUERY NO: 190 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1189
);

/* INSERT QUERY NO: 191 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1190
);

/* INSERT QUERY NO: 192 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1191
);

/* INSERT QUERY NO: 193 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1192
);

/* INSERT QUERY NO: 194 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1193
);

/* INSERT QUERY NO: 195 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1194
);

/* INSERT QUERY NO: 196 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1195
);

/* INSERT QUERY NO: 197 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1196
);

/* INSERT QUERY NO: 198 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1197
);

/* INSERT QUERY NO: 199 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1198
);

/* INSERT QUERY NO: 200 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1199
);

/* INSERT QUERY NO: 201 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1200
);

/* INSERT QUERY NO: 202 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1201
);

/* INSERT QUERY NO: 203 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1202
);

/* INSERT QUERY NO: 204 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1203
);

/* INSERT QUERY NO: 205 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1204
);

/* INSERT QUERY NO: 206 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1205
);

/* INSERT QUERY NO: 207 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1206
);

/* INSERT QUERY NO: 208 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1207
);

/* INSERT QUERY NO: 209 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1208
);

/* INSERT QUERY NO: 210 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1209
);

/* INSERT QUERY NO: 211 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1210
);

/* INSERT QUERY NO: 212 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1211
);

/* INSERT QUERY NO: 213 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1212
);

/* INSERT QUERY NO: 214 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1213
);

/* INSERT QUERY NO: 215 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1214
);

/* INSERT QUERY NO: 216 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1215
);

/* INSERT QUERY NO: 217 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1216
);

/* INSERT QUERY NO: 218 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1217
);

/* INSERT QUERY NO: 219 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1218
);

/* INSERT QUERY NO: 220 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1219
);

/* INSERT QUERY NO: 221 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1220
);

/* INSERT QUERY NO: 222 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1221
);

/* INSERT QUERY NO: 223 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1222
);

/* INSERT QUERY NO: 224 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1223
);

/* INSERT QUERY NO: 225 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1224
);

/* INSERT QUERY NO: 226 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1225
);

/* INSERT QUERY NO: 227 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1226
);

/* INSERT QUERY NO: 228 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1227
);

/* INSERT QUERY NO: 229 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1228
);

/* INSERT QUERY NO: 230 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1229
);

/* INSERT QUERY NO: 231 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1230
);

/* INSERT QUERY NO: 232 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1231
);

/* INSERT QUERY NO: 233 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1232
);

/* INSERT QUERY NO: 234 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1233
);

/* INSERT QUERY NO: 235 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1234
);

/* INSERT QUERY NO: 236 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1235
);

/* INSERT QUERY NO: 237 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1236
);

/* INSERT QUERY NO: 238 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1237
);

/* INSERT QUERY NO: 239 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1238
);

/* INSERT QUERY NO: 240 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1239
);

/* INSERT QUERY NO: 241 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1240
);

/* INSERT QUERY NO: 242 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1241
);

/* INSERT QUERY NO: 243 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1242
);

/* INSERT QUERY NO: 244 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1243
);

/* INSERT QUERY NO: 245 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1244
);

/* INSERT QUERY NO: 246 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1245
);

/* INSERT QUERY NO: 247 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1246
);

/* INSERT QUERY NO: 248 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1247
);

/* INSERT QUERY NO: 249 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1248
);

/* INSERT QUERY NO: 250 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1249
);

/* INSERT QUERY NO: 251 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1250
);

/* INSERT QUERY NO: 252 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1251
);

/* INSERT QUERY NO: 253 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1252
);

/* INSERT QUERY NO: 254 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1253
);

/* INSERT QUERY NO: 255 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1254
);

/* INSERT QUERY NO: 256 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1255
);

/* INSERT QUERY NO: 257 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1256
);

/* INSERT QUERY NO: 258 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1257
);

/* INSERT QUERY NO: 259 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1258
);

/* INSERT QUERY NO: 260 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1259
);

/* INSERT QUERY NO: 261 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1260
);

/* INSERT QUERY NO: 262 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1261
);

/* INSERT QUERY NO: 263 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1262
);

/* INSERT QUERY NO: 264 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1263
);

/* INSERT QUERY NO: 265 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1264
);

/* INSERT QUERY NO: 266 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1265
);

/* INSERT QUERY NO: 267 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1266
);

/* INSERT QUERY NO: 268 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1267
);

/* INSERT QUERY NO: 269 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1268
);

/* INSERT QUERY NO: 270 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1269
);

/* INSERT QUERY NO: 271 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1270
);

/* INSERT QUERY NO: 272 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1271
);

/* INSERT QUERY NO: 273 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1272
);

/* INSERT QUERY NO: 274 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1273
);

/* INSERT QUERY NO: 275 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1274
);

/* INSERT QUERY NO: 276 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1275
);

/* INSERT QUERY NO: 277 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1276
);

/* INSERT QUERY NO: 278 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1277
);

/* INSERT QUERY NO: 279 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1278
);

/* INSERT QUERY NO: 280 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1279
);

/* INSERT QUERY NO: 281 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1280
);

/* INSERT QUERY NO: 282 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1281
);

/* INSERT QUERY NO: 283 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1282
);

/* INSERT QUERY NO: 284 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1283
);

/* INSERT QUERY NO: 285 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1284
);

/* INSERT QUERY NO: 286 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1285
);

/* INSERT QUERY NO: 287 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1286
);

/* INSERT QUERY NO: 288 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1287
);

/* INSERT QUERY NO: 289 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1288
);

/* INSERT QUERY NO: 290 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1289
);

/* INSERT QUERY NO: 291 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1290
);

/* INSERT QUERY NO: 292 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1291
);

/* INSERT QUERY NO: 293 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1292
);

/* INSERT QUERY NO: 294 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1293
);

/* INSERT QUERY NO: 295 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1294
);

/* INSERT QUERY NO: 296 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1295
);

/* INSERT QUERY NO: 297 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1296
);

/* INSERT QUERY NO: 298 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1297
);

/* INSERT QUERY NO: 299 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1298
);

/* INSERT QUERY NO: 300 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1299
);

/* INSERT QUERY NO: 301 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1300
);

/* INSERT QUERY NO: 302 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1301
);

/* INSERT QUERY NO: 303 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1302
);

/* INSERT QUERY NO: 304 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1303
);

/* INSERT QUERY NO: 305 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1304
);

/* INSERT QUERY NO: 306 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1305
);

/* INSERT QUERY NO: 307 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1306
);

/* INSERT QUERY NO: 308 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1307
);

/* INSERT QUERY NO: 309 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1308
);

/* INSERT QUERY NO: 310 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1309
);

/* INSERT QUERY NO: 311 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1310
);

/* INSERT QUERY NO: 312 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1311
);

/* INSERT QUERY NO: 313 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1312
);

/* INSERT QUERY NO: 314 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1313
);

/* INSERT QUERY NO: 315 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1314
);

/* INSERT QUERY NO: 316 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1315
);

/* INSERT QUERY NO: 317 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1316
);

/* INSERT QUERY NO: 318 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1317
);

/* INSERT QUERY NO: 319 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1318
);

/* INSERT QUERY NO: 320 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1319
);

/* INSERT QUERY NO: 321 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1320
);

/* INSERT QUERY NO: 322 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1321
);

/* INSERT QUERY NO: 323 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1322
);

/* INSERT QUERY NO: 324 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1323
);

/* INSERT QUERY NO: 325 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1324
);

/* INSERT QUERY NO: 326 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1325
);

/* INSERT QUERY NO: 327 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1326
);

/* INSERT QUERY NO: 328 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1327
);

/* INSERT QUERY NO: 329 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1328
);

/* INSERT QUERY NO: 330 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1329
);

/* INSERT QUERY NO: 331 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1330
);

/* INSERT QUERY NO: 332 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1331
);

/* INSERT QUERY NO: 333 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1332
);

/* INSERT QUERY NO: 334 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1333
);

/* INSERT QUERY NO: 335 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1334
);

/* INSERT QUERY NO: 336 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1335
);

/* INSERT QUERY NO: 337 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1336
);

/* INSERT QUERY NO: 338 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1337
);

/* INSERT QUERY NO: 339 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1338
);

/* INSERT QUERY NO: 340 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1339
);

/* INSERT QUERY NO: 341 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1340
);

/* INSERT QUERY NO: 342 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1341
);

/* INSERT QUERY NO: 343 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1342
);

/* INSERT QUERY NO: 344 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1343
);

/* INSERT QUERY NO: 345 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1344
);

/* INSERT QUERY NO: 346 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1345
);

/* INSERT QUERY NO: 347 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1346
);

/* INSERT QUERY NO: 348 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1347
);

/* INSERT QUERY NO: 349 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1348
);

/* INSERT QUERY NO: 350 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1349
);

/* INSERT QUERY NO: 351 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1350
);

/* INSERT QUERY NO: 352 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1351
);

/* INSERT QUERY NO: 353 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1352
);

/* INSERT QUERY NO: 354 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1353
);

/* INSERT QUERY NO: 355 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1354
);

/* INSERT QUERY NO: 356 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1355
);

/* INSERT QUERY NO: 357 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1356
);

/* INSERT QUERY NO: 358 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1357
);

/* INSERT QUERY NO: 359 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1358
);

/* INSERT QUERY NO: 360 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1359
);

/* INSERT QUERY NO: 361 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1360
);

/* INSERT QUERY NO: 362 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1361
);

/* INSERT QUERY NO: 363 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1362
);

/* INSERT QUERY NO: 364 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1363
);

/* INSERT QUERY NO: 365 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1364
);

/* INSERT QUERY NO: 366 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1365
);

/* INSERT QUERY NO: 367 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1366
);

/* INSERT QUERY NO: 368 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1367
);

/* INSERT QUERY NO: 369 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1368
);

/* INSERT QUERY NO: 370 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1369
);

/* INSERT QUERY NO: 371 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1370
);

/* INSERT QUERY NO: 372 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1371
);

/* INSERT QUERY NO: 373 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1372
);

/* INSERT QUERY NO: 374 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1373
);

/* INSERT QUERY NO: 375 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1374
);

/* INSERT QUERY NO: 376 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1375
);

/* INSERT QUERY NO: 377 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1376
);

/* INSERT QUERY NO: 378 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1377
);

/* INSERT QUERY NO: 379 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1378
);

/* INSERT QUERY NO: 380 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1379
);

/* INSERT QUERY NO: 381 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1380
);

/* INSERT QUERY NO: 382 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1381
);

/* INSERT QUERY NO: 383 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1382
);

/* INSERT QUERY NO: 384 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1383
);

/* INSERT QUERY NO: 385 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1384
);

/* INSERT QUERY NO: 386 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1385
);

/* INSERT QUERY NO: 387 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1386
);

/* INSERT QUERY NO: 388 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1387
);

/* INSERT QUERY NO: 389 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1388
);

/* INSERT QUERY NO: 390 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1389
);

/* INSERT QUERY NO: 391 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1390
);

/* INSERT QUERY NO: 392 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1391
);

/* INSERT QUERY NO: 393 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1392
);

/* INSERT QUERY NO: 394 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1393
);

/* INSERT QUERY NO: 395 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1394
);

/* INSERT QUERY NO: 396 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1395
);

/* INSERT QUERY NO: 397 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1396
);

/* INSERT QUERY NO: 398 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1397
);

/* INSERT QUERY NO: 399 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1398
);

/* INSERT QUERY NO: 400 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1399
);

/* INSERT QUERY NO: 401 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1400
);

/* INSERT QUERY NO: 402 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1401
);

/* INSERT QUERY NO: 403 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1402
);

/* INSERT QUERY NO: 404 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1403
);

/* INSERT QUERY NO: 405 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1404
);

/* INSERT QUERY NO: 406 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1405
);

/* INSERT QUERY NO: 407 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1406
);

/* INSERT QUERY NO: 408 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1407
);

/* INSERT QUERY NO: 409 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1408
);

/* INSERT QUERY NO: 410 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1409
);

/* INSERT QUERY NO: 411 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1410
);

/* INSERT QUERY NO: 412 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1411
);

/* INSERT QUERY NO: 413 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1412
);

/* INSERT QUERY NO: 414 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1413
);

/* INSERT QUERY NO: 415 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1414
);

/* INSERT QUERY NO: 416 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1415
);

/* INSERT QUERY NO: 417 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1416
);

/* INSERT QUERY NO: 418 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1417
);

/* INSERT QUERY NO: 419 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1418
);

/* INSERT QUERY NO: 420 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1419
);

/* INSERT QUERY NO: 421 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1420
);

/* INSERT QUERY NO: 422 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1421
);

/* INSERT QUERY NO: 423 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1422
);

/* INSERT QUERY NO: 424 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1423
);

/* INSERT QUERY NO: 425 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1424
);

/* INSERT QUERY NO: 426 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1425
);

/* INSERT QUERY NO: 427 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1426
);

/* INSERT QUERY NO: 428 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1427
);

/* INSERT QUERY NO: 429 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1428
);

/* INSERT QUERY NO: 430 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1429
);

/* INSERT QUERY NO: 431 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1430
);

/* INSERT QUERY NO: 432 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1431
);

/* INSERT QUERY NO: 433 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1432
);

/* INSERT QUERY NO: 434 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1433
);

/* INSERT QUERY NO: 435 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1434
);

/* INSERT QUERY NO: 436 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1435
);

/* INSERT QUERY NO: 437 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1436
);

/* INSERT QUERY NO: 438 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1437
);

/* INSERT QUERY NO: 439 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1438
);

/* INSERT QUERY NO: 440 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1439
);

/* INSERT QUERY NO: 441 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1440
);

/* INSERT QUERY NO: 442 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1441
);

/* INSERT QUERY NO: 443 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1442
);

/* INSERT QUERY NO: 444 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1443
);

/* INSERT QUERY NO: 445 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1444
);

/* INSERT QUERY NO: 446 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1445
);

/* INSERT QUERY NO: 447 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1446
);

/* INSERT QUERY NO: 448 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1447
);

/* INSERT QUERY NO: 449 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1448
);

/* INSERT QUERY NO: 450 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1449
);

/* INSERT QUERY NO: 451 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1450
);

/* INSERT QUERY NO: 452 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1451
);

/* INSERT QUERY NO: 453 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1452
);

/* INSERT QUERY NO: 454 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1453
);

/* INSERT QUERY NO: 455 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1454
);

/* INSERT QUERY NO: 456 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1455
);

/* INSERT QUERY NO: 457 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1456
);

/* INSERT QUERY NO: 458 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1457
);

/* INSERT QUERY NO: 459 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1458
);

/* INSERT QUERY NO: 460 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1459
);

/* INSERT QUERY NO: 461 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1460
);

/* INSERT QUERY NO: 462 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1461
);

/* INSERT QUERY NO: 463 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1462
);

/* INSERT QUERY NO: 464 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1463
);

/* INSERT QUERY NO: 465 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1464
);

/* INSERT QUERY NO: 466 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1465
);

/* INSERT QUERY NO: 467 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1466
);

/* INSERT QUERY NO: 468 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1467
);

/* INSERT QUERY NO: 469 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1468
);

/* INSERT QUERY NO: 470 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1469
);

/* INSERT QUERY NO: 471 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1470
);

/* INSERT QUERY NO: 472 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1471
);

/* INSERT QUERY NO: 473 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1472
);

/* INSERT QUERY NO: 474 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1473
);

/* INSERT QUERY NO: 475 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1474
);

/* INSERT QUERY NO: 476 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1475
);

/* INSERT QUERY NO: 477 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1476
);

/* INSERT QUERY NO: 478 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1477
);

/* INSERT QUERY NO: 479 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1478
);

/* INSERT QUERY NO: 480 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1479
);

/* INSERT QUERY NO: 481 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1480
);

/* INSERT QUERY NO: 482 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1481
);

/* INSERT QUERY NO: 483 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1482
);

/* INSERT QUERY NO: 484 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1483
);

/* INSERT QUERY NO: 485 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1484
);

/* INSERT QUERY NO: 486 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1485
);

/* INSERT QUERY NO: 487 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1486
);

/* INSERT QUERY NO: 488 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1487
);

/* INSERT QUERY NO: 489 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1488
);

/* INSERT QUERY NO: 490 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1489
);

/* INSERT QUERY NO: 491 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1490
);

/* INSERT QUERY NO: 492 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1491
);

/* INSERT QUERY NO: 493 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1492
);

/* INSERT QUERY NO: 494 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1493
);

/* INSERT QUERY NO: 495 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1494
);

/* INSERT QUERY NO: 496 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1495
);

/* INSERT QUERY NO: 497 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1496
);

/* INSERT QUERY NO: 498 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1497
);

/* INSERT QUERY NO: 499 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1498
);

/* INSERT QUERY NO: 500 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1499
);

/* INSERT QUERY NO: 501 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1500
);

/* INSERT QUERY NO: 502 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1501
);

/* INSERT QUERY NO: 503 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1502
);

/* INSERT QUERY NO: 504 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1503
);

/* INSERT QUERY NO: 505 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1504
);

/* INSERT QUERY NO: 506 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1505
);

/* INSERT QUERY NO: 507 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1506
);

/* INSERT QUERY NO: 508 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1507
);

/* INSERT QUERY NO: 509 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1508
);

/* INSERT QUERY NO: 510 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1509
);

/* INSERT QUERY NO: 511 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1510
);

/* INSERT QUERY NO: 512 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1511
);

/* INSERT QUERY NO: 513 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1512
);

/* INSERT QUERY NO: 514 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1513
);

/* INSERT QUERY NO: 515 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1514
);

/* INSERT QUERY NO: 516 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1515
);

/* INSERT QUERY NO: 517 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1516
);

/* INSERT QUERY NO: 518 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1517
);

/* INSERT QUERY NO: 519 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1518
);

/* INSERT QUERY NO: 520 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1519
);

/* INSERT QUERY NO: 521 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1520
);

/* INSERT QUERY NO: 522 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1521
);

/* INSERT QUERY NO: 523 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1522
);

/* INSERT QUERY NO: 524 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1523
);

/* INSERT QUERY NO: 525 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1524
);

/* INSERT QUERY NO: 526 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1525
);

/* INSERT QUERY NO: 527 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1526
);

/* INSERT QUERY NO: 528 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1527
);

/* INSERT QUERY NO: 529 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1528
);

/* INSERT QUERY NO: 530 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1529
);

/* INSERT QUERY NO: 531 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1530
);

/* INSERT QUERY NO: 532 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1531
);

/* INSERT QUERY NO: 533 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1532
);

/* INSERT QUERY NO: 534 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1533
);

/* INSERT QUERY NO: 535 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1534
);

/* INSERT QUERY NO: 536 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1535
);

/* INSERT QUERY NO: 537 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1536
);

/* INSERT QUERY NO: 538 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1537
);

/* INSERT QUERY NO: 539 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1538
);

/* INSERT QUERY NO: 540 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1539
);

/* INSERT QUERY NO: 541 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1540
);

/* INSERT QUERY NO: 542 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1541
);

/* INSERT QUERY NO: 543 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1542
);

/* INSERT QUERY NO: 544 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1543
);

/* INSERT QUERY NO: 545 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1544
);

/* INSERT QUERY NO: 546 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1545
);

/* INSERT QUERY NO: 547 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1546
);

/* INSERT QUERY NO: 548 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1547
);

/* INSERT QUERY NO: 549 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1548
);

/* INSERT QUERY NO: 550 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1549
);

/* INSERT QUERY NO: 551 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1550
);

/* INSERT QUERY NO: 552 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1551
);

/* INSERT QUERY NO: 553 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1552
);

/* INSERT QUERY NO: 554 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1553
);

/* INSERT QUERY NO: 555 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1554
);

/* INSERT QUERY NO: 556 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1555
);

/* INSERT QUERY NO: 557 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1556
);

/* INSERT QUERY NO: 558 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1557
);

/* INSERT QUERY NO: 559 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1558
);

/* INSERT QUERY NO: 560 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1559
);

/* INSERT QUERY NO: 561 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1560
);

/* INSERT QUERY NO: 562 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1561
);

/* INSERT QUERY NO: 563 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1562
);

/* INSERT QUERY NO: 564 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1563
);

/* INSERT QUERY NO: 565 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1564
);

/* INSERT QUERY NO: 566 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1565
);

/* INSERT QUERY NO: 567 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1566
);

/* INSERT QUERY NO: 568 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1567
);

/* INSERT QUERY NO: 569 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1568
);

/* INSERT QUERY NO: 570 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1569
);

/* INSERT QUERY NO: 571 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1570
);

/* INSERT QUERY NO: 572 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1571
);

/* INSERT QUERY NO: 573 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1572
);

/* INSERT QUERY NO: 574 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1573
);

/* INSERT QUERY NO: 575 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1574
);

/* INSERT QUERY NO: 576 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1575
);

/* INSERT QUERY NO: 577 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1576
);

/* INSERT QUERY NO: 578 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1577
);

/* INSERT QUERY NO: 579 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1578
);

/* INSERT QUERY NO: 580 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1579
);

/* INSERT QUERY NO: 581 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1580
);

/* INSERT QUERY NO: 582 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1581
);

/* INSERT QUERY NO: 583 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1582
);

/* INSERT QUERY NO: 584 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1583
);

/* INSERT QUERY NO: 585 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1584
);

/* INSERT QUERY NO: 586 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1585
);

/* INSERT QUERY NO: 587 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1586
);

/* INSERT QUERY NO: 588 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1587
);

/* INSERT QUERY NO: 589 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1588
);

/* INSERT QUERY NO: 590 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1589
);

/* INSERT QUERY NO: 591 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1590
);

/* INSERT QUERY NO: 592 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1591
);

/* INSERT QUERY NO: 593 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1592
);

/* INSERT QUERY NO: 594 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1593
);

/* INSERT QUERY NO: 595 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1594
);

/* INSERT QUERY NO: 596 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1595
);

/* INSERT QUERY NO: 597 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1596
);

/* INSERT QUERY NO: 598 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1597
);

/* INSERT QUERY NO: 599 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1598
);

/* INSERT QUERY NO: 600 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1599
);

/* INSERT QUERY NO: 601 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1600
);

/* INSERT QUERY NO: 602 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1601
);

/* INSERT QUERY NO: 603 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1602
);

/* INSERT QUERY NO: 604 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1603
);

/* INSERT QUERY NO: 605 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1604
);

/* INSERT QUERY NO: 606 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1605
);

/* INSERT QUERY NO: 607 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1606
);

/* INSERT QUERY NO: 608 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1607
);

/* INSERT QUERY NO: 609 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1608
);

/* INSERT QUERY NO: 610 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1609
);

/* INSERT QUERY NO: 611 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1610
);

/* INSERT QUERY NO: 612 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1611
);

/* INSERT QUERY NO: 613 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1612
);

/* INSERT QUERY NO: 614 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1613
);

/* INSERT QUERY NO: 615 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1614
);

/* INSERT QUERY NO: 616 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1615
);

/* INSERT QUERY NO: 617 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1616
);

/* INSERT QUERY NO: 618 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1617
);

/* INSERT QUERY NO: 619 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1618
);

/* INSERT QUERY NO: 620 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1619
);

/* INSERT QUERY NO: 621 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1620
);

/* INSERT QUERY NO: 622 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1621
);

/* INSERT QUERY NO: 623 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1622
);

/* INSERT QUERY NO: 624 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1623
);

/* INSERT QUERY NO: 625 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1624
);

/* INSERT QUERY NO: 626 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1625
);

/* INSERT QUERY NO: 627 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1626
);

/* INSERT QUERY NO: 628 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1627
);

/* INSERT QUERY NO: 629 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1628
);

/* INSERT QUERY NO: 630 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1629
);

/* INSERT QUERY NO: 631 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1630
);

/* INSERT QUERY NO: 632 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1631
);

/* INSERT QUERY NO: 633 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1632
);

/* INSERT QUERY NO: 634 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1633
);

/* INSERT QUERY NO: 635 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1634
);

/* INSERT QUERY NO: 636 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1635
);

/* INSERT QUERY NO: 637 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1636
);

/* INSERT QUERY NO: 638 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1637
);

/* INSERT QUERY NO: 639 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1638
);

/* INSERT QUERY NO: 640 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1639
);

/* INSERT QUERY NO: 641 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1640
);

/* INSERT QUERY NO: 642 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1641
);

/* INSERT QUERY NO: 643 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1642
);

/* INSERT QUERY NO: 644 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1643
);

/* INSERT QUERY NO: 645 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1644
);

/* INSERT QUERY NO: 646 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1645
);

/* INSERT QUERY NO: 647 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1646
);

/* INSERT QUERY NO: 648 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1647
);

/* INSERT QUERY NO: 649 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1648
);

/* INSERT QUERY NO: 650 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1649
);

/* INSERT QUERY NO: 651 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1650
);

/* INSERT QUERY NO: 652 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1651
);

/* INSERT QUERY NO: 653 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1652
);

/* INSERT QUERY NO: 654 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1653
);

/* INSERT QUERY NO: 655 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1654
);

/* INSERT QUERY NO: 656 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1655
);

/* INSERT QUERY NO: 657 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1656
);

/* INSERT QUERY NO: 658 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1657
);

/* INSERT QUERY NO: 659 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1658
);

/* INSERT QUERY NO: 660 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1659
);

/* INSERT QUERY NO: 661 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1660
);

/* INSERT QUERY NO: 662 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1661
);

/* INSERT QUERY NO: 663 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1662
);

/* INSERT QUERY NO: 664 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1663
);

/* INSERT QUERY NO: 665 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1664
);

/* INSERT QUERY NO: 666 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1665
);

/* INSERT QUERY NO: 667 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1666
);

/* INSERT QUERY NO: 668 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1667
);

/* INSERT QUERY NO: 669 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1668
);

/* INSERT QUERY NO: 670 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1669
);

/* INSERT QUERY NO: 671 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1670
);

/* INSERT QUERY NO: 672 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1671
);

/* INSERT QUERY NO: 673 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1672
);

/* INSERT QUERY NO: 674 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1673
);

/* INSERT QUERY NO: 675 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1674
);

/* INSERT QUERY NO: 676 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1675
);

/* INSERT QUERY NO: 677 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1676
);

/* INSERT QUERY NO: 678 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1677
);

/* INSERT QUERY NO: 679 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1678
);

/* INSERT QUERY NO: 680 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1679
);

/* INSERT QUERY NO: 681 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1680
);

/* INSERT QUERY NO: 682 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1681
);

/* INSERT QUERY NO: 683 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1682
);

/* INSERT QUERY NO: 684 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1683
);

/* INSERT QUERY NO: 685 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1684
);

/* INSERT QUERY NO: 686 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1685
);

/* INSERT QUERY NO: 687 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1686
);

/* INSERT QUERY NO: 688 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1687
);

/* INSERT QUERY NO: 689 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1688
);

/* INSERT QUERY NO: 690 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1689
);

/* INSERT QUERY NO: 691 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1690
);

/* INSERT QUERY NO: 692 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1691
);

/* INSERT QUERY NO: 693 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1692
);

/* INSERT QUERY NO: 694 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1693
);

/* INSERT QUERY NO: 695 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1694
);

/* INSERT QUERY NO: 696 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1695
);

/* INSERT QUERY NO: 697 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1696
);

/* INSERT QUERY NO: 698 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1697
);

/* INSERT QUERY NO: 699 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1698
);

/* INSERT QUERY NO: 700 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1699
);

/* INSERT QUERY NO: 701 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1700
);

/* INSERT QUERY NO: 702 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1701
);

/* INSERT QUERY NO: 703 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1702
);

/* INSERT QUERY NO: 704 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1703
);

/* INSERT QUERY NO: 705 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1704
);

/* INSERT QUERY NO: 706 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1705
);

/* INSERT QUERY NO: 707 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1706
);

/* INSERT QUERY NO: 708 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1707
);

/* INSERT QUERY NO: 709 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1708
);

/* INSERT QUERY NO: 710 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1709
);

/* INSERT QUERY NO: 711 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1710
);

/* INSERT QUERY NO: 712 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1711
);

/* INSERT QUERY NO: 713 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1712
);

/* INSERT QUERY NO: 714 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1713
);

/* INSERT QUERY NO: 715 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1714
);

/* INSERT QUERY NO: 716 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1715
);

/* INSERT QUERY NO: 717 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1716
);

/* INSERT QUERY NO: 718 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1717
);

/* INSERT QUERY NO: 719 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1718
);

/* INSERT QUERY NO: 720 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1719
);

/* INSERT QUERY NO: 721 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1720
);

/* INSERT QUERY NO: 722 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1721
);

/* INSERT QUERY NO: 723 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1722
);

/* INSERT QUERY NO: 724 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1723
);

/* INSERT QUERY NO: 725 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1724
);

/* INSERT QUERY NO: 726 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1725
);

/* INSERT QUERY NO: 727 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1726
);

/* INSERT QUERY NO: 728 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1727
);

/* INSERT QUERY NO: 729 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1728
);

/* INSERT QUERY NO: 730 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1729
);

/* INSERT QUERY NO: 731 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1730
);

/* INSERT QUERY NO: 732 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1731
);

/* INSERT QUERY NO: 733 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1732
);

/* INSERT QUERY NO: 734 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1733
);

/* INSERT QUERY NO: 735 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1734
);

/* INSERT QUERY NO: 736 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1735
);

/* INSERT QUERY NO: 737 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1736
);

/* INSERT QUERY NO: 738 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1737
);

/* INSERT QUERY NO: 739 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1738
);

/* INSERT QUERY NO: 740 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1739
);

/* INSERT QUERY NO: 741 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1740
);

/* INSERT QUERY NO: 742 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1741
);

/* INSERT QUERY NO: 743 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1742
);

/* INSERT QUERY NO: 744 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1743
);

/* INSERT QUERY NO: 745 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1744
);

/* INSERT QUERY NO: 746 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1745
);

/* INSERT QUERY NO: 747 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1746
);

/* INSERT QUERY NO: 748 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1747
);

/* INSERT QUERY NO: 749 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1748
);

/* INSERT QUERY NO: 750 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1749
);

/* INSERT QUERY NO: 751 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1750
);

/* INSERT QUERY NO: 752 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1751
);

/* INSERT QUERY NO: 753 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1752
);

/* INSERT QUERY NO: 754 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1753
);

/* INSERT QUERY NO: 755 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1754
);

/* INSERT QUERY NO: 756 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1755
);

/* INSERT QUERY NO: 757 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1756
);

/* INSERT QUERY NO: 758 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1757
);

/* INSERT QUERY NO: 759 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1758
);

/* INSERT QUERY NO: 760 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1759
);

/* INSERT QUERY NO: 761 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1760
);

/* INSERT QUERY NO: 762 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1761
);

/* INSERT QUERY NO: 763 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1762
);

/* INSERT QUERY NO: 764 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1763
);

/* INSERT QUERY NO: 765 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1764
);

/* INSERT QUERY NO: 766 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1765
);

/* INSERT QUERY NO: 767 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1766
);

/* INSERT QUERY NO: 768 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1767
);

/* INSERT QUERY NO: 769 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1768
);

/* INSERT QUERY NO: 770 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1769
);

/* INSERT QUERY NO: 771 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1770
);

/* INSERT QUERY NO: 772 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1771
);

/* INSERT QUERY NO: 773 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1772
);

/* INSERT QUERY NO: 774 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1773
);

/* INSERT QUERY NO: 775 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1774
);

/* INSERT QUERY NO: 776 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1775
);

/* INSERT QUERY NO: 777 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1776
);

/* INSERT QUERY NO: 778 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1777
);

/* INSERT QUERY NO: 779 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1778
);

/* INSERT QUERY NO: 780 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1779
);

/* INSERT QUERY NO: 781 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1780
);

/* INSERT QUERY NO: 782 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1781
);

/* INSERT QUERY NO: 783 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1782
);

/* INSERT QUERY NO: 784 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1783
);

/* INSERT QUERY NO: 785 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1784
);

/* INSERT QUERY NO: 786 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1785
);

/* INSERT QUERY NO: 787 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1786
);

/* INSERT QUERY NO: 788 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1787
);

/* INSERT QUERY NO: 789 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1788
);

/* INSERT QUERY NO: 790 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1789
);

/* INSERT QUERY NO: 791 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1790
);

/* INSERT QUERY NO: 792 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1791
);

/* INSERT QUERY NO: 793 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1792
);

/* INSERT QUERY NO: 794 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1793
);

/* INSERT QUERY NO: 795 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1794
);

/* INSERT QUERY NO: 796 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1795
);

/* INSERT QUERY NO: 797 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1796
);

/* INSERT QUERY NO: 798 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1797
);

/* INSERT QUERY NO: 799 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1798
);

/* INSERT QUERY NO: 800 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1799
);

/* INSERT QUERY NO: 801 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1800
);

/* INSERT QUERY NO: 802 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1801
);

/* INSERT QUERY NO: 803 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1802
);

/* INSERT QUERY NO: 804 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1803
);

/* INSERT QUERY NO: 805 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1804
);

/* INSERT QUERY NO: 806 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1805
);

/* INSERT QUERY NO: 807 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1806
);

/* INSERT QUERY NO: 808 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1807
);

/* INSERT QUERY NO: 809 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1808
);

/* INSERT QUERY NO: 810 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1809
);

/* INSERT QUERY NO: 811 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1810
);

/* INSERT QUERY NO: 812 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1811
);

/* INSERT QUERY NO: 813 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1812
);

/* INSERT QUERY NO: 814 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1813
);

/* INSERT QUERY NO: 815 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1814
);

/* INSERT QUERY NO: 816 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1815
);

/* INSERT QUERY NO: 817 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1816
);

/* INSERT QUERY NO: 818 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1817
);

/* INSERT QUERY NO: 819 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1818
);

/* INSERT QUERY NO: 820 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1819
);

/* INSERT QUERY NO: 821 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1820
);

/* INSERT QUERY NO: 822 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1821
);

/* INSERT QUERY NO: 823 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1822
);

/* INSERT QUERY NO: 824 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1823
);

/* INSERT QUERY NO: 825 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1824
);

/* INSERT QUERY NO: 826 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1825
);

/* INSERT QUERY NO: 827 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1826
);

/* INSERT QUERY NO: 828 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1827
);

/* INSERT QUERY NO: 829 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1828
);

/* INSERT QUERY NO: 830 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1829
);

/* INSERT QUERY NO: 831 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1830
);

/* INSERT QUERY NO: 832 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1831
);

/* INSERT QUERY NO: 833 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1832
);

/* INSERT QUERY NO: 834 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1833
);

/* INSERT QUERY NO: 835 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1834
);

/* INSERT QUERY NO: 836 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1835
);

/* INSERT QUERY NO: 837 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1836
);

/* INSERT QUERY NO: 838 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1837
);

/* INSERT QUERY NO: 839 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1838
);

/* INSERT QUERY NO: 840 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1839
);

/* INSERT QUERY NO: 841 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1840
);

/* INSERT QUERY NO: 842 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1841
);

/* INSERT QUERY NO: 843 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1842
);

/* INSERT QUERY NO: 844 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1843
);

/* INSERT QUERY NO: 845 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1844
);

/* INSERT QUERY NO: 846 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1845
);

/* INSERT QUERY NO: 847 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1846
);

/* INSERT QUERY NO: 848 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1847
);

/* INSERT QUERY NO: 849 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1848
);

/* INSERT QUERY NO: 850 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1849
);

/* INSERT QUERY NO: 851 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1850
);

/* INSERT QUERY NO: 852 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1851
);

/* INSERT QUERY NO: 853 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1852
);

/* INSERT QUERY NO: 854 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1853
);

/* INSERT QUERY NO: 855 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1854
);

/* INSERT QUERY NO: 856 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1855
);

/* INSERT QUERY NO: 857 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1856
);

/* INSERT QUERY NO: 858 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1857
);

/* INSERT QUERY NO: 859 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1858
);

/* INSERT QUERY NO: 860 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1859
);

/* INSERT QUERY NO: 861 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1860
);

/* INSERT QUERY NO: 862 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1861
);

/* INSERT QUERY NO: 863 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1862
);

/* INSERT QUERY NO: 864 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1863
);

/* INSERT QUERY NO: 865 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1864
);

/* INSERT QUERY NO: 866 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1865
);

/* INSERT QUERY NO: 867 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1866
);

/* INSERT QUERY NO: 868 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1867
);

/* INSERT QUERY NO: 869 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1868
);

/* INSERT QUERY NO: 870 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1869
);

/* INSERT QUERY NO: 871 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1870
);

/* INSERT QUERY NO: 872 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1871
);

/* INSERT QUERY NO: 873 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1872
);

/* INSERT QUERY NO: 874 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1873
);

/* INSERT QUERY NO: 875 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1874
);

/* INSERT QUERY NO: 876 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1875
);

/* INSERT QUERY NO: 877 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1876
);

/* INSERT QUERY NO: 878 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1877
);

/* INSERT QUERY NO: 879 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1878
);

/* INSERT QUERY NO: 880 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1879
);

/* INSERT QUERY NO: 881 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1880
);

/* INSERT QUERY NO: 882 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1881
);

/* INSERT QUERY NO: 883 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1882
);

/* INSERT QUERY NO: 884 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1883
);

/* INSERT QUERY NO: 885 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1884
);

/* INSERT QUERY NO: 886 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1885
);

/* INSERT QUERY NO: 887 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1886
);

/* INSERT QUERY NO: 888 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1887
);

/* INSERT QUERY NO: 889 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1888
);

/* INSERT QUERY NO: 890 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1889
);

/* INSERT QUERY NO: 891 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1890
);

/* INSERT QUERY NO: 892 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1891
);

/* INSERT QUERY NO: 893 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1892
);

/* INSERT QUERY NO: 894 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1893
);

/* INSERT QUERY NO: 895 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1894
);

/* INSERT QUERY NO: 896 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1895
);

/* INSERT QUERY NO: 897 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1896
);

/* INSERT QUERY NO: 898 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1897
);

/* INSERT QUERY NO: 899 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1898
);

/* INSERT QUERY NO: 900 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1899
);

/* INSERT QUERY NO: 901 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1900
);

/* INSERT QUERY NO: 902 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1901
);

/* INSERT QUERY NO: 903 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1902
);

/* INSERT QUERY NO: 904 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1903
);

/* INSERT QUERY NO: 905 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1904
);

/* INSERT QUERY NO: 906 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1905
);

/* INSERT QUERY NO: 907 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1906
);

/* INSERT QUERY NO: 908 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1907
);

/* INSERT QUERY NO: 909 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1908
);

/* INSERT QUERY NO: 910 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1909
);

/* INSERT QUERY NO: 911 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1910
);

/* INSERT QUERY NO: 912 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1911
);

/* INSERT QUERY NO: 913 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1912
);

/* INSERT QUERY NO: 914 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1913
);

/* INSERT QUERY NO: 915 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1914
);

/* INSERT QUERY NO: 916 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1915
);

/* INSERT QUERY NO: 917 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1916
);

/* INSERT QUERY NO: 918 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1917
);

/* INSERT QUERY NO: 919 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1918
);

/* INSERT QUERY NO: 920 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1919
);

/* INSERT QUERY NO: 921 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1920
);

/* INSERT QUERY NO: 922 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1921
);

/* INSERT QUERY NO: 923 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1922
);

/* INSERT QUERY NO: 924 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1923
);

/* INSERT QUERY NO: 925 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1924
);

/* INSERT QUERY NO: 926 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1925
);

/* INSERT QUERY NO: 927 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1926
);

/* INSERT QUERY NO: 928 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1927
);

/* INSERT QUERY NO: 929 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1928
);

/* INSERT QUERY NO: 930 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1929
);

/* INSERT QUERY NO: 931 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1930
);

/* INSERT QUERY NO: 932 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1931
);

/* INSERT QUERY NO: 933 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1932
);

/* INSERT QUERY NO: 934 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1933
);

/* INSERT QUERY NO: 935 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1934
);

/* INSERT QUERY NO: 936 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1935
);

/* INSERT QUERY NO: 937 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1936
);

/* INSERT QUERY NO: 938 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1937
);

/* INSERT QUERY NO: 939 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1938
);

/* INSERT QUERY NO: 940 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1939
);

/* INSERT QUERY NO: 941 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1940
);

/* INSERT QUERY NO: 942 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1941
);

/* INSERT QUERY NO: 943 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1942
);

/* INSERT QUERY NO: 944 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1943
);

/* INSERT QUERY NO: 945 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1944
);

/* INSERT QUERY NO: 946 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1945
);

/* INSERT QUERY NO: 947 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1946
);

/* INSERT QUERY NO: 948 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1947
);

/* INSERT QUERY NO: 949 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1948
);

/* INSERT QUERY NO: 950 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1949
);

/* INSERT QUERY NO: 951 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1950
);

/* INSERT QUERY NO: 952 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1951
);

/* INSERT QUERY NO: 953 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1952
);

/* INSERT QUERY NO: 954 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1953
);

/* INSERT QUERY NO: 955 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1954
);

/* INSERT QUERY NO: 956 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1955
);

/* INSERT QUERY NO: 957 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1956
);

/* INSERT QUERY NO: 958 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1957
);

/* INSERT QUERY NO: 959 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1958
);

/* INSERT QUERY NO: 960 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1959
);

/* INSERT QUERY NO: 961 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1960
);

/* INSERT QUERY NO: 962 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1961
);

/* INSERT QUERY NO: 963 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1962
);

/* INSERT QUERY NO: 964 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1963
);

/* INSERT QUERY NO: 965 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1964
);

/* INSERT QUERY NO: 966 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1965
);

/* INSERT QUERY NO: 967 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1966
);

/* INSERT QUERY NO: 968 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1967
);

/* INSERT QUERY NO: 969 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1968
);

/* INSERT QUERY NO: 970 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1969
);

/* INSERT QUERY NO: 971 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1970
);

/* INSERT QUERY NO: 972 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1971
);

/* INSERT QUERY NO: 973 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1972
);

/* INSERT QUERY NO: 974 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1973
);

/* INSERT QUERY NO: 975 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1974
);

/* INSERT QUERY NO: 976 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1975
);

/* INSERT QUERY NO: 977 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1976
);

/* INSERT QUERY NO: 978 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1977
);

/* INSERT QUERY NO: 979 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1978
);

/* INSERT QUERY NO: 980 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1979
);

/* INSERT QUERY NO: 981 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1980
);

/* INSERT QUERY NO: 982 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1981
);

/* INSERT QUERY NO: 983 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1982
);

/* INSERT QUERY NO: 984 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1983
);

/* INSERT QUERY NO: 985 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1984
);

/* INSERT QUERY NO: 986 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1985
);

/* INSERT QUERY NO: 987 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1986
);

/* INSERT QUERY NO: 988 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1987
);

/* INSERT QUERY NO: 989 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1988
);

/* INSERT QUERY NO: 990 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1989
);

/* INSERT QUERY NO: 991 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1990
);

/* INSERT QUERY NO: 992 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1991
);

/* INSERT QUERY NO: 993 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1992
);

/* INSERT QUERY NO: 994 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1993
);

/* INSERT QUERY NO: 995 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1994
);

/* INSERT QUERY NO: 996 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1995
);

/* INSERT QUERY NO: 997 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1996
);

/* INSERT QUERY NO: 998 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1997
);

/* INSERT QUERY NO: 999 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'si', 1998
);

/* INSERT QUERY NO: 1000 */
INSERT INTO Controles(ControlEstabilidad, IdCarac)
VALUES
(
'no', 1999
);

