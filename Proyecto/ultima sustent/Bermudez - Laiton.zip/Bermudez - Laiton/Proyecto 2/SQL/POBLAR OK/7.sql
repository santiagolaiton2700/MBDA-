/* Showing results for LoteProducciones.xlsx */

/* INSERT QUERY NO: 1 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
1, 11, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 2 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
2, 22, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 3 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
3, 33, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 4 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
4, 44, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 5 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
5, 55, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 6 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
6, 66, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 7 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
7, 77, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 8 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
8, 88, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 9 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
9, 99, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 10 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
10, 1010, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 11 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
11, 1111, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 12 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
12, 1212, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 13 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
13, 1313, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 14 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
14, 1414, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 15 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
15, 1515, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 16 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
16, 1616, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 17 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
17, 1717, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 18 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
18, 1818, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 19 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
19, 1919, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 20 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
20, 2020, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 21 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
21, 2121, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 22 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
22, 2222, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 23 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
23, 2323, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 24 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
24, 2424, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 25 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
25, 2525, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 26 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
26, 2626, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 27 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
27, 2727, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 28 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
28, 2828, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 29 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
29, 2929, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 30 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
30, 3030, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 31 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
31, 3131, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 32 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
32, 3232, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 33 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
33, 3333, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 34 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
34, 3434, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 35 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
35, 3535, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 36 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
36, 3636, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 37 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
37, 3737, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 38 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
38, 3838, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 39 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
39, 3939, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 40 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
40, 4040, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 41 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
41, 4141, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 42 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
42, 4242, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 43 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
43, 4343, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 44 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
44, 4444, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 45 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
45, 4545, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 46 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
46, 4646, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 47 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
47, 4747, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 48 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
48, 4848, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 49 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
49, 4949, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 50 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
50, 5050, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 51 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
51, 5151, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 52 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
52, 5252, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 53 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
53, 5353, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 54 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
54, 5454, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 55 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
55, 5555, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 56 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
56, 5656, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 57 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
57, 5757, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 58 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
58, 5858, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 59 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
59, 5959, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 60 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
60, 6060, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 61 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
61, 6161, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 62 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
62, 6262, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 63 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
63, 6363, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 64 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
64, 6464, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 65 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
65, 6565, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 66 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
66, 6666, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 67 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
67, 6767, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 68 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
68, 6868, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 69 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
69, 6969, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 70 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
70, 7070, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 71 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
71, 7171, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 72 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
72, 7272, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 73 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
73, 7373, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 74 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
74, 7474, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 75 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
75, 7575, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 76 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
76, 7676, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 77 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
77, 7777, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 78 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
78, 7878, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 79 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
79, 7979, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 80 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
80, 8080, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 81 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
81, 8181, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 82 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
82, 8282, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 83 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
83, 8383, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 84 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
84, 8484, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 85 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
85, 8585, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 86 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
86, 8686, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 87 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
87, 8787, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 88 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
88, 8888, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 89 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
89, 8989, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 90 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
90, 9090, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 91 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
91, 9191, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 92 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
92, 9292, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 93 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
93, 9393, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 94 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
94, 9494, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 95 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
95, 9595, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 96 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
96, 9696, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 97 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
97, 9797, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 98 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
98, 9898, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 99 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
99, 9999, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 100 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
100, 100100, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 101 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
101, 101101, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 102 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
102, 102102, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 103 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
103, 103103, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 104 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
104, 104104, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 105 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
105, 105105, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 106 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
106, 106106, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 107 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
107, 107107, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 108 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
108, 108108, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 109 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
109, 109109, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 110 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
110, 110110, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 111 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
111, 111111, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 112 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
112, 112112, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 113 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
113, 113113, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 114 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
114, 114114, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 115 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
115, 115115, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 116 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
116, 116116, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 117 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
117, 117117, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 118 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
118, 118118, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 119 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
119, 119119, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 120 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
120, 120120, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 121 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
121, 121121, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 122 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
122, 122122, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 123 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
123, 123123, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 124 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
124, 124124, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 125 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
125, 125125, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 126 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
126, 126126, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 127 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
127, 127127, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 128 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
128, 128128, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 129 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
129, 129129, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 130 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
130, 130130, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 131 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
131, 131131, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 132 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
132, 132132, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 133 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
133, 133133, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 134 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
134, 134134, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 135 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
135, 135135, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 136 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
136, 136136, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 137 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
137, 137137, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 138 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
138, 138138, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 139 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
139, 139139, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 140 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
140, 140140, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 141 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
141, 141141, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 142 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
142, 142142, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 143 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
143, 143143, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 144 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
144, 144144, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 145 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
145, 145145, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 146 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
146, 146146, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 147 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
147, 147147, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 148 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
148, 148148, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 149 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
149, 149149, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 150 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
150, 150150, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 151 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
151, 151151, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 152 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
152, 152152, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 153 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
153, 153153, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 154 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
154, 154154, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 155 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
155, 155155, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 156 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
156, 156156, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 157 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
157, 157157, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 158 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
158, 158158, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 159 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
159, 159159, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 160 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
160, 160160, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 161 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
161, 161161, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 162 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
162, 162162, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 163 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
163, 163163, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 164 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
164, 164164, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 165 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
165, 165165, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 166 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
166, 166166, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 167 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
167, 167167, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 168 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
168, 168168, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 169 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
169, 169169, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 170 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
170, 170170, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 171 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
171, 171171, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 172 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
172, 172172, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 173 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
173, 173173, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 174 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
174, 174174, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 175 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
175, 175175, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 176 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
176, 176176, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 177 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
177, 177177, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 178 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
178, 178178, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 179 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
179, 179179, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 180 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
180, 180180, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 181 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
181, 181181, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 182 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
182, 182182, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 183 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
183, 183183, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 184 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
184, 184184, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 185 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
185, 185185, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 186 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
186, 186186, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 187 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
187, 187187, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 188 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
188, 188188, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 189 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
189, 189189, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 190 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
190, 190190, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 191 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
191, 191191, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 192 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
192, 192192, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 193 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
193, 193193, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 194 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
194, 194194, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 195 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
195, 195195, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 196 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
196, 196196, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 197 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
197, 197197, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 198 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
198, 198198, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 199 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
199, 199199, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 200 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
200, 200200, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 201 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
201, 201201, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 202 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
202, 202202, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 203 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
203, 203203, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 204 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
204, 204204, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 205 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
205, 205205, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 206 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
206, 206206, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 207 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
207, 207207, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 208 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
208, 208208, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 209 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
209, 209209, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 210 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
210, 210210, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 211 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
211, 211211, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 212 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
212, 212212, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 213 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
213, 213213, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 214 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
214, 214214, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 215 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
215, 215215, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 216 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
216, 216216, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 217 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
217, 217217, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 218 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
218, 218218, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 219 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
219, 219219, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 220 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
220, 220220, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 221 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
221, 221221, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 222 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
222, 222222, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 223 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
223, 223223, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 224 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
224, 224224, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 225 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
225, 225225, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 226 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
226, 226226, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 227 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
227, 227227, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 228 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
228, 228228, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 229 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
229, 229229, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 230 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
230, 230230, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 231 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
231, 231231, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 232 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
232, 232232, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 233 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
233, 233233, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 234 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
234, 234234, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 235 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
235, 235235, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 236 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
236, 236236, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 237 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
237, 237237, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 238 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
238, 238238, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 239 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
239, 239239, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 240 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
240, 240240, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 241 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
241, 241241, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 242 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
242, 242242, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 243 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
243, 243243, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 244 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
244, 244244, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 245 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
245, 245245, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 246 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
246, 246246, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 247 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
247, 247247, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 248 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
248, 248248, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 249 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
249, 249249, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 250 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
250, 250250, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 251 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
251, 251251, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 252 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
252, 252252, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 253 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
253, 253253, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 254 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
254, 254254, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 255 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
255, 255255, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 256 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
256, 256256, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 257 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
257, 257257, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 258 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
258, 258258, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 259 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
259, 259259, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 260 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
260, 260260, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 261 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
261, 261261, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 262 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
262, 262262, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 263 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
263, 263263, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 264 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
264, 264264, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 265 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
265, 265265, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 266 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
266, 266266, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 267 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
267, 267267, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 268 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
268, 268268, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 269 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
269, 269269, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 270 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
270, 270270, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 271 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
271, 271271, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 272 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
272, 272272, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 273 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
273, 273273, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 274 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
274, 274274, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 275 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
275, 275275, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 276 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
276, 276276, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 277 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
277, 277277, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 278 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
278, 278278, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 279 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
279, 279279, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 280 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
280, 280280, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 281 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
281, 281281, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 282 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
282, 282282, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 283 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
283, 283283, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 284 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
284, 284284, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 285 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
285, 285285, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 286 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
286, 286286, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 287 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
287, 287287, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 288 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
288, 288288, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 289 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
289, 289289, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 290 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
290, 290290, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 291 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
291, 291291, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 292 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
292, 292292, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 293 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
293, 293293, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 294 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
294, 294294, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 295 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
295, 295295, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 296 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
296, 296296, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 297 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
297, 297297, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 298 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
298, 298298, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 299 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
299, 299299, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 300 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
300, 300300, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 301 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
301, 301301, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 302 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
302, 302302, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 303 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
303, 303303, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 304 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
304, 304304, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 305 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
305, 305305, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 306 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
306, 306306, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 307 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
307, 307307, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 308 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
308, 308308, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 309 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
309, 309309, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 310 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
310, 310310, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 311 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
311, 311311, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 312 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
312, 312312, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 313 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
313, 313313, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 314 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
314, 314314, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 315 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
315, 315315, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 316 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
316, 316316, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 317 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
317, 317317, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 318 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
318, 318318, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 319 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
319, 319319, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 320 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
320, 320320, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 321 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
321, 321321, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 322 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
322, 322322, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 323 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
323, 323323, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 324 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
324, 324324, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 325 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
325, 325325, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 326 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
326, 326326, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 327 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
327, 327327, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 328 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
328, 328328, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 329 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
329, 329329, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 330 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
330, 330330, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 331 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
331, 331331, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 332 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
332, 332332, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 333 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
333, 333333, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 334 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
334, 334334, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 335 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
335, 335335, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 336 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
336, 336336, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 337 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
337, 337337, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 338 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
338, 338338, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 339 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
339, 339339, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 340 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
340, 340340, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 341 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
341, 341341, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 342 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
342, 342342, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 343 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
343, 343343, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 344 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
344, 344344, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 345 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
345, 345345, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 346 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
346, 346346, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 347 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
347, 347347, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 348 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
348, 348348, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 349 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
349, 349349, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 350 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
350, 350350, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 351 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
351, 351351, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 352 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
352, 352352, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 353 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
353, 353353, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 354 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
354, 354354, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 355 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
355, 355355, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 356 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
356, 356356, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 357 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
357, 357357, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 358 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
358, 358358, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 359 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
359, 359359, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 360 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
360, 360360, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 361 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
361, 361361, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 362 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
362, 362362, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 363 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
363, 363363, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 364 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
364, 364364, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 365 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
365, 365365, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 366 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
366, 366366, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 367 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
367, 367367, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 368 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
368, 368368, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 369 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
369, 369369, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 370 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
370, 370370, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 371 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
371, 371371, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 372 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
372, 372372, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 373 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
373, 373373, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 374 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
374, 374374, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 375 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
375, 375375, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 376 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
376, 376376, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 377 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
377, 377377, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 378 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
378, 378378, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 379 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
379, 379379, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 380 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
380, 380380, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 381 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
381, 381381, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 382 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
382, 382382, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 383 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
383, 383383, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 384 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
384, 384384, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 385 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
385, 385385, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 386 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
386, 386386, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 387 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
387, 387387, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 388 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
388, 388388, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 389 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
389, 389389, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 390 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
390, 390390, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 391 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
391, 391391, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 392 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
392, 392392, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 393 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
393, 393393, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 394 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
394, 394394, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 395 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
395, 395395, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 396 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
396, 396396, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 397 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
397, 397397, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 398 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
398, 398398, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 399 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
399, 399399, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 400 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
400, 400400, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 401 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
401, 401401, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 402 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
402, 402402, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 403 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
403, 403403, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 404 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
404, 404404, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 405 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
405, 405405, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 406 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
406, 406406, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 407 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
407, 407407, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 408 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
408, 408408, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 409 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
409, 409409, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 410 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
410, 410410, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 411 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
411, 411411, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 412 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
412, 412412, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 413 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
413, 413413, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 414 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
414, 414414, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 415 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
415, 415415, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 416 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
416, 416416, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 417 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
417, 417417, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 418 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
418, 418418, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 419 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
419, 419419, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 420 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
420, 420420, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 421 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
421, 421421, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 422 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
422, 422422, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 423 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
423, 423423, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 424 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
424, 424424, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 425 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
425, 425425, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 426 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
426, 426426, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 427 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
427, 427427, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 428 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
428, 428428, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 429 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
429, 429429, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 430 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
430, 430430, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 431 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
431, 431431, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 432 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
432, 432432, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 433 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
433, 433433, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 434 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
434, 434434, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 435 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
435, 435435, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 436 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
436, 436436, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 437 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
437, 437437, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 438 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
438, 438438, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 439 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
439, 439439, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 440 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
440, 440440, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 441 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
441, 441441, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 442 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
442, 442442, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 443 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
443, 443443, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 444 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
444, 444444, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 445 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
445, 445445, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 446 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
446, 446446, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 447 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
447, 447447, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 448 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
448, 448448, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 449 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
449, 449449, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 450 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
450, 450450, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 451 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
451, 451451, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 452 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
452, 452452, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 453 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
453, 453453, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 454 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
454, 454454, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 455 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
455, 455455, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 456 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
456, 456456, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 457 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
457, 457457, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 458 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
458, 458458, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 459 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
459, 459459, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 460 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
460, 460460, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 461 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
461, 461461, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 462 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
462, 462462, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 463 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
463, 463463, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 464 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
464, 464464, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 465 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
465, 465465, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 466 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
466, 466466, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 467 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
467, 467467, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 468 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
468, 468468, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 469 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
469, 469469, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 470 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
470, 470470, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 471 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
471, 471471, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 472 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
472, 472472, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 473 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
473, 473473, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 474 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
474, 474474, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 475 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
475, 475475, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 476 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
476, 476476, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 477 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
477, 477477, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 478 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
478, 478478, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 479 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
479, 479479, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 480 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
480, 480480, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 481 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
481, 481481, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 482 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
482, 482482, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 483 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
483, 483483, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 484 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
484, 484484, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 485 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
485, 485485, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 486 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
486, 486486, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 487 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
487, 487487, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 488 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
488, 488488, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 489 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
489, 489489, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 490 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
490, 490490, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 491 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
491, 491491, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 492 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
492, 492492, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 493 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
493, 493493, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 494 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
494, 494494, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 495 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
495, 495495, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 496 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
496, 496496, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 497 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
497, 497497, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 498 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
498, 498498, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 499 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
499, 499499, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 500 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
500, 500500, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Coupe'
);

/* INSERT QUERY NO: 501 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
501, 501501, TO_DATE('4/2/1998','DD/MM/YYYY'), TO_DATE('4/2/2000','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 502 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
502, 502502, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 503 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
503, 503503, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 504 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
504, 504504, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 505 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
505, 505505, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 506 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
506, 506506, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 507 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
507, 507507, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 508 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
508, 508508, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 509 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
509, 509509, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 510 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
510, 510510, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 511 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
511, 511511, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 512 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
512, 512512, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 513 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
513, 513513, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 514 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
514, 514514, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 515 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
515, 515515, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 516 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
516, 516516, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 517 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
517, 517517, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 518 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
518, 518518, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 519 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
519, 519519, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 520 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
520, 520520, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 521 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
521, 521521, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 522 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
522, 522522, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 523 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
523, 523523, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 524 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
524, 524524, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 525 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
525, 525525, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 526 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
526, 526526, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 527 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
527, 527527, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 528 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
528, 528528, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 529 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
529, 529529, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 530 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
530, 530530, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 531 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
531, 531531, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 532 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
532, 532532, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 533 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
533, 533533, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 534 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
534, 534534, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 535 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
535, 535535, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 536 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
536, 536536, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 537 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
537, 537537, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 538 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
538, 538538, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 539 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
539, 539539, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 540 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
540, 540540, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 541 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
541, 541541, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 542 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
542, 542542, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 543 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
543, 543543, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 544 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
544, 544544, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 545 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
545, 545545, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 546 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
546, 546546, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 547 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
547, 547547, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 548 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
548, 548548, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 549 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
549, 549549, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 550 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
550, 550550, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 551 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
551, 551551, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 552 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
552, 552552, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 553 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
553, 553553, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 554 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
554, 554554, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 555 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
555, 555555, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 556 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
556, 556556, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 557 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
557, 557557, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 558 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
558, 558558, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 559 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
559, 559559, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 560 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
560, 560560, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 561 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
561, 561561, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 562 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
562, 562562, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 563 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
563, 563563, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 564 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
564, 564564, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 565 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
565, 565565, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 566 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
566, 566566, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 567 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
567, 567567, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 568 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
568, 568568, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 569 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
569, 569569, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 570 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
570, 570570, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 571 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
571, 571571, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 572 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
572, 572572, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 573 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
573, 573573, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 574 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
574, 574574, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 575 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
575, 575575, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 576 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
576, 576576, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 577 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
577, 577577, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 578 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
578, 578578, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 579 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
579, 579579, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 580 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
580, 580580, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 581 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
581, 581581, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 582 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
582, 582582, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 583 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
583, 583583, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 584 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
584, 584584, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 585 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
585, 585585, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 586 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
586, 586586, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 587 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
587, 587587, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 588 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
588, 588588, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 589 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
589, 589589, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 590 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
590, 590590, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 591 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
591, 591591, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 592 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
592, 592592, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 593 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
593, 593593, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 594 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
594, 594594, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 595 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
595, 595595, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 596 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
596, 596596, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 597 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
597, 597597, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 598 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
598, 598598, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 599 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
599, 599599, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 600 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
600, 600600, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 601 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
601, 601601, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 602 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
602, 602602, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 603 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
603, 603603, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 604 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
604, 604604, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 605 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
605, 605605, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 606 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
606, 606606, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 607 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
607, 607607, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 608 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
608, 608608, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 609 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
609, 609609, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 610 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
610, 610610, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 611 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
611, 611611, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 612 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
612, 612612, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 613 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
613, 613613, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 614 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
614, 614614, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 615 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
615, 615615, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 616 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
616, 616616, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 617 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
617, 617617, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 618 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
618, 618618, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 619 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
619, 619619, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 620 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
620, 620620, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 621 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
621, 621621, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 622 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
622, 622622, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 623 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
623, 623623, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 624 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
624, 624624, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 625 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
625, 625625, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 626 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
626, 626626, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 627 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
627, 627627, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 628 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
628, 628628, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 629 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
629, 629629, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 630 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
630, 630630, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 631 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
631, 631631, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 632 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
632, 632632, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 633 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
633, 633633, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 634 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
634, 634634, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 635 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
635, 635635, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 636 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
636, 636636, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 637 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
637, 637637, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 638 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
638, 638638, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 639 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
639, 639639, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 640 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
640, 640640, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 641 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
641, 641641, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 642 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
642, 642642, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 643 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
643, 643643, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 644 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
644, 644644, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 645 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
645, 645645, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 646 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
646, 646646, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 647 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
647, 647647, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 648 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
648, 648648, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 649 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
649, 649649, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 650 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
650, 650650, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 651 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
651, 651651, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 652 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
652, 652652, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 653 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
653, 653653, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 654 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
654, 654654, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 655 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
655, 655655, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 656 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
656, 656656, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 657 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
657, 657657, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 658 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
658, 658658, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 659 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
659, 659659, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 660 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
660, 660660, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 661 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
661, 661661, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 662 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
662, 662662, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 663 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
663, 663663, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 664 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
664, 664664, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 665 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
665, 665665, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 666 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
666, 666666, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 667 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
667, 667667, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 668 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
668, 668668, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 669 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
669, 669669, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 670 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
670, 670670, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 671 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
671, 671671, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 672 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
672, 672672, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 673 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
673, 673673, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 674 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
674, 674674, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 675 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
675, 675675, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 676 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
676, 676676, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 677 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
677, 677677, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 678 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
678, 678678, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 679 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
679, 679679, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 680 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
680, 680680, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 681 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
681, 681681, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 682 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
682, 682682, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 683 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
683, 683683, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 684 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
684, 684684, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 685 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
685, 685685, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 686 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
686, 686686, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 687 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
687, 687687, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 688 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
688, 688688, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 689 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
689, 689689, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 690 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
690, 690690, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 691 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
691, 691691, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 692 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
692, 692692, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 693 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
693, 693693, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 694 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
694, 694694, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 695 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
695, 695695, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 696 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
696, 696696, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 697 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
697, 697697, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 698 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
698, 698698, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 699 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
699, 699699, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 700 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
700, 700700, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 701 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
701, 701701, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 702 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
702, 702702, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 703 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
703, 703703, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 704 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
704, 704704, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 705 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
705, 705705, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 706 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
706, 706706, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 707 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
707, 707707, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 708 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
708, 708708, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 709 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
709, 709709, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 710 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
710, 710710, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 711 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
711, 711711, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 712 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
712, 712712, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 713 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
713, 713713, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 714 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
714, 714714, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 715 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
715, 715715, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 716 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
716, 716716, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 717 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
717, 717717, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 718 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
718, 718718, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 719 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
719, 719719, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 720 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
720, 720720, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 721 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
721, 721721, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 722 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
722, 722722, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 723 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
723, 723723, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 724 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
724, 724724, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 725 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
725, 725725, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 726 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
726, 726726, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 727 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
727, 727727, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 728 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
728, 728728, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 729 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
729, 729729, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 730 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
730, 730730, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 731 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
731, 731731, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 732 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
732, 732732, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 733 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
733, 733733, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 734 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
734, 734734, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 735 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
735, 735735, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 736 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
736, 736736, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 737 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
737, 737737, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 738 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
738, 738738, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 739 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
739, 739739, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 740 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
740, 740740, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 741 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
741, 741741, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 742 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
742, 742742, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 743 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
743, 743743, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 744 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
744, 744744, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 745 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
745, 745745, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 746 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
746, 746746, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 747 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
747, 747747, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 748 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
748, 748748, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 749 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
749, 749749, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 750 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
750, 750750, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 751 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
751, 751751, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 752 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
752, 752752, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 753 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
753, 753753, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 754 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
754, 754754, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 755 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
755, 755755, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 756 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
756, 756756, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 757 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
757, 757757, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 758 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
758, 758758, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 759 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
759, 759759, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 760 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
760, 760760, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 761 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
761, 761761, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 762 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
762, 762762, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 763 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
763, 763763, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 764 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
764, 764764, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 765 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
765, 765765, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 766 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
766, 766766, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 767 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
767, 767767, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 768 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
768, 768768, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 769 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
769, 769769, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 770 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
770, 770770, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 771 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
771, 771771, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 772 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
772, 772772, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 773 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
773, 773773, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 774 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
774, 774774, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 775 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
775, 775775, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 776 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
776, 776776, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 777 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
777, 777777, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 778 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
778, 778778, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 779 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
779, 779779, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 780 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
780, 780780, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 781 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
781, 781781, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 782 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
782, 782782, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 783 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
783, 783783, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 784 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
784, 784784, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 785 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
785, 785785, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 786 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
786, 786786, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 787 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
787, 787787, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 788 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
788, 788788, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 789 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
789, 789789, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 790 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
790, 790790, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 791 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
791, 791791, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 792 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
792, 792792, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 793 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
793, 793793, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 794 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
794, 794794, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 795 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
795, 795795, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 796 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
796, 796796, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 797 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
797, 797797, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 798 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
798, 798798, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 799 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
799, 799799, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 800 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
800, 800800, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 801 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
801, 801801, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 802 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
802, 802802, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 803 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
803, 803803, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 804 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
804, 804804, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 805 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
805, 805805, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 806 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
806, 806806, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 807 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
807, 807807, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 808 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
808, 808808, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 809 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
809, 809809, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 810 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
810, 810810, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 811 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
811, 811811, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 812 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
812, 812812, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 813 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
813, 813813, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 814 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
814, 814814, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 815 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
815, 815815, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 816 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
816, 816816, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 817 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
817, 817817, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 818 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
818, 818818, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 819 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
819, 819819, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 820 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
820, 820820, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 821 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
821, 821821, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 822 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
822, 822822, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 823 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
823, 823823, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 824 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
824, 824824, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 825 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
825, 825825, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 826 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
826, 826826, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 827 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
827, 827827, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 828 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
828, 828828, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 829 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
829, 829829, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 830 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
830, 830830, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 831 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
831, 831831, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 832 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
832, 832832, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 833 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
833, 833833, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 834 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
834, 834834, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 835 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
835, 835835, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 836 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
836, 836836, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 837 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
837, 837837, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);


/* INSERT QUERY NO: 839 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
839, 839839, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 840 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
840, 840840, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 841 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
841, 841841, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 842 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
842, 842842, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 843 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
843, 843843, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 844 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
844, 844844, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 845 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
845, 845845, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 846 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
846, 846846, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 847 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
847, 847847, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 848 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
848, 848848, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 849 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
849, 849849, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 850 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
850, 850850, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 851 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
851, 851851, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 852 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
852, 852852, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 853 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
853, 853853, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 854 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
854, 854854, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 855 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
855, 855855, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 856 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
856, 856856, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 857 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
857, 857857, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 858 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
858, 858858, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 859 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
859, 859859, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 860 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
860, 860860, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 861 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
861, 861861, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 862 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
862, 862862, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 863 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
863, 863863, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 864 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
864, 864864, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 865 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
865, 865865, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 866 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
866, 866866, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 867 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
867, 867867, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 868 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
868, 868868, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 869 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
869, 869869, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 870 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
870, 870870, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 871 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
871, 871871, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 872 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
872, 872872, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 873 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
873, 873873, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 874 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
874, 874874, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 875 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
875, 875875, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 876 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
876, 876876, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 877 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
877, 877877, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 878 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
878, 878878, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 879 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
879, 879879, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 880 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
880, 880880, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 881 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
881, 881881, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 882 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
882, 882882, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 883 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
883, 883883, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 884 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
884, 884884, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 885 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
885, 885885, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 886 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
886, 886886, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 887 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
887, 887887, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 888 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
888, 888888, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 889 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
889, 889889, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 890 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
890, 890890, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 891 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
891, 891891, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 892 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
892, 892892, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 893 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
893, 893893, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 894 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
894, 894894, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 895 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
895, 895895, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 896 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
896, 896896, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 897 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
897, 897897, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 898 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
898, 898898, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 899 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
899, 899899, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 900 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
900, 900900, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 901 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
901, 901901, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 902 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
902, 902902, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 903 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
903, 903903, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 904 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
904, 904904, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 905 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
905, 905905, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 906 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
906, 906906, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 907 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
907, 907907, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 908 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
908, 908908, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 909 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
909, 909909, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 910 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
910, 910910, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 911 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
911, 911911, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 912 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
912, 912912, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 913 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
913, 913913, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 914 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
914, 914914, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 915 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
915, 915915, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 916 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
916, 916916, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 917 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
917, 917917, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 918 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
918, 918918, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 919 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
919, 919919, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 920 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
920, 920920, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 921 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
921, 921921, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 922 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
922, 922922, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 923 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
923, 923923, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 924 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
924, 924924, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 925 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
925, 925925, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 926 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
926, 926926, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 927 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
927, 927927, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 928 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
928, 928928, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 929 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
929, 929929, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 930 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
930, 930930, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 931 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
931, 931931, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 932 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
932, 932932, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 933 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
933, 933933, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 934 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
934, 934934, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 935 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
935, 935935, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 936 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
936, 936936, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 937 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
937, 937937, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 938 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
938, 938938, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 939 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
939, 939939, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 940 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
940, 940940, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 941 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
941, 941941, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 942 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
942, 942942, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 943 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
943, 943943, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 944 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
944, 944944, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 945 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
945, 945945, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 946 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
946, 946946, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 947 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
947, 947947, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 948 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
948, 948948, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 949 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
949, 949949, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 950 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
950, 950950, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 951 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
951, 951951, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 952 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
952, 952952, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 953 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
953, 953953, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 954 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
954, 954954, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 955 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
955, 955955, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 956 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
956, 956956, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 957 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
957, 957957, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 958 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
958, 958958, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 959 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
959, 959959, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 960 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
960, 960960, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 961 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
961, 961961, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 962 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
962, 962962, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 963 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
963, 963963, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 964 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
964, 964964, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 965 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
965, 965965, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 966 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
966, 966966, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 967 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
967, 967967, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 968 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
968, 968968, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 969 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
969, 969969, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 970 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
970, 970970, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 971 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
971, 971971, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 972 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
972, 972972, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 973 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
973, 973973, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 974 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
974, 974974, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 975 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
975, 975975, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 976 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
976, 976976, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 977 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
977, 977977, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 978 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
978, 978978, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 979 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
979, 979979, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 980 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
980, 980980, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 981 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
981, 981981, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 982 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
982, 982982, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 983 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
983, 983983, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 984 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
984, 984984, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 985 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
985, 985985, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 986 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
986, 986986, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 987 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
987, 987987, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 988 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
988, 988988, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 989 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
989, 989989, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 990 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
990, 990990, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 991 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
991, 991991, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 992 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
992, 992992, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 993 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
993, 993993, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 994 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
994, 994994, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 995 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
995, 995995, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 996 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
996, 996996, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 997 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
997, 997997, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 998 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
998, 998998, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 999 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
999, 999999, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);

/* INSERT QUERY NO: 1000 */
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion)
VALUES
(
1000, 10001000, TO_DATE('4/2/1999','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan'
);
