/* Showing results for ABOGADO.xlsx */

/* INSERT QUERY NO: 1 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
100000, 'TR100000', 'Chuck', 'Imm', 8858189875, 'cimm0@cloudflare.com'
);

/* INSERT QUERY NO: 2 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
100100, 'TR100100', 'Ethelbert', 'Obray', 3728857741, 'eobray1@addthis.com'
);

/* INSERT QUERY NO: 3 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
100200, 'TR100200', 'Hagen', 'Feaviour', 9759363486, 'hfeaviour2@irs.gov'
);

/* INSERT QUERY NO: 4 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
100300, 'TR100300', 'Erna', 'Symmons', 8041431163, 'esymmons3@zdnet.com'
);

/* INSERT QUERY NO: 5 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
100400, 'TR100400', 'Alie', 'Asif', 6975368835, 'aasif4@netscape.com'
);

/* INSERT QUERY NO: 6 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
100500, 'TR100500', 'Jaimie', 'Kivlehan', 8473856890, 'jkivlehan5@seesaa.net'
);

/* INSERT QUERY NO: 7 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
100600, 'TR100600', 'Giacinta', 'Winslett', 9623485388, 'gwinslett6@narod.ru'
);

/* INSERT QUERY NO: 8 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
100700, 'TR100700', 'Blondell', 'Muirden', 4972602224, 'bmuirden7@mac.com'
);

/* INSERT QUERY NO: 9 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
100800, 'TR100800', 'Willy', 'Fronsek', 8802329470, 'wfronsek8@shareasale.com'
);

/* INSERT QUERY NO: 10 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
100900, 'TR100900', 'Nettie', 'Benadette', 7852503333, 'nbenadette9@a8.net'
);

/* INSERT QUERY NO: 11 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
101000, 'TR101000', 'Tarra', 'Minthorpe', 4634789087, 'tminthorpea@wordpress.com'
);

/* INSERT QUERY NO: 12 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
101100, 'TR101100', 'Claudian', 'Blooman', 6039952426, 'cbloomanb@artisteer.com'
);

/* INSERT QUERY NO: 13 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
101200, 'TR101200', 'Jeremie', 'Bingham', 8568401055, 'jbinghamc@moonfruit.com'
);

/* INSERT QUERY NO: 14 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
101300, 'TR101300', 'Brendis', 'Sotham', 1222911084, 'bsothamd@wikimedia.org'
);

/* INSERT QUERY NO: 15 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
101400, 'TR101400', 'Wilt', 'Grieg', 5357429451, 'wgriege@techcrunch.com'
);

/* INSERT QUERY NO: 16 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
101500, 'TR101500', 'Derrek', 'Postin', 1747753699, 'dpostinf@patch.com'
);

/* INSERT QUERY NO: 17 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
101600, 'TR101600', 'Hubey', 'Crawley', 2105220195, 'hcrawleyg@gnu.org'
);

/* INSERT QUERY NO: 18 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
101700, 'TR101700', 'Amberly', 'Goodman', 7657124126, 'agoodmanh@narod.ru'
);

/* INSERT QUERY NO: 19 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
101800, 'TR101800', 'Dreddy', 'Jacson', 2455772250, 'djacsoni@barnesandnoble.com'
);

/* INSERT QUERY NO: 20 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
101900, 'TR101900', 'Vachel', 'Westhead', 5319168704, 'vwestheadj@patch.com'
);

/* INSERT QUERY NO: 21 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
102000, 'TR102000', 'Helenka', 'Levinge', 2915280169, 'hlevingek@smugmug.com'
);

/* INSERT QUERY NO: 22 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
102100, 'TR102100', 'Samaria', 'Pechold', 6218249780, 'specholdl@bigcartel.com'
);

/* INSERT QUERY NO: 23 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
102200, 'TR102200', 'Tucky', 'Bruckman', 5528262894, 'tbruckmanm@vinaora.com'
);

/* INSERT QUERY NO: 24 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
102300, 'TR102300', 'Dodie', 'Harbron', 8046993284, 'dharbronn@lycos.com'
);

/* INSERT QUERY NO: 25 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
102400, 'TR102400', 'Gayla', 'Methven', 7499539001, 'gmethveno@hostgator.com'
);

/* INSERT QUERY NO: 26 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
102500, 'TR102500', 'Costanza', 'Cantua', 5444173563, 'ccantuap@naver.com'
);

/* INSERT QUERY NO: 27 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
102600, 'TR102600', 'Mikael', 'Skullet', 5092047097, 'mskulletq@ca.gov'
);

/* INSERT QUERY NO: 28 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
102700, 'TR102700', 'Clare', 'Lavers', 3767568512, 'claversr@tiny.cc'
);

/* INSERT QUERY NO: 29 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
102800, 'TR102800', 'Lawton', 'Maciaszczyk', 2131579761, 'lmaciaszczyks@yolasite.com'
);

/* INSERT QUERY NO: 30 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
102900, 'TR102900', 'Birgit', 'Nockolds', 6753198669, 'bnockoldst@biglobe.ne.jp'
);

/* INSERT QUERY NO: 31 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
103000, 'TR103000', 'Selia', 'Muller', 9684603612, 'smulleru@sun.com'
);

/* INSERT QUERY NO: 32 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
103100, 'TR103100', 'Anya', 'Clemenzi', 3966753133, 'aclemenziv@earthlink.net'
);

/* INSERT QUERY NO: 33 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
103200, 'TR103200', 'Otho', 'Ramel', 5128229415, 'oramelw@joomla.org'
);

/* INSERT QUERY NO: 34 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
103300, 'TR103300', 'Walther', 'Pill', 7393050399, 'wpillx@google.fr'
);

/* INSERT QUERY NO: 35 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
103400, 'TR103400', 'Emmott', 'Djurevic', 9127745745, 'edjurevicy@ezinearticles.com'
);

/* INSERT QUERY NO: 36 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
103500, 'TR103500', 'Felizio', 'Boycott', 7537498119, 'fboycottz@bbb.org'
);

/* INSERT QUERY NO: 37 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
103600, 'TR103600', 'Renato', 'Broose', 6931503801, 'rbroose10@ovh.net'
);

/* INSERT QUERY NO: 38 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
103700, 'TR103700', 'Camile', 'Struijs', 8433561789, 'cstruijs11@msu.edu'
);

/* INSERT QUERY NO: 39 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
103800, 'TR103800', 'Bill', 'Rowntree', 1593552500, 'browntree12@csmonitor.com'
);

/* INSERT QUERY NO: 40 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
103900, 'TR103900', 'Sly', 'Mc Caughan', 1574701705, 'smccaughan13@timesonline.co.uk'
);

/* INSERT QUERY NO: 41 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
104000, 'TR104000', 'Joelynn', 'Marthen', 6924479856, 'jmarthen14@accuweather.com'
);

/* INSERT QUERY NO: 42 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
104100, 'TR104100', 'Lyndsie', 'Pampling', 9846162416, 'lpampling15@seesaa.net'
);

/* INSERT QUERY NO: 43 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
104200, 'TR104200', 'Kati', 'Desporte', 9135565299, 'kdesporte16@gmpg.org'
);

/* INSERT QUERY NO: 44 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
104300, 'TR104300', 'Berne', 'Reinger', 1245790100, 'breinger17@tiny.cc'
);

/* INSERT QUERY NO: 45 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
104400, 'TR104400', 'Eulalie', 'Paolino', 2423286111, 'epaolino18@topsy.com'
);

/* INSERT QUERY NO: 46 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
104500, 'TR104500', 'Cleveland', 'Wholesworth', 4292559741, 'cwholesworth19@about.com'
);

/* INSERT QUERY NO: 47 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
104600, 'TR104600', 'Joline', 'Wilderspoon', 4827049481, 'jwilderspoon1a@netlog.com'
);

/* INSERT QUERY NO: 48 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
104700, 'TR104700', 'Francklin', 'Gouly', 3069314462, 'fgouly1b@mit.edu'
);

/* INSERT QUERY NO: 49 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
104800, 'TR104800', 'Inglis', 'Syddall', 5845549206, 'isyddall1c@usnews.com'
);

/* INSERT QUERY NO: 50 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
104900, 'TR104900', 'Clay', 'Eskrigg', 4522847135, 'ceskrigg1d@epa.gov'
);

/* INSERT QUERY NO: 51 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
105000, 'TR105000', 'Susette', 'Gerlts', 1886991429, 'sgerlts1e@yale.edu'
);

/* INSERT QUERY NO: 52 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
105100, 'TR105100', 'Brandi', 'Phillot', 3581847632, 'bphillot1f@deviantart.com'
);

/* INSERT QUERY NO: 53 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
105200, 'TR105200', 'Channa', 'Sell', 2761981670, 'csell1g@abc.net.au'
);

/* INSERT QUERY NO: 54 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
105300, 'TR105300', 'Gannon', 'Furbank', 6411778897, 'gfurbank1h@alibaba.com'
);

/* INSERT QUERY NO: 55 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
105400, 'TR105400', 'Patsy', 'Makey', 3628807714, 'pmakey1i@japanpost.jp'
);

/* INSERT QUERY NO: 56 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
105500, 'TR105500', 'Cirillo', 'John', 7709293465, 'cjohn1j@desdev.cn'
);

/* INSERT QUERY NO: 57 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
105600, 'TR105600', 'Hersch', 'Ruste', 2076663630, 'hruste1k@reference.com'
);

/* INSERT QUERY NO: 58 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
105700, 'TR105700', 'Babb', 'Mashal', 6995775238, 'bmashal1l@dmoz.org'
);

/* INSERT QUERY NO: 59 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
105800, 'TR105800', 'Donovan', 'McGarrity', 2296560584, 'dmcgarrity1m@blinklist.com'
);

/* INSERT QUERY NO: 60 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
105900, 'TR105900', 'Chelsae', 'Crum', 4382249175, 'ccrum1n@wikia.com'
);

/* INSERT QUERY NO: 61 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
106000, 'TR106000', 'Adela', 'Panas', 3803006351, 'apanas1o@microsoft.com'
);

/* INSERT QUERY NO: 62 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
106100, 'TR106100', 'Brandie', 'Niave', 9309852734, 'bniave1p@google.co.uk'
);

/* INSERT QUERY NO: 63 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
106200, 'TR106200', 'Bendick', 'Rumbelow', 1708062928, 'brumbelow1q@ycombinator.com'
);

/* INSERT QUERY NO: 64 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
106300, 'TR106300', 'Agosto', 'Mimmack', 7454165558, 'amimmack1r@house.gov'
);

/* INSERT QUERY NO: 65 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
106400, 'TR106400', 'Mitchel', 'Scarfe', 2199174768, 'mscarfe1s@dmoz.org'
);

/* INSERT QUERY NO: 66 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
106500, 'TR106500', 'Kimberlee', 'Gapper', 9716675436, 'kgapper1t@usatoday.com'
);

/* INSERT QUERY NO: 67 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
106600, 'TR106600', 'Goldie', 'Parley', 2152077443, 'gparley1u@infoseek.co.jp'
);

/* INSERT QUERY NO: 68 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
106700, 'TR106700', 'Howey', 'Dewdney', 2578521332, 'hdewdney1v@census.gov'
);

/* INSERT QUERY NO: 69 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
106800, 'TR106800', 'Chadd', 'Hackley', 4768071133, 'chackley1w@cmu.edu'
);

/* INSERT QUERY NO: 70 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
106900, 'TR106900', 'Lynette', 'Halvosen', 6292432602, 'lhalvosen1x@sfgate.com'
);

/* INSERT QUERY NO: 71 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
107000, 'TR107000', 'Cassie', 'Reasun', 6999937828, 'creasun1y@cnet.com'
);

/* INSERT QUERY NO: 72 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
107100, 'TR107100', 'Lawton', 'Josefsen', 6506562689, 'ljosefsen1z@yellowpages.com'
);

/* INSERT QUERY NO: 73 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
107200, 'TR107200', 'Burt', 'Van Merwe', 5009139547, 'bvanmerwe20@people.com.cn'
);

/* INSERT QUERY NO: 74 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
107300, 'TR107300', 'Ailee', 'Lauridsen', 4535148297, 'alauridsen21@networksolutions.com'
);

/* INSERT QUERY NO: 75 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
107400, 'TR107400', 'Marlowe', 'Hazle', 3061928977, 'mhazle22@skype.com'
);

/* INSERT QUERY NO: 76 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
107500, 'TR107500', 'Ty', 'Screwton', 2162732467, 'tscrewton23@xrea.com'
);

/* INSERT QUERY NO: 77 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
107600, 'TR107600', 'Tessi', 'Genge', 3855808899, 'tgenge24@mtv.com'
);

/* INSERT QUERY NO: 78 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
107700, 'TR107700', 'Byrle', 'Bancroft', 8741811093, 'bbancroft25@gravatar.com'
);

/* INSERT QUERY NO: 79 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
107800, 'TR107800', 'Nev', 'Hullot', 7369134372, 'nhullot26@purevolume.com'
);

/* INSERT QUERY NO: 80 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
107900, 'TR107900', 'Nerti', 'Secret', 5156914337, 'nsecret27@godaddy.com'
);

/* INSERT QUERY NO: 81 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
108000, 'TR108000', 'Pieter', 'Faraday', 1315002613, 'pfaraday28@craigslist.org'
);

/* INSERT QUERY NO: 82 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
108100, 'TR108100', 'Harold', 'Backhouse', 4576675951, 'hbackhouse29@prweb.com'
);

/* INSERT QUERY NO: 83 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
108200, 'TR108200', 'Jock', 'Heselwood', 1932919956, 'jheselwood2a@ucoz.ru'
);

/* INSERT QUERY NO: 84 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
108300, 'TR108300', 'Care', 'Atterley', 4668451493, 'catterley2b@icq.com'
);

/* INSERT QUERY NO: 85 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
108400, 'TR108400', 'Lexi', 'Kidston', 3901529041, 'lkidston2c@yahoo.com'
);

/* INSERT QUERY NO: 86 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
108500, 'TR108500', 'Anissa', 'Montes', 3039684241, 'amontes2d@wunderground.com'
);

/* INSERT QUERY NO: 87 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
108600, 'TR108600', 'Kelly', 'Forre', 4518274837, 'kforre2e@sina.com.cn'
);

/* INSERT QUERY NO: 88 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
108700, 'TR108700', 'Greggory', 'Oaten', 3857919190, 'goaten2f@ed.gov'
);

/* INSERT QUERY NO: 89 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
108800, 'TR108800', 'Susann', 'Ryson', 8825033171, 'sryson2g@census.gov'
);

/* INSERT QUERY NO: 90 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
108900, 'TR108900', 'Ryon', 'Olivello', 7701794150, 'rolivello2h@a8.net'
);

/* INSERT QUERY NO: 91 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
109000, 'TR109000', 'Esra', 'Lunge', 5495682814, 'elunge2i@webmd.com'
);

/* INSERT QUERY NO: 92 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
109100, 'TR109100', 'Deb', 'Brumham', 9915004491, 'dbrumham2j@seesaa.net'
);

/* INSERT QUERY NO: 93 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
109200, 'TR109200', 'Nancee', 'Mecchi', 6902969852, 'nmecchi2k@google.nl'
);

/* INSERT QUERY NO: 94 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
109300, 'TR109300', 'Saunder', 'Bamfield', 5375845543, 'sbamfield2l@tinyurl.com'
);

/* INSERT QUERY NO: 95 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
109400, 'TR109400', 'Hermie', 'Tenbrug', 3047797729, 'htenbrug2m@cbc.ca'
);

/* INSERT QUERY NO: 96 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
109500, 'TR109500', 'Shanda', 'Paffitt', 6925055383, 'spaffitt2n@nasa.gov'
);

/* INSERT QUERY NO: 97 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
109600, 'TR109600', 'Berky', 'Springer', 9799496204, 'bspringer2o@hexun.com'
);

/* INSERT QUERY NO: 98 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
109700, 'TR109700', 'Jedediah', 'Ord', 9927581226, 'jord2p@usda.gov'
);

/* INSERT QUERY NO: 99 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
109800, 'TR109800', 'Andras', 'Goodyear', 9944679978, 'agoodyear2q@bbc.co.uk'
);

/* INSERT QUERY NO: 100 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
109900, 'TR109900', 'Konstanze', 'Zylbermann', 2491495731, 'kzylbermann2r@java.com'
);

/* INSERT QUERY NO: 101 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
110000, 'TR110000', 'Raynell', 'Hartwell', 1223047331, 'rhartwell2s@surveymonkey.com'
);

/* INSERT QUERY NO: 102 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
110100, 'TR110100', 'Willette', 'Charnock', 7349700969, 'wcharnock2t@qq.com'
);

/* INSERT QUERY NO: 103 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
110200, 'TR110200', 'Julian', 'Eddicott', 6446347192, 'jeddicott2u@hao123.com'
);

/* INSERT QUERY NO: 104 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
110300, 'TR110300', 'Clarice', 'Hun', 8611473685, 'chun2v@4shared.com'
);

/* INSERT QUERY NO: 105 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
110400, 'TR110400', 'Brander', 'Udell', 1492480769, 'budell2w@ebay.co.uk'
);

/* INSERT QUERY NO: 106 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
110500, 'TR110500', 'Myrtia', 'Epton', 3966453212, 'mepton2x@purevolume.com'
);

/* INSERT QUERY NO: 107 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
110600, 'TR110600', 'Chandra', 'Wooldridge', 1786789586, 'cwooldridge2y@ehow.com'
);

/* INSERT QUERY NO: 108 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
110700, 'TR110700', 'Jania', 'Levings', 7734702999, 'jlevings2z@un.org'
);

/* INSERT QUERY NO: 109 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
110800, 'TR110800', 'Rania', 'Finnes', 9167721114, 'rfinnes30@wsj.com'
);

/* INSERT QUERY NO: 110 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
110900, 'TR110900', 'Alex', 'Caulcutt', 5535337763, 'acaulcutt31@howstuffworks.com'
);

/* INSERT QUERY NO: 111 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
111000, 'TR111000', 'Erskine', 'OHenecan', 7891578133, 'eohenecan32@livejournal.com'
);

/* INSERT QUERY NO: 112 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
111100, 'TR111100', 'Lincoln', 'Dionsetti', 4151093937, 'ldionsetti33@github.com'
);

/* INSERT QUERY NO: 113 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
111200, 'TR111200', 'Roley', 'Tanby', 9861990597, 'rtanby34@harvard.edu'
);

/* INSERT QUERY NO: 114 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
111300, 'TR111300', 'Sarge', 'Piff', 1576820741, 'spiff35@cloudflare.com'
);

/* INSERT QUERY NO: 115 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
111400, 'TR111400', 'Sawyer', 'Runnicles', 7813649993, 'srunnicles36@archive.org'
);

/* INSERT QUERY NO: 116 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
111500, 'TR111500', 'Tamiko', 'Ioannou', 8422640446, 'tioannou37@chicagotribune.com'
);

/* INSERT QUERY NO: 117 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
111600, 'TR111600', 'Kaila', 'Girt', 1426788972, 'kgirt38@earthlink.net'
);

/* INSERT QUERY NO: 118 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
111700, 'TR111700', 'Ronald', 'McMurty', 4503754021, 'rmcmurty39@example.com'
);

/* INSERT QUERY NO: 119 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
111800, 'TR111800', 'Jodee', 'Climer', 7116935649, 'jclimer3a@amazon.de'
);

/* INSERT QUERY NO: 120 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
111900, 'TR111900', 'Myrlene', 'Huzzey', 7302704339, 'mhuzzey3b@stanford.edu'
);

/* INSERT QUERY NO: 121 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
112000, 'TR112000', 'Chucho', 'Jirick', 4175446730, 'cjirick3c@umich.edu'
);

/* INSERT QUERY NO: 122 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
112100, 'TR112100', 'Tedie', 'Nowakowski', 2638492178, 'tnowakowski3d@ox.ac.uk'
);

/* INSERT QUERY NO: 123 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
112200, 'TR112200', 'Bambi', 'Ornillos', 6648474511, 'bornillos3e@npr.org'
);

/* INSERT QUERY NO: 124 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
112300, 'TR112300', 'Nollie', 'Peasey', 9346338091, 'npeasey3f@google.es'
);

/* INSERT QUERY NO: 125 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
112400, 'TR112400', 'Fredra', 'Wickerson', 9474963771, 'fwickerson3g@imgur.com'
);

/* INSERT QUERY NO: 126 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
112500, 'TR112500', 'Verile', 'Epton', 5466345027, 'vepton3h@mediafire.com'
);

/* INSERT QUERY NO: 127 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
112600, 'TR112600', 'Lindon', 'Spurret', 3099524893, 'lspurret3i@yelp.com'
);

/* INSERT QUERY NO: 128 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
112700, 'TR112700', 'Patin', 'Mobius', 5727755024, 'pmobius3j@va.gov'
);

/* INSERT QUERY NO: 129 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
112800, 'TR112800', 'Yoshiko', 'Jammes', 9244856759, 'yjammes3k@yellowbook.com'
);

/* INSERT QUERY NO: 130 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
112900, 'TR112900', 'Boy', 'Semorad', 7506378911, 'bsemorad3l@skyrock.com'
);

/* INSERT QUERY NO: 131 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
113000, 'TR113000', 'Koressa', 'Corbally', 4808147556, 'kcorbally3m@nsw.gov.au'
);

/* INSERT QUERY NO: 132 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
113100, 'TR113100', 'Aarika', 'Kidman', 4411894294, 'akidman3n@jugem.jp'
);

/* INSERT QUERY NO: 133 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
113200, 'TR113200', 'Laetitia', 'Autrie', 4588662212, 'lautrie3o@webeden.co.uk'
);

/* INSERT QUERY NO: 134 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
113300, 'TR113300', 'Jayne', 'Dimberline', 4586384431, 'jdimberline3p@ifeng.com'
);

/* INSERT QUERY NO: 135 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
113400, 'TR113400', 'Gregorius', 'Bode', 2428496708, 'gbode3q@imdb.com'
);

/* INSERT QUERY NO: 136 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
113500, 'TR113500', 'Robin', 'Edling', 4526429252, 'redling3r@google.com'
);

/* INSERT QUERY NO: 137 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
113600, 'TR113600', 'Karyl', 'Ahrenius', 4246717489, 'kahrenius3s@lulu.com'
);

/* INSERT QUERY NO: 138 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
113700, 'TR113700', 'Markos', 'Fairnie', 7736332307, 'mfairnie3t@mlb.com'
);

/* INSERT QUERY NO: 139 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
113800, 'TR113800', 'Hedy', 'Ratray', 4795400820, 'hratray3u@cisco.com'
);

/* INSERT QUERY NO: 140 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
113900, 'TR113900', 'Dame', 'Crick', 4363983879, 'dcrick3v@com.com'
);

/* INSERT QUERY NO: 141 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
114000, 'TR114000', 'Luelle', 'Roony', 7953419253, 'lroony3w@fda.gov'
);

/* INSERT QUERY NO: 142 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
114100, 'TR114100', 'Aura', 'Sydry', 1132432374, 'asydry3x@dropbox.com'
);

/* INSERT QUERY NO: 143 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
114200, 'TR114200', 'Martita', 'Biesterfeld', 5063394226, 'mbiesterfeld3y@ucsd.edu'
);

/* INSERT QUERY NO: 144 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
114300, 'TR114300', 'Markos', 'Luigi', 5289112570, 'mluigi3z@google.ca'
);

/* INSERT QUERY NO: 145 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
114400, 'TR114400', 'Oralla', 'Lamburne', 4374000598, 'olamburne40@theglobeandmail.com'
);

/* INSERT QUERY NO: 146 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
114500, 'TR114500', 'Hansiain', 'Cleal', 2838700951, 'hcleal41@typepad.com'
);

/* INSERT QUERY NO: 147 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
114600, 'TR114600', 'Riva', 'Antonognoli', 3186862729, 'rantonognoli42@goodreads.com'
);

/* INSERT QUERY NO: 148 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
114700, 'TR114700', 'Pen', 'Dunphie', 2879874789, 'pdunphie43@wikispaces.com'
);

/* INSERT QUERY NO: 149 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
114800, 'TR114800', 'Pammy', 'Janas', 9899272390, 'pjanas44@tonline.de'
);

/* INSERT QUERY NO: 150 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
114900, 'TR114900', 'Jeanie', 'Sigart', 7064317592, 'jsigart45@xing.com'
);

/* INSERT QUERY NO: 151 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
115000, 'TR115000', 'Chaunce', 'Risborough', 1054602671, 'crisborough46@unc.edu'
);

/* INSERT QUERY NO: 152 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
115100, 'TR115100', 'Archibaldo', 'Tupper', 6672040887, 'atupper47@ed.gov'
);

/* INSERT QUERY NO: 153 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
115200, 'TR115200', 'Carlene', 'Enevold', 5255244534, 'cenevold48@epa.gov'
);

/* INSERT QUERY NO: 154 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
115300, 'TR115300', 'Shauna', 'Cornu', 5161236933, 'scornu49@netscape.com'
);

/* INSERT QUERY NO: 155 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
115400, 'TR115400', 'Paulie', 'Duxbarry', 2857723721, 'pduxbarry4a@deliciousdays.com'
);

/* INSERT QUERY NO: 156 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
115500, 'TR115500', 'Urban', 'Sparway', 6537807710, 'usparway4b@trellian.com'
);

/* INSERT QUERY NO: 157 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
115600, 'TR115600', 'Ianthe', 'Jeaves', 3821748705, 'ijeaves4c@quantcast.com'
);

/* INSERT QUERY NO: 158 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
115700, 'TR115700', 'Ludovico', 'Cotelard', 4006164432, 'lcotelard4d@auda.org.au'
);

/* INSERT QUERY NO: 159 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
115800, 'TR115800', 'Krisha', 'Shepherdson', 5153345182, 'kshepherdson4e@walmart.com'
);

/* INSERT QUERY NO: 160 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
115900, 'TR115900', 'Doralynn', 'Leebeter', 2496568764, 'dleebeter4f@shinystat.com'
);

/* INSERT QUERY NO: 161 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
116000, 'TR116000', 'Marjy', 'Seeger', 1403676032, 'mseeger4g@soundcloud.com'
);

/* INSERT QUERY NO: 162 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
116100, 'TR116100', 'Olympia', 'Minihan', 7786471188, 'ominihan4h@fema.gov'
);

/* INSERT QUERY NO: 163 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
116200, 'TR116200', 'Bogey', 'McPhate', 1647210153, 'bmcphate4i@1und1.de'
);

/* INSERT QUERY NO: 164 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
116300, 'TR116300', 'Constancia', 'Smissen', 6743994118, 'csmissen4j@cornell.edu'
);

/* INSERT QUERY NO: 165 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
116400, 'TR116400', 'Jack', 'Moulson', 1609564478, 'jmoulson4k@usa.gov'
);

/* INSERT QUERY NO: 166 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
116500, 'TR116500', 'Abbe', 'Stoddart', 6593396518, 'astoddart4l@hc360.com'
);

/* INSERT QUERY NO: 167 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
116600, 'TR116600', 'Tommie', 'Rousby', 1936745067, 'trousby4m@hc360.com'
);

/* INSERT QUERY NO: 168 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
116700, 'TR116700', 'Woodrow', 'Wenger', 8243938206, 'wwenger4n@usatoday.com'
);

/* INSERT QUERY NO: 169 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
116800, 'TR116800', 'Ethe', 'Reiners', 1825063858, 'ereiners4o@edublogs.org'
);

/* INSERT QUERY NO: 170 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
116900, 'TR116900', 'Marjory', 'Rustman', 9274490427, 'mrustman4p@cdc.gov'
);

/* INSERT QUERY NO: 171 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
117000, 'TR117000', 'Judy', 'Coolahan', 5677735927, 'jcoolahan4q@prnewswire.com'
);

/* INSERT QUERY NO: 172 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
117100, 'TR117100', 'Teena', 'Cady', 1471453359, 'tcady4r@t.co'
);

/* INSERT QUERY NO: 173 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
117200, 'TR117200', 'Hilary', 'Jablonski', 9389176471, 'hjablonski4s@bloglines.com'
);

/* INSERT QUERY NO: 174 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
117300, 'TR117300', 'Dorice', 'Joyson', 9296740607, 'djoyson4t@themeforest.net'
);

/* INSERT QUERY NO: 175 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
117400, 'TR117400', 'Diena', 'Test', 1913772476, 'dtest4u@pen.io'
);

/* INSERT QUERY NO: 176 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
117500, 'TR117500', 'Ellswerth', 'Mate', 4357517203, 'emate4v@overblog.com'
);

/* INSERT QUERY NO: 177 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
117600, 'TR117600', 'Roseanna', 'Bartrap', 9537177328, 'rbartrap4w@google.es'
);

/* INSERT QUERY NO: 178 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
117700, 'TR117700', 'Donni', 'Routledge', 9639042512, 'droutledge4x@census.gov'
);

/* INSERT QUERY NO: 179 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
117800, 'TR117800', 'Derrik', 'Barrell', 1773482753, 'dbarrell4y@sun.com'
);

/* INSERT QUERY NO: 180 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
117900, 'TR117900', 'Westley', 'Swindlehurst', 2234173411, 'wswindlehurst4z@trellian.com'
);

/* INSERT QUERY NO: 181 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
118000, 'TR118000', 'Jenelle', 'Schnitter', 3585343035, 'jschnitter50@aol.com'
);

/* INSERT QUERY NO: 182 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
118100, 'TR118100', 'Cirillo', 'Gookey', 2056238863, 'cgookey51@weebly.com'
);

/* INSERT QUERY NO: 183 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
118200, 'TR118200', 'Tatum', 'Hulse', 1356171799, 'thulse52@google.co.jp'
);

/* INSERT QUERY NO: 184 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
118300, 'TR118300', 'Yanaton', 'Crowder', 2444421442, 'ycrowder53@cyberchimps.com'
);

/* INSERT QUERY NO: 185 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
118400, 'TR118400', 'Kerri', 'Macconaghy', 7992130170, 'kmacconaghy54@chron.com'
);

/* INSERT QUERY NO: 186 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
118500, 'TR118500', 'Miran', 'Frawley', 1558367105, 'mfrawley55@wired.com'
);

/* INSERT QUERY NO: 187 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
118600, 'TR118600', 'Lyndel', 'Jandak', 4134459199, 'ljandak56@1und1.de'
);

/* INSERT QUERY NO: 188 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
118700, 'TR118700', 'Reider', 'Reely', 3334507615, 'rreely57@imageshack.us'
);

/* INSERT QUERY NO: 189 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
118800, 'TR118800', 'Faber', 'Eannetta', 5272247513, 'feannetta58@rediff.com'
);

/* INSERT QUERY NO: 190 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
118900, 'TR118900', 'Gal', 'Stoke', 6644301237, 'gstoke59@cornell.edu'
);

/* INSERT QUERY NO: 191 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
119000, 'TR119000', 'Fran', 'Goodley', 2583848930, 'fgoodley5a@prweb.com'
);

/* INSERT QUERY NO: 192 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
119100, 'TR119100', 'Yevette', 'Gennrich', 6429396531, 'ygennrich5b@dailymail.co.uk'
);

/* INSERT QUERY NO: 193 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
119200, 'TR119200', 'Seward', 'Housiaux', 5637254159, 'shousiaux5c@oakley.com'
);

/* INSERT QUERY NO: 194 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
119300, 'TR119300', 'Peta', 'Kenchington', 2071637353, 'pkenchington5d@cyberchimps.com'
);

/* INSERT QUERY NO: 195 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
119400, 'TR119400', 'Joellyn', 'Scobie', 8291542514, 'jscobie5e@walmart.com'
);

/* INSERT QUERY NO: 196 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
119500, 'TR119500', 'Carmelia', 'Gotecliffe', 8794174720, 'cgotecliffe5f@wisc.edu'
);

/* INSERT QUERY NO: 197 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
119600, 'TR119600', 'Roze', 'Deboick', 7135544452, 'rdeboick5g@deviantart.com'
);

/* INSERT QUERY NO: 198 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
119700, 'TR119700', 'Rice', 'Rewbottom', 5054094575, 'rrewbottom5h@netlog.com'
);

/* INSERT QUERY NO: 199 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
119800, 'TR119800', 'Marne', 'Hollow', 2821921657, 'mhollow5i@sourceforge.net'
);

/* INSERT QUERY NO: 200 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
119900, 'TR119900', 'Clarissa', 'Burren', 8983601693, 'cburren5j@ucoz.com'
);

/* INSERT QUERY NO: 201 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
120000, 'TR120000', 'Karee', 'Harriday', 4435815753, 'kharriday5k@wired.com'
);

/* INSERT QUERY NO: 202 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
120100, 'TR120100', 'Cole', 'Currier', 1192898030, 'ccurrier5l@naver.com'
);

/* INSERT QUERY NO: 203 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
120200, 'TR120200', 'Osbourne', 'Antham', 8147880953, 'oantham5m@intel.com'
);

/* INSERT QUERY NO: 204 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
120300, 'TR120300', 'Farlee', 'Fuggles', 7687912849, 'ffuggles5n@pinterest.com'
);

/* INSERT QUERY NO: 205 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
120400, 'TR120400', 'Joanne', 'Seally', 8135793769, 'jseally5o@vk.com'
);

/* INSERT QUERY NO: 206 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
120500, 'TR120500', 'Bryan', 'Birdwistle', 7989242627, 'bbirdwistle5p@webeden.co.uk'
);

/* INSERT QUERY NO: 207 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
120600, 'TR120600', 'Kerwinn', 'Knivett', 1877963058, 'kknivett5q@amazon.com'
);

/* INSERT QUERY NO: 208 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
120700, 'TR120700', 'Olly', 'House', 1449088608, 'ohouse5r@printfriendly.com'
);

/* INSERT QUERY NO: 209 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
120800, 'TR120800', 'Rae', 'Gohn', 8301627072, 'rgohn5s@bbc.co.uk'
);

/* INSERT QUERY NO: 210 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
120900, 'TR120900', 'Ana', 'Rawe', 9964414913, 'arawe5t@biglobe.ne.jp'
);

/* INSERT QUERY NO: 211 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
121000, 'TR121000', 'Kingsley', 'Gianinotti', 5241841896, 'kgianinotti5u@who.int'
);

/* INSERT QUERY NO: 212 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
121100, 'TR121100', 'Tulley', 'Gonet', 7889095294, 'tgonet5v@fc2.com'
);

/* INSERT QUERY NO: 213 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
121200, 'TR121200', 'Inge', 'Estabrook', 3675357127, 'iestabrook5w@blogspot.com'
);

/* INSERT QUERY NO: 214 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
121300, 'TR121300', 'Farly', 'Marcus', 8785614454, 'fmarcus5x@about.me'
);

/* INSERT QUERY NO: 215 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
121400, 'TR121400', 'Basil', 'Donaho', 3549265830, 'bdonaho5y@blinklist.com'
);

/* INSERT QUERY NO: 216 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
121500, 'TR121500', 'Zed', 'Chardin', 9537869742, 'zchardin5z@netscape.com'
);

/* INSERT QUERY NO: 217 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
121600, 'TR121600', 'Hyacinthia', 'Bucham', 8113343332, 'hbucham60@paginegialle.it'
);

/* INSERT QUERY NO: 218 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
121700, 'TR121700', 'Harlie', 'Winpenny', 6816251311, 'hwinpenny61@livejournal.com'
);

/* INSERT QUERY NO: 219 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
121800, 'TR121800', 'Jill', 'Nare', 7802741345, 'jnare62@apple.com'
);

/* INSERT QUERY NO: 220 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
121900, 'TR121900', 'Ernst', 'Foxon', 3448127585, 'efoxon63@abc.net.au'
);

/* INSERT QUERY NO: 221 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
122000, 'TR122000', 'Noelyn', 'Menauteau', 3887168733, 'nmenauteau64@theguardian.com'
);

/* INSERT QUERY NO: 222 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
122100, 'TR122100', 'Mady', 'Jellett', 7178707295, 'mjellett65@purevolume.com'
);

/* INSERT QUERY NO: 223 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
122200, 'TR122200', 'Ody', 'Metterick', 5634406964, 'ometterick66@va.gov'
);

/* INSERT QUERY NO: 224 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
122300, 'TR122300', 'Herculie', 'Samuels', 7729724605, 'hsamuels67@berkeley.edu'
);

/* INSERT QUERY NO: 225 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
122400, 'TR122400', 'Ingar', 'Cauldfield', 7599879375, 'icauldfield68@issuu.com'
);

/* INSERT QUERY NO: 226 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
122500, 'TR122500', 'Roscoe', 'Schubuser', 1964839846, 'rschubuser69@hao123.com'
);

/* INSERT QUERY NO: 227 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
122600, 'TR122600', 'Cissy', 'Betteson', 9342063961, 'cbetteson6a@stumbleupon.com'
);

/* INSERT QUERY NO: 228 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
122700, 'TR122700', 'Pooh', 'Noades', 9824289030, 'pnoades6b@theatlantic.com'
);

/* INSERT QUERY NO: 229 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
122800, 'TR122800', 'Mickie', 'Tomczak', 8514547460, 'mtomczak6c@shareasale.com'
);

/* INSERT QUERY NO: 230 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
122900, 'TR122900', 'Archy', 'Christescu', 5228810186, 'achristescu6d@theglobeandmail.com'
);

/* INSERT QUERY NO: 231 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
123000, 'TR123000', 'Geoffry', 'Salling', 5918570068, 'gsalling6e@hhs.gov'
);

/* INSERT QUERY NO: 232 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
123100, 'TR123100', 'West', 'Ratcliff', 6782783663, 'wratcliff6f@digg.com'
);

/* INSERT QUERY NO: 233 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
123200, 'TR123200', 'Breanne', 'Balshaw', 5141701984, 'bbalshaw6g@youtu.be'
);

/* INSERT QUERY NO: 234 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
123300, 'TR123300', 'Aldus', 'Gwinnel', 1392480319, 'agwinnel6h@instagram.com'
);

/* INSERT QUERY NO: 235 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
123400, 'TR123400', 'Bennie', 'Nijs', 7873449077, 'bnijs6i@oakley.com'
);

/* INSERT QUERY NO: 236 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
123500, 'TR123500', 'Reid', 'Sprankling', 4044401607, 'rsprankling6j@joomla.org'
);

/* INSERT QUERY NO: 237 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
123600, 'TR123600', 'Selle', 'Kryzhov', 4623144438, 'skryzhov6k@chron.com'
);

/* INSERT QUERY NO: 238 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
123700, 'TR123700', 'Jarad', 'Spender', 2466493948, 'jspender6l@nbcnews.com'
);

/* INSERT QUERY NO: 239 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
123800, 'TR123800', 'Delbert', 'Quantick', 9631600664, 'dquantick6m@issuu.com'
);

/* INSERT QUERY NO: 240 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
123900, 'TR123900', 'Creigh', 'Radnage', 3424241441, 'cradnage6n@sohu.com'
);

/* INSERT QUERY NO: 241 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
124000, 'TR124000', 'Perry', 'McQueen', 6958091341, 'pmcqueen6o@typepad.com'
);

/* INSERT QUERY NO: 242 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
124100, 'TR124100', 'Kerwin', 'Presswell', 8771304498, 'kpresswell6p@printfriendly.com'
);

/* INSERT QUERY NO: 243 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
124200, 'TR124200', 'Moina', 'Motherwell', 1973290154, 'mmotherwell6q@oracle.com'
);

/* INSERT QUERY NO: 244 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
124300, 'TR124300', 'Reamonn', 'Dye', 2015535338, 'rdye6r@1und1.de'
);

/* INSERT QUERY NO: 245 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
124400, 'TR124400', 'Wernher', 'Liccardo', 5922558579, 'wliccardo6s@vk.com'
);

/* INSERT QUERY NO: 246 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
124500, 'TR124500', 'Alexandros', 'Bernardoni', 6177564301, 'abernardoni6t@zimbio.com'
);

/* INSERT QUERY NO: 247 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
124600, 'TR124600', 'Judith', 'Blythin', 3464494418, 'jblythin6u@mail.ru'
);

/* INSERT QUERY NO: 248 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
124700, 'TR124700', 'Claybourne', 'Langfitt', 4832444837, 'clangfitt6v@nih.gov'
);

/* INSERT QUERY NO: 249 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
124800, 'TR124800', 'Even', 'Hiseman', 2444672328, 'ehiseman6w@xinhuanet.com'
);

/* INSERT QUERY NO: 250 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
124900, 'TR124900', 'Jerry', 'Veazey', 9291719152, 'jveazey6x@hibu.com'
);

/* INSERT QUERY NO: 251 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
125000, 'TR125000', 'Aarika', 'Jahner', 5811359246, 'ajahner6y@umich.edu'
);

/* INSERT QUERY NO: 252 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
125100, 'TR125100', 'Elena', 'Copnell', 4204656092, 'ecopnell6z@noaa.gov'
);

/* INSERT QUERY NO: 253 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
125200, 'TR125200', 'Victor', 'Kienzle', 7024639519, 'vkienzle70@cafepress.com'
);

/* INSERT QUERY NO: 254 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
125300, 'TR125300', 'Anselma', 'Jovanovic', 9082204035, 'ajovanovic71@admin.ch'
);

/* INSERT QUERY NO: 255 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
125400, 'TR125400', 'Clevey', 'Spofforth', 9393694480, 'cspofforth72@ning.com'
);

/* INSERT QUERY NO: 256 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
125500, 'TR125500', 'Hatty', 'Saket', 5233612561, 'hsaket73@wired.com'
);

/* INSERT QUERY NO: 257 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
125600, 'TR125600', 'Meir', 'Boshere', 3195763517, 'mboshere74@theguardian.com'
);

/* INSERT QUERY NO: 258 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
125700, 'TR125700', 'Devan', 'Chill', 4748358872, 'dchill75@census.gov'
);

/* INSERT QUERY NO: 259 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
125800, 'TR125800', 'Lesley', 'Driuzzi', 1743341535, 'ldriuzzi76@slashdot.org'
);

/* INSERT QUERY NO: 260 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
125900, 'TR125900', 'Antone', 'Carlino', 1937187974, 'acarlino77@google.ru'
);

/* INSERT QUERY NO: 261 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
126000, 'TR126000', 'Augie', 'Choulerton', 6395716381, 'achoulerton78@google.es'
);

/* INSERT QUERY NO: 262 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
126100, 'TR126100', 'Kaleb', 'Siddons', 4364388702, 'ksiddons79@quantcast.com'
);

/* INSERT QUERY NO: 263 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
126200, 'TR126200', 'Nikos', 'Aldous', 8759697844, 'naldous7a@purevolume.com'
);

/* INSERT QUERY NO: 264 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
126300, 'TR126300', 'Tracy', 'Munroe', 1263597631, 'tmunroe7b@nba.com'
);

/* INSERT QUERY NO: 265 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
126400, 'TR126400', 'Shaylynn', 'McNish', 1318189644, 'smcnish7c@bloomberg.com'
);

/* INSERT QUERY NO: 266 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
126500, 'TR126500', 'Heather', 'Castellaccio', 6678764395, 'hcastellaccio7d@rediff.com'
);

/* INSERT QUERY NO: 267 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
126600, 'TR126600', 'Zebadiah', 'Jonke', 1384399574, 'zjonke7e@patch.com'
);

/* INSERT QUERY NO: 268 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
126700, 'TR126700', 'Ashbey', 'Croux', 7003671647, 'acroux7f@deliciousdays.com'
);

/* INSERT QUERY NO: 269 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
126800, 'TR126800', 'Tallulah', 'Waddicor', 2931037774, 'twaddicor7g@plala.or.jp'
);

/* INSERT QUERY NO: 270 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
126900, 'TR126900', 'Flory', 'Burtenshaw', 2433974783, 'fburtenshaw7h@usa.gov'
);

/* INSERT QUERY NO: 271 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
127000, 'TR127000', 'Mina', 'Cathel', 7672448734, 'mcathel7i@youtu.be'
);

/* INSERT QUERY NO: 272 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
127100, 'TR127100', 'Jabez', 'Escale', 5469472642, 'jescale7j@skyrock.com'
);

/* INSERT QUERY NO: 273 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
127200, 'TR127200', 'Celeste', 'Gavrielly', 4766537520, 'cgavrielly7k@networkadvertising.org'
);

/* INSERT QUERY NO: 274 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
127300, 'TR127300', 'Koralle', 'McMillan', 5155747404, 'kmcmillan7l@cbc.ca'
);

/* INSERT QUERY NO: 275 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
127400, 'TR127400', 'Gareth', 'Morcombe', 9263280867, 'gmorcombe7m@github.io'
);

/* INSERT QUERY NO: 276 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
127500, 'TR127500', 'Sheeree', 'Malloy', 3135092309, 'smalloy7n@dailymotion.com'
);

/* INSERT QUERY NO: 277 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
127600, 'TR127600', 'Forster', 'Mossbee', 6581729818, 'fmossbee7o@chronoengine.com'
);

/* INSERT QUERY NO: 278 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
127700, 'TR127700', 'Natty', 'Acutt', 1275810952, 'nacutt7p@japanpost.jp'
);

/* INSERT QUERY NO: 279 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
127800, 'TR127800', 'Nydia', 'Searchwell', 5484288125, 'nsearchwell7q@mit.edu'
);

/* INSERT QUERY NO: 280 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
127900, 'TR127900', 'Genia', 'Rymmer', 5298128348, 'grymmer7r@mit.edu'
);

/* INSERT QUERY NO: 281 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
128000, 'TR128000', 'Pearline', 'Wylder', 3713152726, 'pwylder7s@1und1.de'
);

/* INSERT QUERY NO: 282 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
128100, 'TR128100', 'Herve', 'Aggett', 9753528527, 'haggett7t@msu.edu'
);

/* INSERT QUERY NO: 283 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
128200, 'TR128200', 'Letitia', 'Lorey', 4847511551, 'llorey7u@nymag.com'
);

/* INSERT QUERY NO: 284 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
128300, 'TR128300', 'Ramonda', 'McDowall', 5318067993, 'rmcdowall7v@ibm.com'
);

/* INSERT QUERY NO: 285 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
128400, 'TR128400', 'Obidiah', 'Bartlam', 4976918358, 'obartlam7w@simplemachines.org'
);

/* INSERT QUERY NO: 286 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
128500, 'TR128500', 'Bambie', 'Carnduff', 7686328381, 'bcarnduff7x@ucla.edu'
);

/* INSERT QUERY NO: 287 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
128600, 'TR128600', 'Sonnie', 'Nowick', 5231000548, 'snowick7y@ox.ac.uk'
);

/* INSERT QUERY NO: 288 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
128700, 'TR128700', 'Corina', 'Martinelli', 3381315696, 'cmartinelli7z@i2i.jp'
);

/* INSERT QUERY NO: 289 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
128800, 'TR128800', 'Zeke', 'Jako', 9236204650, 'zjako80@tumblr.com'
);

/* INSERT QUERY NO: 290 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
128900, 'TR128900', 'Vincents', 'Eastcott', 9869040068, 'veastcott81@va.gov'
);

/* INSERT QUERY NO: 291 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
129000, 'TR129000', 'Pace', 'Curnock', 2584664947, 'pcurnock82@wikispaces.com'
);

/* INSERT QUERY NO: 292 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
129100, 'TR129100', 'Sidonia', 'Findley', 5085002270, 'sfindley83@bloomberg.com'
);

/* INSERT QUERY NO: 293 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
129200, 'TR129200', 'Agnese', 'Valente', 4513188716, 'avalente84@squarespace.com'
);

/* INSERT QUERY NO: 294 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
129300, 'TR129300', 'Drud', 'Gouch', 3488887317, 'dgouch85@indiatimes.com'
);

/* INSERT QUERY NO: 295 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
129400, 'TR129400', 'Miller', 'Rayner', 1674328234, 'mrayner86@berkeley.edu'
);

/* INSERT QUERY NO: 296 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
129500, 'TR129500', 'Curt', 'Burke', 8812194311, 'cburke87@npr.org'
);

/* INSERT QUERY NO: 297 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
129600, 'TR129600', 'Porty', 'Pidgley', 2903486976, 'ppidgley88@bing.com'
);

/* INSERT QUERY NO: 298 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
129700, 'TR129700', 'Bartlet', 'Burbudge', 5278392603, 'bburbudge89@zimbio.com'
);

/* INSERT QUERY NO: 299 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
129800, 'TR129800', 'Fidole', 'Guiver', 2813893028, 'fguiver8a@1688.com'
);

/* INSERT QUERY NO: 300 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
129900, 'TR129900', 'Prentiss', 'Petts', 3275807224, 'ppetts8b@mtv.com'
);

/* INSERT QUERY NO: 301 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
130000, 'TR130000', 'Gareth', 'Darrell', 4964546881, 'gdarrell8c@domainmarket.com'
);

/* INSERT QUERY NO: 302 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
130100, 'TR130100', 'Natalina', 'Degan', 6358419082, 'ndegan8d@patch.com'
);

/* INSERT QUERY NO: 303 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
130200, 'TR130200', 'Carie', 'Bagley', 4236324550, 'cbagley8e@histats.com'
);

/* INSERT QUERY NO: 304 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
130300, 'TR130300', 'Reine', 'Pottes', 1323849878, 'rpottes8f@umich.edu'
);

/* INSERT QUERY NO: 305 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
130400, 'TR130400', 'Bridgette', 'Thalmann', 9366256046, 'bthalmann8g@ucoz.com'
);

/* INSERT QUERY NO: 306 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
130500, 'TR130500', 'Ferrel', 'Gianasi', 4755309644, 'fgianasi8h@yahoo.com'
);

/* INSERT QUERY NO: 307 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
130600, 'TR130600', 'Dianemarie', 'Ablett', 2828767539, 'dablett8i@amazonaws.com'
);

/* INSERT QUERY NO: 308 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
130700, 'TR130700', 'Rickie', 'Rosi', 4576173786, 'rrosi8j@businessweek.com'
);

/* INSERT QUERY NO: 309 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
130800, 'TR130800', 'Lisbeth', 'Shipp', 7848784400, 'lshipp8k@tuttocitta.it'
);

/* INSERT QUERY NO: 310 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
130900, 'TR130900', 'Corinna', 'Easen', 2654762018, 'ceasen8l@cmu.edu'
);

/* INSERT QUERY NO: 311 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
131000, 'TR131000', 'Miguel', 'Durie', 1396178653, 'mdurie8m@businessinsider.com'
);

/* INSERT QUERY NO: 312 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
131100, 'TR131100', 'Lauryn', 'Karim', 4024080790, 'lkarim8n@woothemes.com'
);

/* INSERT QUERY NO: 313 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
131200, 'TR131200', 'Keelia', 'Bater', 3334502269, 'kbater8o@icq.com'
);

/* INSERT QUERY NO: 314 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
131300, 'TR131300', 'Phip', 'Yoxall', 3997993884, 'pyoxall8p@linkedin.com'
);

/* INSERT QUERY NO: 315 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
131400, 'TR131400', 'Mollie', 'Longmaid', 2947855677, 'mlongmaid8q@nyu.edu'
);

/* INSERT QUERY NO: 316 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
131500, 'TR131500', 'Pegeen', 'Phelan', 4139317649, 'pphelan8r@home.pl'
);

/* INSERT QUERY NO: 317 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
131600, 'TR131600', 'Jarvis', 'Lambourne', 7377564865, 'jlambourne8s@mail.ru'
);

/* INSERT QUERY NO: 318 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
131700, 'TR131700', 'Alfreda', 'Janssens', 7776991946, 'ajanssens8t@a8.net'
);

/* INSERT QUERY NO: 319 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
131800, 'TR131800', 'Cristal', 'Ferruzzi', 2952363200, 'cferruzzi8u@abc.net.au'
);

/* INSERT QUERY NO: 320 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
131900, 'TR131900', 'Kirstyn', 'Bernadon', 2903649937, 'kbernadon8v@bbc.co.uk'
);

/* INSERT QUERY NO: 321 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
132000, 'TR132000', 'Umeko', 'Spyvye', 3498435174, 'uspyvye8w@shareasale.com'
);

/* INSERT QUERY NO: 322 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
132100, 'TR132100', 'Letty', 'Batteson', 2296686020, 'lbatteson8x@berkeley.edu'
);

/* INSERT QUERY NO: 323 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
132200, 'TR132200', 'Manfred', 'Vyse', 6627312478, 'mvyse8y@un.org'
);

/* INSERT QUERY NO: 324 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
132300, 'TR132300', 'Karlan', 'McClements', 7493595010, 'kmcclements8z@fotki.com'
);

/* INSERT QUERY NO: 325 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
132400, 'TR132400', 'Mackenzie', 'Kemer', 1571463069, 'mkemer90@engadget.com'
);

/* INSERT QUERY NO: 326 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
132500, 'TR132500', 'Orazio', 'Toyer', 4819665601, 'otoyer91@ow.ly'
);

/* INSERT QUERY NO: 327 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
132600, 'TR132600', 'Rose', 'Moggan', 1272488741, 'rmoggan92@examiner.com'
);

/* INSERT QUERY NO: 328 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
132700, 'TR132700', 'Piggy', 'Franek', 2698504102, 'pfranek93@elegantthemes.com'
);

/* INSERT QUERY NO: 329 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
132800, 'TR132800', 'Hernando', 'Orts', 9117121893, 'horts94@listmanage.com'
);

/* INSERT QUERY NO: 330 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
132900, 'TR132900', 'Clemens', 'Tetlow', 8015739183, 'ctetlow95@fema.gov'
);

/* INSERT QUERY NO: 331 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
133000, 'TR133000', 'Terrie', 'Coslitt', 4411595632, 'tcoslitt96@goo.ne.jp'
);

/* INSERT QUERY NO: 332 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
133100, 'TR133100', 'Darlleen', 'Chartres', 6208945579, 'dchartres97@google.fr'
);

/* INSERT QUERY NO: 333 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
133200, 'TR133200', 'Ronda', 'Hearl', 7208899960, 'rhearl98@howstuffworks.com'
);

/* INSERT QUERY NO: 334 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
133300, 'TR133300', 'Zaccaria', 'Fitzsimons', 9395892025, 'zfitzsimons99@facebook.com'
);

/* INSERT QUERY NO: 335 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
133400, 'TR133400', 'Karlan', 'Takkos', 2843037003, 'ktakkos9a@printfriendly.com'
);

/* INSERT QUERY NO: 336 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
133500, 'TR133500', 'Molly', 'Devote', 3754561801, 'mdevote9b@instagram.com'
);

/* INSERT QUERY NO: 337 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
133600, 'TR133600', 'Octavius', 'Dudding', 8072884700, 'odudding9c@slideshare.net'
);

/* INSERT QUERY NO: 338 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
133700, 'TR133700', 'Coralie', 'Pavy', 3458337192, 'cpavy9d@nih.gov'
);

/* INSERT QUERY NO: 339 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
133800, 'TR133800', 'Tony', 'Rome', 4694302813, 'trome9e@cargocollective.com'
);

/* INSERT QUERY NO: 340 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
133900, 'TR133900', 'Lief', 'Pettiward', 8267733615, 'lpettiward9f@nasa.gov'
);

/* INSERT QUERY NO: 341 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
134000, 'TR134000', 'Burke', 'Swaton', 4434155564, 'bswaton9g@bloglines.com'
);

/* INSERT QUERY NO: 342 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
134100, 'TR134100', 'Olva', 'Leatherbarrow', 2202397854, 'oleatherbarrow9h@netscape.com'
);

/* INSERT QUERY NO: 343 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
134200, 'TR134200', 'Lynelle', 'Santen', 3746280667, 'lsanten9i@goodreads.com'
);

/* INSERT QUERY NO: 344 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
134300, 'TR134300', 'Wyndham', 'Bursnall', 1008173565, 'wbursnall9j@mtv.com'
);

/* INSERT QUERY NO: 345 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
134400, 'TR134400', 'Micheal', 'Ronald', 2228518215, 'mronald9k@miibeian.gov.cn'
);

/* INSERT QUERY NO: 346 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
134500, 'TR134500', 'Rikki', 'Coghlan', 7899491509, 'rcoghlan9l@ning.com'
);

/* INSERT QUERY NO: 347 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
134600, 'TR134600', 'Cristabel', 'Pennacci', 6018890865, 'cpennacci9m@bloomberg.com'
);

/* INSERT QUERY NO: 348 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
134700, 'TR134700', 'Rhody', 'Beadnall', 2026310569, 'rbeadnall9n@cam.ac.uk'
);

/* INSERT QUERY NO: 349 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
134800, 'TR134800', 'Lowell', 'Mc Menamin', 8323368152, 'lmcmenamin9o@pinterest.com'
);

/* INSERT QUERY NO: 350 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
134900, 'TR134900', 'Celine', 'Le Bosse', 1767189512, 'clebosse9p@phpbb.com'
);

/* INSERT QUERY NO: 351 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
135000, 'TR135000', 'Atalanta', 'Hansard', 6758038386, 'ahansard9q@mlb.com'
);

/* INSERT QUERY NO: 352 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
135100, 'TR135100', 'Brnaby', 'De Simone', 9812645042, 'bdesimone9r@amazon.co.uk'
);

/* INSERT QUERY NO: 353 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
135200, 'TR135200', 'Madelyn', 'Boyde', 5087768167, 'mboyde9s@slashdot.org'
);

/* INSERT QUERY NO: 354 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
135300, 'TR135300', 'Jerri', 'Hartman', 2294867996, 'jhartman9t@thetimes.co.uk'
);

/* INSERT QUERY NO: 355 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
135400, 'TR135400', 'Bili', 'Klee', 4184295062, 'bklee9u@ox.ac.uk'
);

/* INSERT QUERY NO: 356 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
135500, 'TR135500', 'Catlee', 'Lifton', 7984135994, 'clifton9v@biblegateway.com'
);

/* INSERT QUERY NO: 357 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
135600, 'TR135600', 'Archibold', 'Muirden', 2781079788, 'amuirden9w@bbb.org'
);

/* INSERT QUERY NO: 358 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
135700, 'TR135700', 'Kellen', 'Campanelle', 5768693566, 'kcampanelle9x@nyu.edu'
);

/* INSERT QUERY NO: 359 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
135800, 'TR135800', 'Valaree', 'Wilshaw', 4622473402, 'vwilshaw9y@discuz.net'
);

/* INSERT QUERY NO: 360 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
135900, 'TR135900', 'Chilton', 'Dufton', 5331095697, 'cdufton9z@google.pl'
);

/* INSERT QUERY NO: 361 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
136000, 'TR136000', 'Erastus', 'Moehle', 3833245580, 'emoehlea0@mapy.cz'
);

/* INSERT QUERY NO: 362 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
136100, 'TR136100', 'Osgood', 'Brabben', 9561492805, 'obrabbena1@dion.ne.jp'
);

/* INSERT QUERY NO: 363 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
136200, 'TR136200', 'Katinka', 'Jovicevic', 5428530505, 'kjovicevica2@biglobe.ne.jp'
);

/* INSERT QUERY NO: 364 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
136300, 'TR136300', 'Melamie', 'Bourges', 4145052490, 'mbourgesa3@biglobe.ne.jp'
);

/* INSERT QUERY NO: 365 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
136400, 'TR136400', 'Ruttger', 'Rumford', 2103392643, 'rrumforda4@constantcontact.com'
);

/* INSERT QUERY NO: 366 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
136500, 'TR136500', 'Aileen', 'Odlin', 4809400621, 'aodlina5@alibaba.com'
);

/* INSERT QUERY NO: 367 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
136600, 'TR136600', 'Brena', 'Stithe', 4551656132, 'bstithea6@ocn.ne.jp'
);

/* INSERT QUERY NO: 368 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
136700, 'TR136700', 'Sara', 'Nassey', 5876581404, 'snasseya7@mapy.cz'
);

/* INSERT QUERY NO: 369 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
136800, 'TR136800', 'Robers', 'Blacket', 6494584796, 'rblacketa8@uol.com.br'
);

/* INSERT QUERY NO: 370 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
136900, 'TR136900', 'Florentia', 'Cawdery', 2739535905, 'fcawderya9@pagespersoorange.fr'
);

/* INSERT QUERY NO: 371 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
137000, 'TR137000', 'Didi', 'Trenouth', 5624179522, 'dtrenouthaa@instagram.com'
);

/* INSERT QUERY NO: 372 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
137100, 'TR137100', 'Retha', 'Kauffman', 2285196809, 'rkauffmanab@phoca.cz'
);

/* INSERT QUERY NO: 373 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
137200, 'TR137200', 'Rina', 'Dunckley', 2741327899, 'rdunckleyac@nba.com'
);

/* INSERT QUERY NO: 374 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
137300, 'TR137300', 'Ulrike', 'Ternault', 3056921653, 'uternaultad@wikimedia.org'
);

/* INSERT QUERY NO: 375 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
137400, 'TR137400', 'Louisa', 'Alexander', 7613084473, 'lalexanderae@businesswire.com'
);

/* INSERT QUERY NO: 376 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
137500, 'TR137500', 'Padraic', 'Scurrer', 8503275226, 'pscurreraf@tmall.com'
);

/* INSERT QUERY NO: 377 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
137600, 'TR137600', 'Angelica', 'Tytler', 1692497629, 'atytlerag@163.com'
);

/* INSERT QUERY NO: 378 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
137700, 'TR137700', 'Lil', 'Morcom', 2496085334, 'lmorcomah@skyrock.com'
);

/* INSERT QUERY NO: 379 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
137800, 'TR137800', 'Sarge', 'Harford', 2765640566, 'sharfordai@weather.com'
);

/* INSERT QUERY NO: 380 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
137900, 'TR137900', 'Susi', 'Swires', 9817855622, 'sswiresaj@earthlink.net'
);

/* INSERT QUERY NO: 381 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
138000, 'TR138000', 'Jenica', 'Edmondson', 5415231413, 'jedmondsonak@csmonitor.com'
);

/* INSERT QUERY NO: 382 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
138100, 'TR138100', 'Bert', 'Bargh', 7411579386, 'bbarghal@msu.edu'
);

/* INSERT QUERY NO: 383 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
138200, 'TR138200', 'Stu', 'Bollans', 5471945372, 'sbollansam@ehow.com'
);

/* INSERT QUERY NO: 384 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
138300, 'TR138300', 'Odella', 'Goddard', 5535662357, 'ogoddardan@erecht24.de'
);

/* INSERT QUERY NO: 385 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
138400, 'TR138400', 'Kalina', 'Bellon', 8636389989, 'kbellonao@earthlink.net'
);

/* INSERT QUERY NO: 386 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
138500, 'TR138500', 'Manuel', 'Lowless', 8575041025, 'mlowlessap@bbc.co.uk'
);

/* INSERT QUERY NO: 387 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
138600, 'TR138600', 'Jessamyn', 'Grass', 6531342789, 'jgrassaq@bravesites.com'
);

/* INSERT QUERY NO: 388 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
138700, 'TR138700', 'Tiff', 'Wellan', 2249684227, 'twellanar@360.cn'
);

/* INSERT QUERY NO: 389 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
138800, 'TR138800', 'Teirtza', 'Delgua', 7811310066, 'tdelguaas@spotify.com'
);

/* INSERT QUERY NO: 390 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
138900, 'TR138900', 'Willi', 'Wornum', 2629180757, 'wwornumat@bbc.co.uk'
);

/* INSERT QUERY NO: 391 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
139000, 'TR139000', 'Torey', 'Simpole', 2569654738, 'tsimpoleau@soup.io'
);

/* INSERT QUERY NO: 392 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
139100, 'TR139100', 'Helyn', 'Sheekey', 8217733281, 'hsheekeyav@homestead.com'
);

/* INSERT QUERY NO: 393 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
139200, 'TR139200', 'Samuele', 'Baudins', 5908002996, 'sbaudinsaw@mysql.com'
);

/* INSERT QUERY NO: 394 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
139300, 'TR139300', 'Annabell', 'Iacabucci', 9611666083, 'aiacabucciax@berkeley.edu'
);

/* INSERT QUERY NO: 395 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
139400, 'TR139400', 'Starr', 'Dmitrovic', 6166841971, 'sdmitrovicay@icio.us'
);

/* INSERT QUERY NO: 396 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
139500, 'TR139500', 'Loleta', 'Mapson', 7694931248, 'lmapsonaz@disqus.com'
);

/* INSERT QUERY NO: 397 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
139600, 'TR139600', 'Gunilla', 'Bosche', 2635364699, 'gboscheb0@i2i.jp'
);

/* INSERT QUERY NO: 398 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
139700, 'TR139700', 'Guy', 'Sommer', 9703796586, 'gsommerb1@epa.gov'
);

/* INSERT QUERY NO: 399 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
139800, 'TR139800', 'Griffie', 'Mack', 3684891281, 'gmackb2@soundcloud.com'
);

/* INSERT QUERY NO: 400 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
139900, 'TR139900', 'Pate', 'Durant', 3532444902, 'pdurantb3@purevolume.com'
);

/* INSERT QUERY NO: 401 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
140000, 'TR140000', 'Beckie', 'Ibberson', 1468258958, 'bibbersonb4@economist.com'
);

/* INSERT QUERY NO: 402 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
140100, 'TR140100', 'Hope', 'Volante', 9992542690, 'hvolanteb5@umn.edu'
);

/* INSERT QUERY NO: 403 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
140200, 'TR140200', 'Tammie', 'Moorhead', 4098647078, 'tmoorheadb6@mac.com'
);

/* INSERT QUERY NO: 404 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
140300, 'TR140300', 'Rica', 'Hodgon', 7239006900, 'rhodgonb7@reference.com'
);

/* INSERT QUERY NO: 405 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
140400, 'TR140400', 'Sharia', 'Madsen', 5958685957, 'smadsenb8@amazon.co.uk'
);

/* INSERT QUERY NO: 406 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
140500, 'TR140500', 'Willyt', 'Osler', 4654991186, 'woslerb9@twitpic.com'
);

/* INSERT QUERY NO: 407 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
140600, 'TR140600', 'Sarge', 'Screach', 9553192870, 'sscreachba@time.com'
);

/* INSERT QUERY NO: 408 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
140700, 'TR140700', 'Monro', 'Tarbett', 2928882080, 'mtarbettbb@wikipedia.org'
);

/* INSERT QUERY NO: 409 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
140800, 'TR140800', 'Rani', 'Duxbarry', 8713910065, 'rduxbarrybc@princeton.edu'
);

/* INSERT QUERY NO: 410 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
140900, 'TR140900', 'Rolph', 'Gergus', 9046290210, 'rgergusbd@telegraph.co.uk'
);

/* INSERT QUERY NO: 411 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
141000, 'TR141000', 'Darin', 'Gault', 4406153048, 'dgaultbe@blog.com'
);

/* INSERT QUERY NO: 412 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
141100, 'TR141100', 'Morissa', 'Caser', 3649972710, 'mcaserbf@gravatar.com'
);

/* INSERT QUERY NO: 413 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
141200, 'TR141200', 'Cherye', 'Grimme', 8969440356, 'cgrimmebg@boston.com'
);

/* INSERT QUERY NO: 414 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
141300, 'TR141300', 'Marmaduke', 'Dyte', 4411577434, 'mdytebh@meetup.com'
);

/* INSERT QUERY NO: 415 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
141400, 'TR141400', 'Rees', 'Robard', 1677096597, 'rrobardbi@mit.edu'
);

/* INSERT QUERY NO: 416 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
141500, 'TR141500', 'Loren', 'Nan Carrow', 3695939731, 'lnancarrowbj@gravatar.com'
);

/* INSERT QUERY NO: 417 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
141600, 'TR141600', 'Claiborne', 'Shillinglaw', 5977943251, 'cshillinglawbk@csmonitor.com'
);

/* INSERT QUERY NO: 418 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
141700, 'TR141700', 'Lauretta', 'Mulroy', 5829307772, 'lmulroybl@nba.com'
);

/* INSERT QUERY NO: 419 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
141800, 'TR141800', 'Clarisse', 'Sandbrook', 7334125722, 'csandbrookbm@theatlantic.com'
);

/* INSERT QUERY NO: 420 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
141900, 'TR141900', 'Katlin', 'Lafrentz', 2329469199, 'klafrentzbn@webmd.com'
);

/* INSERT QUERY NO: 421 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
142000, 'TR142000', 'Wiley', 'Impey', 5386151006, 'wimpeybo@dailymotion.com'
);

/* INSERT QUERY NO: 422 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
142100, 'TR142100', 'Kim', 'Bohl', 5215073214, 'kbohlbp@simplemachines.org'
);

/* INSERT QUERY NO: 423 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
142200, 'TR142200', 'Myrta', 'Owttrim', 4115431669, 'mowttrimbq@cam.ac.uk'
);

/* INSERT QUERY NO: 424 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
142300, 'TR142300', 'Alvina', 'Dennett', 3825262265, 'adennettbr@apache.org'
);

/* INSERT QUERY NO: 425 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
142400, 'TR142400', 'Brigit', 'Chaimson', 4732101291, 'bchaimsonbs@fotki.com'
);

/* INSERT QUERY NO: 426 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
142500, 'TR142500', 'Brena', 'Devinn', 8669437331, 'bdevinnbt@4shared.com'
);

/* INSERT QUERY NO: 427 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
142600, 'TR142600', 'Bird', 'Izzard', 4089820349, 'bizzardbu@51.la'
);

/* INSERT QUERY NO: 428 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
142700, 'TR142700', 'Charlot', 'Valentelli', 2792009296, 'cvalentellibv@bloglovin.com'
);

/* INSERT QUERY NO: 429 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
142800, 'TR142800', 'Isadore', 'Moller', 6339715432, 'imollerbw@google.com.au'
);

/* INSERT QUERY NO: 430 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
142900, 'TR142900', 'Lynnell', 'Burds', 1628375334, 'lburdsbx@taobao.com'
);

/* INSERT QUERY NO: 431 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
143000, 'TR143000', 'Vally', 'Cajkler', 7303436304, 'vcajklerby@yellowpages.com'
);

/* INSERT QUERY NO: 432 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
143100, 'TR143100', 'Millicent', 'Baxill', 5736278063, 'mbaxillbz@hc360.com'
);

/* INSERT QUERY NO: 433 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
143200, 'TR143200', 'Tessi', 'Pipes', 8864966428, 'tpipesc0@spiegel.de'
);

/* INSERT QUERY NO: 434 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
143300, 'TR143300', 'Ricca', 'Staton', 3181204349, 'rstatonc1@tamu.edu'
);

/* INSERT QUERY NO: 435 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
143400, 'TR143400', 'Antony', 'Beebe', 5935908589, 'abeebec2@epa.gov'
);

/* INSERT QUERY NO: 436 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
143500, 'TR143500', 'Farley', 'Dunklee', 1865268975, 'fdunkleec3@prnewswire.com'
);

/* INSERT QUERY NO: 437 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
143600, 'TR143600', 'Casi', 'Hampson', 3659370748, 'champsonc4@google.co.uk'
);

/* INSERT QUERY NO: 438 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
143700, 'TR143700', 'Stanislaw', 'Bellham', 6802872829, 'sbellhamc5@deviantart.com'
);

/* INSERT QUERY NO: 439 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
143800, 'TR143800', 'Cherise', 'Warner', 4933609507, 'cwarnerc6@timesonline.co.uk'
);

/* INSERT QUERY NO: 440 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
143900, 'TR143900', 'Meghan', 'Jeeves', 7238235025, 'mjeevesc7@gmpg.org'
);

/* INSERT QUERY NO: 441 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
144000, 'TR144000', 'Lancelot', 'Carding', 2123750251, 'lcardingc8@1688.com'
);

/* INSERT QUERY NO: 442 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
144100, 'TR144100', 'Jehanna', 'Crawforth', 6403926146, 'jcrawforthc9@slate.com'
);

/* INSERT QUERY NO: 443 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
144200, 'TR144200', 'Roldan', 'Barrasse', 7443653677, 'rbarrasseca@ezinearticles.com'
);

/* INSERT QUERY NO: 444 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
144300, 'TR144300', 'Angelika', 'Carnaman', 7737669963, 'acarnamancb@hc360.com'
);

/* INSERT QUERY NO: 445 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
144400, 'TR144400', 'Erminie', 'Forryan', 5498002048, 'eforryancc@alexa.com'
);

/* INSERT QUERY NO: 446 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
144500, 'TR144500', 'Reba', 'Praton', 3374248975, 'rpratoncd@vkontakte.ru'
);

/* INSERT QUERY NO: 447 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
144600, 'TR144600', 'Ardisj', 'Baccus', 6077039637, 'abaccusce@home.pl'
);

/* INSERT QUERY NO: 448 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
144700, 'TR144700', 'Nikolia', 'Annice', 9125896409, 'nannicecf@multiply.com'
);

/* INSERT QUERY NO: 449 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
144800, 'TR144800', 'Pieter', 'Rangle', 2415986602, 'pranglecg@sonet.ne.jp'
);

/* INSERT QUERY NO: 450 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
144900, 'TR144900', 'Rhody', 'Schnieder', 4109421404, 'rschniederch@tinyurl.com'
);

/* INSERT QUERY NO: 451 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
145000, 'TR145000', 'Fabio', 'Sheasby', 5838883195, 'fsheasbyci@infoseek.co.jp'
);

/* INSERT QUERY NO: 452 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
145100, 'TR145100', 'Alain', 'Scarsbrook', 1673822189, 'ascarsbrookcj@weibo.com'
);

/* INSERT QUERY NO: 453 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
145200, 'TR145200', 'Correy', 'Itzkovwitch', 1025558095, 'citzkovwitchck@msu.edu'
);

/* INSERT QUERY NO: 454 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
145300, 'TR145300', 'Sunny', 'Zorzetti', 3442778365, 'szorzetticl@upenn.edu'
);

/* INSERT QUERY NO: 455 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
145400, 'TR145400', 'Dana', 'Hoult', 6718276975, 'dhoultcm@aol.com'
);

/* INSERT QUERY NO: 456 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
145500, 'TR145500', 'Bancroft', 'Echalie', 7189112403, 'bechaliecn@cnet.com'
);

/* INSERT QUERY NO: 457 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
145600, 'TR145600', 'Helaine', 'Millhill', 9204874261, 'hmillhillco@wikispaces.com'
);

/* INSERT QUERY NO: 458 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
145700, 'TR145700', 'Kesley', 'Boulsher', 5537273668, 'kboulshercp@discuz.net'
);

/* INSERT QUERY NO: 459 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
145800, 'TR145800', 'Tuck', 'Reast', 4846121785, 'treastcq@nhs.uk'
);

/* INSERT QUERY NO: 460 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
145900, 'TR145900', 'Nial', 'Mishow', 1857884501, 'nmishowcr@goodreads.com'
);

/* INSERT QUERY NO: 461 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
146000, 'TR146000', 'Claire', 'Farney', 1945471559, 'cfarneycs@businesswire.com'
);

/* INSERT QUERY NO: 462 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
146100, 'TR146100', 'Kellen', 'Loines', 2044993251, 'kloinesct@mac.com'
);

/* INSERT QUERY NO: 463 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
146200, 'TR146200', 'Kevon', 'Knibbs', 5157672483, 'kknibbscu@netvibes.com'
);

/* INSERT QUERY NO: 464 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
146300, 'TR146300', 'Debra', 'McKleod', 8603758052, 'dmckleodcv@people.com.cn'
);

/* INSERT QUERY NO: 465 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
146400, 'TR146400', 'Vinni', 'Aubin', 9769624027, 'vaubincw@apache.org'
);

/* INSERT QUERY NO: 466 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
146500, 'TR146500', 'Josie', 'Fellos', 5003706757, 'jfelloscx@nbcnews.com'
);

/* INSERT QUERY NO: 467 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
146600, 'TR146600', 'Patience', 'Waylen', 7481960601, 'pwaylency@umn.edu'
);

/* INSERT QUERY NO: 468 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
146700, 'TR146700', 'Hasheem', 'MacKeever', 1985963000, 'hmackeevercz@istockphoto.com'
);

/* INSERT QUERY NO: 469 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
146800, 'TR146800', 'Urbain', 'Romayn', 2746154582, 'uromaynd0@zdnet.com'
);

/* INSERT QUERY NO: 470 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
146900, 'TR146900', 'Garry', 'Custy', 8272731425, 'gcustyd1@jalbum.net'
);

/* INSERT QUERY NO: 471 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
147000, 'TR147000', 'Dannie', 'Carslake', 7968128880, 'dcarslaked2@businessweek.com'
);

/* INSERT QUERY NO: 472 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
147100, 'TR147100', 'Em', 'Scollan', 3951966890, 'escolland3@yandex.ru'
);

/* INSERT QUERY NO: 473 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
147200, 'TR147200', 'Emlyn', 'Waszczyk', 6781905373, 'ewaszczykd4@theatlantic.com'
);

/* INSERT QUERY NO: 474 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
147300, 'TR147300', 'Tome', 'Stillmann', 6199429150, 'tstillmannd5@sbwire.com'
);

/* INSERT QUERY NO: 475 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
147400, 'TR147400', 'Penny', 'Elphick', 3534581837, 'pelphickd6@scientificamerican.com'
);

/* INSERT QUERY NO: 476 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
147500, 'TR147500', 'Caril', 'Legerwood', 5159957884, 'clegerwoodd7@lulu.com'
);

/* INSERT QUERY NO: 477 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
147600, 'TR147600', 'Dynah', 'Kerry', 2422236896, 'dkerryd8@mac.com'
);

/* INSERT QUERY NO: 478 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
147700, 'TR147700', 'Ursala', 'Beyne', 8739570251, 'ubeyned9@japanpost.jp'
);

/* INSERT QUERY NO: 479 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
147800, 'TR147800', 'Clemmie', 'Fawkes', 8051388954, 'cfawkesda@china.com.cn'
);

/* INSERT QUERY NO: 480 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
147900, 'TR147900', 'Patti', 'Mercey', 7202451683, 'pmerceydb@jigsy.com'
);

/* INSERT QUERY NO: 481 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
148000, 'TR148000', 'Leigha', 'Goney', 1689432576, 'lgoneydc@comsenz.com'
);

/* INSERT QUERY NO: 482 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
148100, 'TR148100', 'Sukey', 'Linsay', 7897442077, 'slinsaydd@networkadvertising.org'
);

/* INSERT QUERY NO: 483 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
148200, 'TR148200', 'Archaimbaud', 'Lancett', 7388954715, 'alancettde@naver.com'
);

/* INSERT QUERY NO: 484 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
148300, 'TR148300', 'Thomasina', 'Lisamore', 3392985818, 'tlisamoredf@businessinsider.com'
);

/* INSERT QUERY NO: 485 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
148400, 'TR148400', 'Merna', 'Aslet', 2023992943, 'masletdg@people.com.cn'
);

/* INSERT QUERY NO: 486 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
148500, 'TR148500', 'Rosa', 'Pinnere', 6815595413, 'rpinneredh@loc.gov'
);

/* INSERT QUERY NO: 487 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
148600, 'TR148600', 'Ursa', 'Bentick', 4683916535, 'ubentickdi@scribd.com'
);

/* INSERT QUERY NO: 488 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
148700, 'TR148700', 'Amara', 'Tuppeny', 8904946065, 'atuppenydj@cornell.edu'
);

/* INSERT QUERY NO: 489 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
148800, 'TR148800', 'Daisey', 'Peat', 1273938986, 'dpeatdk@moonfruit.com'
);

/* INSERT QUERY NO: 490 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
148900, 'TR148900', 'Berke', 'Holttom', 5746758012, 'bholttomdl@jiathis.com'
);

/* INSERT QUERY NO: 491 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
149000, 'TR149000', 'Oliviero', 'Courtman', 4304979749, 'ocourtmandm@google.fr'
);

/* INSERT QUERY NO: 492 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
149100, 'TR149100', 'Alexandre', 'Pauly', 2802168786, 'apaulydn@artisteer.com'
);

/* INSERT QUERY NO: 493 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
149200, 'TR149200', 'Lorne', 'Diwell', 1432652471, 'ldiwelldo@typepad.com'
);

/* INSERT QUERY NO: 494 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
149300, 'TR149300', 'Gerik', 'Fonquernie', 9602198326, 'gfonquerniedp@geocities.com'
);

/* INSERT QUERY NO: 495 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
149400, 'TR149400', 'Mortie', 'Tole', 7348259508, 'mtoledq@youtu.be'
);

/* INSERT QUERY NO: 496 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
149500, 'TR149500', 'Colene', 'Bispo', 3302614268, 'cbispodr@blogs.com'
);

/* INSERT QUERY NO: 497 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
149600, 'TR149600', 'Dorree', 'Piletic', 4077799453, 'dpileticds@feedburner.com'
);

/* INSERT QUERY NO: 498 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
149700, 'TR149700', 'Ellyn', 'Croux', 8438022228, 'ecrouxdt@opensource.org'
);

/* INSERT QUERY NO: 499 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
149800, 'TR149800', 'Welby', 'Teager', 8199093023, 'wteagerdu@smugmug.com'
);

/* INSERT QUERY NO: 500 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
149900, 'TR149900', 'Patsy', 'Drever', 4475304657, 'pdreverdv@pen.io'
);

/* INSERT QUERY NO: 501 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
150000, 'TR150000', 'Jeffie', 'Lemmens', 5147496065, 'jlemmensdw@indiegogo.com'
);

/* INSERT QUERY NO: 502 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
150100, 'TR150100', 'Henry', 'Neeves', 7715180250, 'hneevesdx@comsenz.com'
);

/* INSERT QUERY NO: 503 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
150200, 'TR150200', 'Joelynn', 'Gyorgy', 5159513083, 'jgyorgydy@nbcnews.com'
);

/* INSERT QUERY NO: 504 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
150300, 'TR150300', 'Kevon', 'McMackin', 5057541026, 'kmcmackindz@storify.com'
);

/* INSERT QUERY NO: 505 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
150400, 'TR150400', 'Johannes', 'Harbottle', 8596029607, 'jharbottlee0@irs.gov'
);

/* INSERT QUERY NO: 506 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
150500, 'TR150500', 'Tobey', 'Dumbleton', 2775850099, 'tdumbletone1@example.com'
);

/* INSERT QUERY NO: 507 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
150600, 'TR150600', 'Mirelle', 'Rookeby', 6469660160, 'mrookebye2@businessweek.com'
);

/* INSERT QUERY NO: 508 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
150700, 'TR150700', 'Wilma', 'Pittson', 3177505981, 'wpittsone3@wired.com'
);

/* INSERT QUERY NO: 509 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
150800, 'TR150800', 'Gunther', 'Armytage', 5208108696, 'garmytagee4@go.com'
);

/* INSERT QUERY NO: 510 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
150900, 'TR150900', 'Ursulina', 'Biskupski', 8072800973, 'ubiskupskie5@discovery.com'
);

/* INSERT QUERY NO: 511 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
151000, 'TR151000', 'Hildegarde', 'Fonte', 8785626714, 'hfontee6@mapquest.com'
);

/* INSERT QUERY NO: 512 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
151100, 'TR151100', 'Woody', 'Dottridge', 2437840628, 'wdottridgee7@yolasite.com'
);

/* INSERT QUERY NO: 513 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
151200, 'TR151200', 'Chrisse', 'Belton', 8221637586, 'cbeltone8@wired.com'
);

/* INSERT QUERY NO: 514 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
151300, 'TR151300', 'Standford', 'de Cullip', 6062182825, 'sdecullipe9@google.com.au'
);

/* INSERT QUERY NO: 515 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
151400, 'TR151400', 'Paule', 'Eisak', 7429134865, 'peisakea@cargocollective.com'
);

/* INSERT QUERY NO: 516 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
151500, 'TR151500', 'Ginger', 'Edworthye', 7276938100, 'gedworthyeeb@webnode.com'
);

/* INSERT QUERY NO: 517 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
151600, 'TR151600', 'Marco', 'Hugo', 5331308970, 'mhugoec@dmoz.org'
);

/* INSERT QUERY NO: 518 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
151700, 'TR151700', 'Hagen', 'Kennerley', 8323909799, 'hkennerleyed@imdb.com'
);

/* INSERT QUERY NO: 519 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
151800, 'TR151800', 'Ignaz', 'Donovin', 6271813779, 'idonovinee@tinypic.com'
);

/* INSERT QUERY NO: 520 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
151900, 'TR151900', 'Kennan', 'Treneer', 9106624859, 'ktreneeref@army.mil'
);

/* INSERT QUERY NO: 521 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
152000, 'TR152000', 'Wilton', 'Branston', 2692296083, 'wbranstoneg@mozilla.com'
);

/* INSERT QUERY NO: 522 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
152100, 'TR152100', 'Vic', 'Filipputti', 9515015893, 'vfilipputtieh@ask.com'
);

/* INSERT QUERY NO: 523 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
152200, 'TR152200', 'Kennett', 'Kidston', 1575916136, 'kkidstonei@jigsy.com'
);

/* INSERT QUERY NO: 524 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
152300, 'TR152300', 'Hasty', 'Hazelgreave', 1962291075, 'hhazelgreaveej@whitehouse.gov'
);

/* INSERT QUERY NO: 525 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
152400, 'TR152400', 'Madella', 'Dunstall', 6398751330, 'mdunstallek@squidoo.com'
);

/* INSERT QUERY NO: 526 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
152500, 'TR152500', 'Hugues', 'Suggate', 8817976557, 'hsuggateel@indiegogo.com'
);

/* INSERT QUERY NO: 527 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
152600, 'TR152600', 'Albie', 'Jacquemet', 6715294994, 'ajacquemetem@odnoklassniki.ru'
);

/* INSERT QUERY NO: 528 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
152700, 'TR152700', 'Bay', 'Dunbobbin', 3947870609, 'bdunbobbinen@fda.gov'
);

/* INSERT QUERY NO: 529 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
152800, 'TR152800', 'Sal', 'Petrashkov', 2614240126, 'spetrashkoveo@zimbio.com'
);

/* INSERT QUERY NO: 530 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
152900, 'TR152900', 'Caddric', 'Lawler', 7914656077, 'clawlerep@nifty.com'
);

/* INSERT QUERY NO: 531 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
153000, 'TR153000', 'Pren', 'Danilovich', 8685982692, 'pdanilovicheq@nih.gov'
);

/* INSERT QUERY NO: 532 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
153100, 'TR153100', 'Pollyanna', 'Dallander', 4599286868, 'pdallanderer@wikipedia.org'
);

/* INSERT QUERY NO: 533 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
153200, 'TR153200', 'Valaria', 'Giacobo', 4081335017, 'vgiacoboes@paginegialle.it'
);

/* INSERT QUERY NO: 534 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
153300, 'TR153300', 'Abbye', 'Callery', 5964881568, 'acalleryet@wp.com'
);

/* INSERT QUERY NO: 535 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
153400, 'TR153400', 'Hew', 'Alwin', 9669946682, 'halwineu@webeden.co.uk'
);

/* INSERT QUERY NO: 536 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
153500, 'TR153500', 'Norina', 'Toderini', 1138250176, 'ntoderiniev@slideshare.net'
);

/* INSERT QUERY NO: 537 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
153600, 'TR153600', 'Violet', 'Keymer', 3348593024, 'vkeymerew@paypal.com'
);

/* INSERT QUERY NO: 538 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
153700, 'TR153700', 'Thadeus', 'McLaine', 5386670274, 'tmclaineex@1688.com'
);

/* INSERT QUERY NO: 539 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
153800, 'TR153800', 'Stanislas', 'Blakemore', 2161844821, 'sblakemoreey@shutterfly.com'
);

/* INSERT QUERY NO: 540 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
153900, 'TR153900', 'Leanora', 'Peppin', 7399128852, 'lpeppinez@hostgator.com'
);

/* INSERT QUERY NO: 541 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
154000, 'TR154000', 'Trevor', 'Fidell', 7869500844, 'tfidellf0@symantec.com'
);

/* INSERT QUERY NO: 542 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
154100, 'TR154100', 'Beltran', 'Duligal', 7323863026, 'bduligalf1@angelfire.com'
);

/* INSERT QUERY NO: 543 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
154200, 'TR154200', 'Karlens', 'MacAnelley', 6044252963, 'kmacanelleyf2@storify.com'
);

/* INSERT QUERY NO: 544 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
154300, 'TR154300', 'Mitchael', 'Kerner', 5398933407, 'mkernerf3@spiegel.de'
);

/* INSERT QUERY NO: 545 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
154400, 'TR154400', 'Olly', 'Dwerryhouse', 4908002210, 'odwerryhousef4@ucsd.edu'
);

/* INSERT QUERY NO: 546 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
154500, 'TR154500', 'Merlina', 'MacRierie', 2288489470, 'mmacrierief5@sonet.ne.jp'
);

/* INSERT QUERY NO: 547 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
154600, 'TR154600', 'Erv', 'Seson', 7493494969, 'esesonf6@creativecommons.org'
);

/* INSERT QUERY NO: 548 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
154700, 'TR154700', 'Neill', 'Judgkins', 8371042643, 'njudgkinsf7@blogtalkradio.com'
);

/* INSERT QUERY NO: 549 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
154800, 'TR154800', 'Sonnnie', 'Scales', 1815765667, 'sscalesf8@macromedia.com'
);

/* INSERT QUERY NO: 550 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
154900, 'TR154900', 'Maxwell', 'Hafford', 6059835330, 'mhaffordf9@freewebs.com'
);

/* INSERT QUERY NO: 551 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
155000, 'TR155000', 'Bing', 'Earles', 8553516226, 'bearlesfa@upenn.edu'
);

/* INSERT QUERY NO: 552 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
155100, 'TR155100', 'Regine', 'Jerche', 5832120166, 'rjerchefb@toplist.cz'
);

/* INSERT QUERY NO: 553 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
155200, 'TR155200', 'Brandea', 'Gaskall', 8532247190, 'bgaskallfc@upenn.edu'
);

/* INSERT QUERY NO: 554 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
155300, 'TR155300', 'Kristan', 'Braunton', 9438878423, 'kbrauntonfd@disqus.com'
);

/* INSERT QUERY NO: 555 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
155400, 'TR155400', 'Raymond', 'Ivakhno', 9664821728, 'rivakhnofe@craigslist.org'
);

/* INSERT QUERY NO: 556 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
155500, 'TR155500', 'Ardelle', 'Hoggan', 4389593343, 'ahogganff@phoca.cz'
);

/* INSERT QUERY NO: 557 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
155600, 'TR155600', 'Alis', 'Blancowe', 8014310733, 'ablancowefg@upenn.edu'
);

/* INSERT QUERY NO: 558 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
155700, 'TR155700', 'Reagan', 'Burds', 1428804239, 'rburdsfh@delicious.com'
);

/* INSERT QUERY NO: 559 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
155800, 'TR155800', 'Sol', 'Brasher', 6211023813, 'sbrasherfi@xinhuanet.com'
);

/* INSERT QUERY NO: 560 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
155900, 'TR155900', 'Ariel', 'Butler', 7406120840, 'abutlerfj@moonfruit.com'
);

/* INSERT QUERY NO: 561 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
156000, 'TR156000', 'Aggi', 'McGowran', 4987914029, 'amcgowranfk@pcworld.com'
);

/* INSERT QUERY NO: 562 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
156100, 'TR156100', 'Rhianon', 'Bech', 9126875426, 'rbechfl@toplist.cz'
);

/* INSERT QUERY NO: 563 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
156200, 'TR156200', 'Broderick', 'Wink', 1084802179, 'bwinkfm@bigcartel.com'
);

/* INSERT QUERY NO: 564 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
156300, 'TR156300', 'Zack', 'Christon', 8804435388, 'zchristonfn@pagespersoorange.fr'
);

/* INSERT QUERY NO: 565 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
156400, 'TR156400', 'Shaine', 'Gravells', 4671926204, 'sgravellsfo@tonline.de'
);

/* INSERT QUERY NO: 566 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
156500, 'TR156500', 'Lilith', 'Gaine of England', 2386859375, 'lgaineofenglandfp@spiegel.de'
);

/* INSERT QUERY NO: 567 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
156600, 'TR156600', 'Elyse', 'Tingcomb', 3482195737, 'etingcombfq@yellowbook.com'
);

/* INSERT QUERY NO: 568 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
156700, 'TR156700', 'Marlo', 'Setford', 3916031691, 'msetfordfr@meetup.com'
);

/* INSERT QUERY NO: 569 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
156800, 'TR156800', 'Issy', 'Georgius', 4643823694, 'igeorgiusfs@tripadvisor.com'
);

/* INSERT QUERY NO: 570 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
156900, 'TR156900', 'Laney', 'McGiffie', 4457456584, 'lmcgiffieft@comcast.net'
);

/* INSERT QUERY NO: 571 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
157000, 'TR157000', 'Filberte', 'Cornford', 2945860602, 'fcornfordfu@scribd.com'
);

/* INSERT QUERY NO: 572 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
157100, 'TR157100', 'Damon', 'Terzza', 4127962949, 'dterzzafv@bloglovin.com'
);

/* INSERT QUERY NO: 573 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
157200, 'TR157200', 'Rooney', 'Eixenberger', 3884582072, 'reixenbergerfw@freewebs.com'
);

/* INSERT QUERY NO: 574 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
157300, 'TR157300', 'Ede', 'MacNeice', 3237108725, 'emacneicefx@auda.org.au'
);

/* INSERT QUERY NO: 575 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
157400, 'TR157400', 'Nestor', 'Stocken', 3565620208, 'nstockenfy@slideshare.net'
);

/* INSERT QUERY NO: 576 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
157500, 'TR157500', 'Cathryn', 'Mariel', 6137087602, 'cmarielfz@psu.edu'
);

/* INSERT QUERY NO: 577 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
157600, 'TR157600', 'Raynell', 'Wharton', 8399245309, 'rwhartong0@reverbnation.com'
);

/* INSERT QUERY NO: 578 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
157700, 'TR157700', 'Allister', 'Keasey', 1416107476, 'akeaseyg1@xrea.com'
);

/* INSERT QUERY NO: 579 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
157800, 'TR157800', 'Josephina', 'Hewson', 1718436256, 'jhewsong2@dailymail.co.uk'
);

/* INSERT QUERY NO: 580 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
157900, 'TR157900', 'Dino', 'Borrow', 2352124799, 'dborrowg3@arstechnica.com'
);

/* INSERT QUERY NO: 581 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
158000, 'TR158000', 'Bobby', 'OldfieldCherry', 3387657249, 'boldfieldcherryg4@geocities.com'
);

/* INSERT QUERY NO: 582 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
158100, 'TR158100', 'Quent', 'Pulford', 7757247047, 'qpulfordg5@earthlink.net'
);

/* INSERT QUERY NO: 583 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
158200, 'TR158200', 'Pooh', 'Grishinov', 5596615695, 'pgrishinovg6@sphinn.com'
);

/* INSERT QUERY NO: 584 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
158300, 'TR158300', 'Elnar', 'Baldacchi', 9121485143, 'ebaldacchig7@fotki.com'
);

/* INSERT QUERY NO: 585 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
158400, 'TR158400', 'Samson', 'Braferton', 1243435213, 'sbrafertong8@slashdot.org'
);

/* INSERT QUERY NO: 586 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
158500, 'TR158500', 'Shurwood', 'Tummons', 1195841864, 'stummonsg9@artisteer.com'
);

/* INSERT QUERY NO: 587 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
158600, 'TR158600', 'Joice', 'Ancliff', 8982836638, 'jancliffga@rambler.ru'
);

/* INSERT QUERY NO: 588 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
158700, 'TR158700', 'Miner', 'Feldmus', 2692722848, 'mfeldmusgb@instagram.com'
);

/* INSERT QUERY NO: 589 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
158800, 'TR158800', 'Abrahan', 'Kurtis', 3939673240, 'akurtisgc@ebay.com'
);

/* INSERT QUERY NO: 590 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
158900, 'TR158900', 'Blisse', 'Vanner', 1171305237, 'bvannergd@addthis.com'
);

/* INSERT QUERY NO: 591 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
159000, 'TR159000', 'Tracie', 'Helbeck', 3279462633, 'thelbeckge@merriamwebster.com'
);

/* INSERT QUERY NO: 592 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
159100, 'TR159100', 'Fredrick', 'Sambell', 3937582988, 'fsambellgf@bloglovin.com'
);

/* INSERT QUERY NO: 593 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
159200, 'TR159200', 'Liane', 'Emburey', 6198580246, 'lembureygg@123reg.co.uk'
);

/* INSERT QUERY NO: 594 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
159300, 'TR159300', 'Andres', 'Bate', 1498430735, 'abategh@theatlantic.com'
);

/* INSERT QUERY NO: 595 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
159400, 'TR159400', 'Ethelda', 'Housegoe', 2286404473, 'ehousegoegi@mapy.cz'
);

/* INSERT QUERY NO: 596 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
159500, 'TR159500', 'Odell', 'Challice', 6559216075, 'ochallicegj@senate.gov'
);

/* INSERT QUERY NO: 597 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
159600, 'TR159600', 'Adam', 'Ecob', 3618414409, 'aecobgk@liveinternet.ru'
);

/* INSERT QUERY NO: 598 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
159700, 'TR159700', 'Paxton', 'Warde', 7357962883, 'pwardegl@discuz.net'
);

/* INSERT QUERY NO: 599 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
159800, 'TR159800', 'Karel', 'Mullaly', 2816097230, 'kmullalygm@tinyurl.com'
);

/* INSERT QUERY NO: 600 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
159900, 'TR159900', 'Georgie', 'Flicker', 4581494173, 'gflickergn@arstechnica.com'
);

/* INSERT QUERY NO: 601 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
160000, 'TR160000', 'Cchaddie', 'Maleham', 7647481883, 'cmalehamgo@answers.com'
);

/* INSERT QUERY NO: 602 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
160100, 'TR160100', 'Corbin', 'Blaksley', 2392233970, 'cblaksleygp@artisteer.com'
);

/* INSERT QUERY NO: 603 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
160200, 'TR160200', 'Angelo', 'Berrill', 8011984419, 'aberrillgq@google.pl'
);

/* INSERT QUERY NO: 604 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
160300, 'TR160300', 'Marcello', 'Hobben', 3001000562, 'mhobbengr@wunderground.com'
);

/* INSERT QUERY NO: 605 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
160400, 'TR160400', 'Merrili', 'Strachan', 4346101612, 'mstrachangs@wunderground.com'
);

/* INSERT QUERY NO: 606 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
160500, 'TR160500', 'Aguistin', 'Loxston', 5581022306, 'aloxstongt@prlog.org'
);

/* INSERT QUERY NO: 607 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
160600, 'TR160600', 'Freeland', 'Sunley', 6069718651, 'fsunleygu@unblog.fr'
);

/* INSERT QUERY NO: 608 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
160700, 'TR160700', 'Siobhan', 'Harding', 9544533419, 'shardinggv@facebook.com'
);

/* INSERT QUERY NO: 609 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
160800, 'TR160800', 'Raphaela', 'Suart', 1913825257, 'rsuartgw@scribd.com'
);

/* INSERT QUERY NO: 610 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
160900, 'TR160900', 'Dara', 'Hagland', 3721856532, 'dhaglandgx@photobucket.com'
);

/* INSERT QUERY NO: 611 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
161000, 'TR161000', 'Corena', 'Billes', 3522986138, 'cbillesgy@skype.com'
);

/* INSERT QUERY NO: 612 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
161100, 'TR161100', 'Mano', 'Guihen', 6363075192, 'mguihengz@ucsd.edu'
);

/* INSERT QUERY NO: 613 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
161200, 'TR161200', 'Libby', 'Dimmock', 4467808739, 'ldimmockh0@arstechnica.com'
);

/* INSERT QUERY NO: 614 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
161300, 'TR161300', 'Karon', 'Capnerhurst', 7693183018, 'kcapnerhursth1@bandcamp.com'
);

/* INSERT QUERY NO: 615 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
161400, 'TR161400', 'Lainey', 'Archer', 1439428233, 'larcherh2@ovh.net'
);

/* INSERT QUERY NO: 616 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
161500, 'TR161500', 'Janith', 'Thundercliffe', 8856201904, 'jthundercliffeh3@pbs.org'
);

/* INSERT QUERY NO: 617 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
161600, 'TR161600', 'Caleb', 'Duckerin', 3242820240, 'cduckerinh4@tuttocitta.it'
);

/* INSERT QUERY NO: 618 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
161700, 'TR161700', 'Keven', 'Ivanyushin', 9969199397, 'kivanyushinh5@istockphoto.com'
);

/* INSERT QUERY NO: 619 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
161800, 'TR161800', 'Cletis', 'Gauvin', 9158745889, 'cgauvinh6@cdc.gov'
);

/* INSERT QUERY NO: 620 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
161900, 'TR161900', 'Aggie', 'Linford', 6906715431, 'alinfordh7@cpanel.net'
);

/* INSERT QUERY NO: 621 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
162000, 'TR162000', 'Garvey', 'Richly', 7741893748, 'grichlyh8@typepad.com'
);

/* INSERT QUERY NO: 622 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
162100, 'TR162100', 'Emogene', 'Jaquemar', 6617924013, 'ejaquemarh9@newyorker.com'
);

/* INSERT QUERY NO: 623 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
162200, 'TR162200', 'Nanci', 'Freestone', 1855215946, 'nfreestoneha@cnn.com'
);

/* INSERT QUERY NO: 624 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
162300, 'TR162300', 'Patsy', 'Gencke', 6302062623, 'pgenckehb@tamu.edu'
);

/* INSERT QUERY NO: 625 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
162400, 'TR162400', 'Moore', 'Warrier', 6121910319, 'mwarrierhc@biblegateway.com'
);

/* INSERT QUERY NO: 626 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
162500, 'TR162500', 'Vevay', 'Bwye', 3245694457, 'vbwyehd@microsoft.com'
);

/* INSERT QUERY NO: 627 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
162600, 'TR162600', 'Any', 'Allinson', 7218234709, 'aallinsonhe@i2i.jp'
);

/* INSERT QUERY NO: 628 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
162700, 'TR162700', 'Dare', 'Helleckas', 9345722942, 'dhelleckashf@techcrunch.com'
);

/* INSERT QUERY NO: 629 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
162800, 'TR162800', 'Ilaire', 'Lehenmann', 3147966326, 'ilehenmannhg@shoppro.jp'
);

/* INSERT QUERY NO: 630 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
162900, 'TR162900', 'Colly', 'Gealy', 9323885388, 'cgealyhh@techcrunch.com'
);

/* INSERT QUERY NO: 631 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
163000, 'TR163000', 'Charmane', 'Dunseith', 5158755460, 'cdunseithhi@oaic.gov.au'
);

/* INSERT QUERY NO: 632 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
163100, 'TR163100', 'Mead', 'Stener', 9162597013, 'mstenerhj@wired.com'
);

/* INSERT QUERY NO: 633 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
163200, 'TR163200', 'Carri', 'Rouse', 5447541564, 'crousehk@i2i.jp'
);

/* INSERT QUERY NO: 634 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
163300, 'TR163300', 'Halley', 'Zanuciolii', 1327321464, 'hzanucioliihl@purevolume.com'
);

/* INSERT QUERY NO: 635 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
163400, 'TR163400', 'Willow', 'Dorn', 2566841241, 'wdornhm@nhs.uk'
);

/* INSERT QUERY NO: 636 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
163500, 'TR163500', 'Otha', 'Count', 1504656915, 'ocounthn@telegraph.co.uk'
);

/* INSERT QUERY NO: 637 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
163600, 'TR163600', 'Tonye', 'Rye', 7213221699, 'tryeho@etsy.com'
);

/* INSERT QUERY NO: 638 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
163700, 'TR163700', 'Haywood', 'Rolse', 4056162867, 'hrolsehp@addtoany.com'
);

/* INSERT QUERY NO: 639 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
163800, 'TR163800', 'Korey', 'Culvey', 9486139767, 'kculveyhq@livejournal.com'
);

/* INSERT QUERY NO: 640 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
163900, 'TR163900', 'Greg', 'Belvard', 5693243208, 'gbelvardhr@hc360.com'
);

/* INSERT QUERY NO: 641 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
164000, 'TR164000', 'Nicholas', 'Randall', 4998779590, 'nrandallhs@hhs.gov'
);

/* INSERT QUERY NO: 642 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
164100, 'TR164100', 'Allayne', 'Dettmar', 1494419827, 'adettmarht@miitbeian.gov.cn'
);

/* INSERT QUERY NO: 643 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
164200, 'TR164200', 'Stormie', 'Balfre', 5648547458, 'sbalfrehu@t.co'
);

/* INSERT QUERY NO: 644 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
164300, 'TR164300', 'Dalston', 'McCaig', 3114453845, 'dmccaighv@engadget.com'
);

/* INSERT QUERY NO: 645 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
164400, 'TR164400', 'Dmitri', 'Nudds', 6414841658, 'dnuddshw@amazon.co.jp'
);

/* INSERT QUERY NO: 646 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
164500, 'TR164500', 'Daisie', 'Anselm', 4853273034, 'danselmhx@statcounter.com'
);

/* INSERT QUERY NO: 647 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
164600, 'TR164600', 'Jasun', 'Howey', 5195507435, 'jhoweyhy@ucsd.edu'
);

/* INSERT QUERY NO: 648 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
164700, 'TR164700', 'Ruddie', 'Wreakes', 8505123471, 'rwreakeshz@wp.com'
);

/* INSERT QUERY NO: 649 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
164800, 'TR164800', 'Killian', 'Wheeliker', 4027734035, 'kwheelikeri0@prlog.org'
);

/* INSERT QUERY NO: 650 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
164900, 'TR164900', 'Franni', 'Battams', 5067471616, 'fbattamsi1@timesonline.co.uk'
);

/* INSERT QUERY NO: 651 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
165000, 'TR165000', 'Shari', 'Bydaway', 1668408677, 'sbydawayi2@psu.edu'
);

/* INSERT QUERY NO: 652 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
165100, 'TR165100', 'Hurley', 'Dodshon', 5742380415, 'hdodshoni3@msu.edu'
);

/* INSERT QUERY NO: 653 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
165200, 'TR165200', 'Isacco', 'Merigon', 1158058936, 'imerigoni4@github.io'
);

/* INSERT QUERY NO: 654 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
165300, 'TR165300', 'Kalila', 'Hillett', 9274779463, 'khilletti5@japanpost.jp'
);

/* INSERT QUERY NO: 655 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
165400, 'TR165400', 'Jacinda', 'Caught', 8152946500, 'jcaughti6@toplist.cz'
);

/* INSERT QUERY NO: 656 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
165500, 'TR165500', 'Doralyn', 'Ravenshear', 6708699746, 'dravensheari7@behance.net'
);

/* INSERT QUERY NO: 657 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
165600, 'TR165600', 'Sheba', 'Hyne', 9127031652, 'shynei8@wikia.com'
);

/* INSERT QUERY NO: 658 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
165700, 'TR165700', 'Rose', 'Burden', 7801718301, 'rburdeni9@jalbum.net'
);

/* INSERT QUERY NO: 659 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
165800, 'TR165800', 'Merrie', 'Aymes', 6402387790, 'maymesia@opensource.org'
);

/* INSERT QUERY NO: 660 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
165900, 'TR165900', 'Edyth', 'Broadhurst', 4917638006, 'ebroadhurstib@yahoo.com'
);

/* INSERT QUERY NO: 661 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
166000, 'TR166000', 'Denise', 'Gerrad', 1327346021, 'dgerradic@prlog.org'
);

/* INSERT QUERY NO: 662 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
166100, 'TR166100', 'Jerrie', 'Seabrook', 3504142797, 'jseabrookid@mac.com'
);

/* INSERT QUERY NO: 663 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
166200, 'TR166200', 'Zack', 'Sheepy', 3051368362, 'zsheepyie@statcounter.com'
);

/* INSERT QUERY NO: 664 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
166300, 'TR166300', 'Kendall', 'Wykey', 6338615725, 'kwykeyif@theglobeandmail.com'
);

/* INSERT QUERY NO: 665 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
166400, 'TR166400', 'Killy', 'SANTAIGO', 3006844852, 'koSANTAIGOig@salon.com'
);

/* INSERT QUERY NO: 666 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
166500, 'TR166500', 'Jennette', 'Redhole', 7005878981, 'jredholeih@altervista.org'
);

/* INSERT QUERY NO: 667 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
166600, 'TR166600', 'Vivi', 'Puckham', 8837115063, 'vpuckhamii@booking.com'
);

/* INSERT QUERY NO: 668 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
166700, 'TR166700', 'Bentley', 'Caslin', 6054249753, 'bcaslinij@networksolutions.com'
);

/* INSERT QUERY NO: 669 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
166800, 'TR166800', 'Tonia', 'Hartin', 3264647211, 'thartinik@51.la'
);

/* INSERT QUERY NO: 670 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
166900, 'TR166900', 'Davy', 'Boecke', 6523164801, 'dboeckeil@youtu.be'
);

/* INSERT QUERY NO: 671 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
167000, 'TR167000', 'Raina', 'Cleminson', 5636318272, 'rcleminsonim@histats.com'
);

/* INSERT QUERY NO: 672 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
167100, 'TR167100', 'Stanfield', 'Huntley', 3682477063, 'shuntleyin@ovh.net'
);

/* INSERT QUERY NO: 673 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
167200, 'TR167200', 'Sharline', 'MacDonough', 8242204400, 'smacdonoughio@macromedia.com'
);

/* INSERT QUERY NO: 674 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
167300, 'TR167300', 'Mel', 'Hellcat', 9355223497, 'mhellcatip@usnews.com'
);

/* INSERT QUERY NO: 675 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
167400, 'TR167400', 'Dud', 'Conford', 3759677555, 'dconfordiq@omniture.com'
);

/* INSERT QUERY NO: 676 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
167500, 'TR167500', 'Lorraine', 'McNevin', 4837039837, 'lmcnevinir@unblog.fr'
);

/* INSERT QUERY NO: 677 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
167600, 'TR167600', 'Tobi', 'Inmett', 6538882591, 'tinmettis@smh.com.au'
);

/* INSERT QUERY NO: 678 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
167700, 'TR167700', 'Dale', 'Moorrud', 5992686656, 'dmoorrudit@exblog.jp'
);

/* INSERT QUERY NO: 679 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
167800, 'TR167800', 'Colet', 'Shirtcliffe', 4611435432, 'cshirtcliffeiu@woothemes.com'
);

/* INSERT QUERY NO: 680 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
167900, 'TR167900', 'Roseanna', 'Paolozzi', 1211098914, 'rpaolozziiv@a8.net'
);

/* INSERT QUERY NO: 681 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
168000, 'TR168000', 'Britney', 'Uccelli', 1434766765, 'buccelliiw@noaa.gov'
);

/* INSERT QUERY NO: 682 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
168100, 'TR168100', 'Dolores', 'Holyland', 9057688876, 'dholylandix@shoppro.jp'
);

/* INSERT QUERY NO: 683 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
168200, 'TR168200', 'Sophronia', 'Domleo', 2113946192, 'sdomleoiy@hugedomains.com'
);

/* INSERT QUERY NO: 684 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
168300, 'TR168300', 'Trudie', 'Ornils', 3306228215, 'tornilsiz@booking.com'
);

/* INSERT QUERY NO: 685 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
168400, 'TR168400', 'Saloma', 'Mee', 1779644814, 'smeej0@eventbrite.com'
);

/* INSERT QUERY NO: 686 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
168500, 'TR168500', 'Alejandra', 'Michie', 2116338744, 'amichiej1@cam.ac.uk'
);

/* INSERT QUERY NO: 687 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
168600, 'TR168600', 'Brianne', 'Lighterness', 1751233717, 'blighternessj2@topsy.com'
);

/* INSERT QUERY NO: 688 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
168700, 'TR168700', 'Artair', 'Rodenborch', 1152767431, 'arodenborchj3@marketwatch.com'
);

/* INSERT QUERY NO: 689 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
168800, 'TR168800', 'Cthrine', 'Lohden', 8464506358, 'clohdenj4@disqus.com'
);

/* INSERT QUERY NO: 690 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
168900, 'TR168900', 'Bradly', 'Philipson', 7736785707, 'bphilipsonj5@va.gov'
);

/* INSERT QUERY NO: 691 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
169000, 'TR169000', 'Conway', 'Brannon', 5573839558, 'cbrannonj6@walmart.com'
);

/* INSERT QUERY NO: 692 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
169100, 'TR169100', 'Evie', 'De Cristoforo', 3731427035, 'edecristoforoj7@bbb.org'
);

/* INSERT QUERY NO: 693 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
169200, 'TR169200', 'Gerta', 'Tante', 7491765846, 'gtantej8@examiner.com'
);

/* INSERT QUERY NO: 694 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
169300, 'TR169300', 'Benoit', 'Forsbey', 5828865456, 'bforsbeyj9@walmart.com'
);

/* INSERT QUERY NO: 695 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
169400, 'TR169400', 'Orland', 'Christley', 5078908870, 'ochristleyja@hubpages.com'
);

/* INSERT QUERY NO: 696 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
169500, 'TR169500', 'Meara', 'Mizzen', 8559891963, 'mmizzenjb@tiny.cc'
);

/* INSERT QUERY NO: 697 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
169600, 'TR169600', 'Olwen', 'Leithgoe', 2349194121, 'oleithgoejc@businessinsider.com'
);

/* INSERT QUERY NO: 698 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
169700, 'TR169700', 'Job', 'Bank', 7086213918, 'jbankjd@ehow.com'
);

/* INSERT QUERY NO: 699 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
169800, 'TR169800', 'Marven', 'Hellyer', 2737502352, 'mhellyerje@craigslist.org'
);

/* INSERT QUERY NO: 700 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
169900, 'TR169900', 'Adrianna', 'Doram', 3792599513, 'adoramjf@yellowpages.com'
);

/* INSERT QUERY NO: 701 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
170000, 'TR170000', 'Charlot', 'Caldero', 7426453861, 'ccalderojg@wisc.edu'
);

/* INSERT QUERY NO: 702 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
170100, 'TR170100', 'Barn', 'Kendall', 1891894514, 'bkendalljh@howstuffworks.com'
);

/* INSERT QUERY NO: 703 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
170200, 'TR170200', 'Jody', 'Newbery', 5739906701, 'jnewberyji@artisteer.com'
);

/* INSERT QUERY NO: 704 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
170300, 'TR170300', 'Tommi', 'Doore', 3512914580, 'tdoorejj@ucla.edu'
);

/* INSERT QUERY NO: 705 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
170400, 'TR170400', 'Carissa', 'Tootin', 5599213131, 'ctootinjk@forbes.com'
);

/* INSERT QUERY NO: 706 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
170500, 'TR170500', 'Doe', 'Ewbank', 9374625301, 'dewbankjl@mtv.com'
);

/* INSERT QUERY NO: 707 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
170600, 'TR170600', 'Klemens', 'Mizzi', 2582948548, 'kmizzijm@reference.com'
);

/* INSERT QUERY NO: 708 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
170700, 'TR170700', 'Karalee', 'Maeer', 4209375292, 'kmaeerjn@myspace.com'
);

/* INSERT QUERY NO: 709 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
170800, 'TR170800', 'Celeste', 'ODuane', 8921210733, 'coduanejo@bluehost.com'
);

/* INSERT QUERY NO: 710 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
170900, 'TR170900', 'Derry', 'Tomsen', 1364108492, 'dtomsenjp@netscape.com'
);

/* INSERT QUERY NO: 711 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
171000, 'TR171000', 'Mureil', 'Garbert', 3152710941, 'mgarbertjq@elegantthemes.com'
);

/* INSERT QUERY NO: 712 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
171100, 'TR171100', 'Carmencita', 'Mc Mechan', 8181791435, 'cmcmechanjr@miitbeian.gov.cn'
);

/* INSERT QUERY NO: 713 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
171200, 'TR171200', 'Malina', 'Ryott', 6689791195, 'mryottjs@chron.com'
);

/* INSERT QUERY NO: 714 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
171300, 'TR171300', 'Gale', 'Joubert', 1934044669, 'gjoubertjt@pen.io'
);

/* INSERT QUERY NO: 715 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
171400, 'TR171400', 'Kitti', 'Addis', 4441889363, 'kaddisju@ebay.co.uk'
);

/* INSERT QUERY NO: 716 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
171500, 'TR171500', 'Dania', 'Grandison', 7165071350, 'dgrandisonjv@europa.eu'
);

/* INSERT QUERY NO: 717 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
171600, 'TR171600', 'Leigh', 'Dornin', 5802090234, 'ldorninjw@creativecommons.org'
);

/* INSERT QUERY NO: 718 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
171700, 'TR171700', 'Miriam', 'McClenan', 5602443027, 'mmcclenanjx@prlog.org'
);

/* INSERT QUERY NO: 719 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
171800, 'TR171800', 'Giffard', 'Scardefield', 8964206110, 'gscardefieldjy@1688.com'
);

/* INSERT QUERY NO: 720 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
171900, 'TR171900', 'Gabe', 'Colerick', 9427357203, 'gcolerickjz@usatoday.com'
);

/* INSERT QUERY NO: 721 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
172000, 'TR172000', 'Arlie', 'Yukhnev', 6166603239, 'ayukhnevk0@japanpost.jp'
);

/* INSERT QUERY NO: 722 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
172100, 'TR172100', 'Greta', 'Sara', 5064651377, 'gsarak1@guardian.co.uk'
);

/* INSERT QUERY NO: 723 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
172200, 'TR172200', 'Benedict', 'Buckles', 3671158926, 'bbucklesk2@vkontakte.ru'
);

/* INSERT QUERY NO: 724 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
172300, 'TR172300', 'Waylon', 'Leport', 4746587855, 'wleportk3@amazon.co.uk'
);

/* INSERT QUERY NO: 725 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
172400, 'TR172400', 'Meredeth', 'Crates', 3971948033, 'mcratesk4@plala.or.jp'
);

/* INSERT QUERY NO: 726 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
172500, 'TR172500', 'Lea', 'Camois', 2688607430, 'lcamoisk5@php.net'
);

/* INSERT QUERY NO: 727 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
172600, 'TR172600', 'Rodie', 'Jeremaes', 7381142861, 'rjeremaesk6@theglobeandmail.com'
);

/* INSERT QUERY NO: 728 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
172700, 'TR172700', 'Robbin', 'Titmus', 1973069519, 'rtitmusk7@wunderground.com'
);

/* INSERT QUERY NO: 729 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
172800, 'TR172800', 'Abby', 'Greenley', 4883790866, 'agreenleyk8@1688.com'
);

/* INSERT QUERY NO: 730 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
172900, 'TR172900', 'Thacher', 'Sarfass', 6175971320, 'tsarfassk9@linkedin.com'
);

/* INSERT QUERY NO: 731 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
173000, 'TR173000', 'Kennith', 'Culshaw', 9156976561, 'kculshawka@boston.com'
);

/* INSERT QUERY NO: 732 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
173100, 'TR173100', 'Lorilyn', 'Behninck', 7002348727, 'lbehninckkb@webeden.co.uk'
);

/* INSERT QUERY NO: 733 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
173200, 'TR173200', 'Mariette', 'Follos', 3832821282, 'mfolloskc@house.gov'
);

/* INSERT QUERY NO: 734 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
173300, 'TR173300', 'Hadleigh', 'Pemble', 2395066374, 'hpemblekd@goodreads.com'
);

/* INSERT QUERY NO: 735 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
173400, 'TR173400', 'Ashil', 'Riccioppo', 8446728470, 'ariccioppoke@hostgator.com'
);

/* INSERT QUERY NO: 736 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
173500, 'TR173500', 'Marissa', 'Tollady', 9359364728, 'mtolladykf@netvibes.com'
);

/* INSERT QUERY NO: 737 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
173600, 'TR173600', 'Jimmy', 'Stuchbury', 6985936493, 'jstuchburykg@fc2.com'
);

/* INSERT QUERY NO: 738 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
173700, 'TR173700', 'Charles', 'Roe', 3995914114, 'croekh@yale.edu'
);

/* INSERT QUERY NO: 739 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
173800, 'TR173800', 'Roger', 'Phizakarley', 7287430547, 'rphizakarleyki@4shared.com'
);

/* INSERT QUERY NO: 740 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
173900, 'TR173900', 'Fayth', 'Spedding', 1033776559, 'fspeddingkj@theguardian.com'
);

/* INSERT QUERY NO: 741 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
174000, 'TR174000', 'Collie', 'Brodnecke', 8371301917, 'cbrodneckekk@fema.gov'
);

/* INSERT QUERY NO: 742 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
174100, 'TR174100', 'Augustus', 'Bloodworthe', 7251676930, 'abloodworthekl@w3.org'
);

/* INSERT QUERY NO: 743 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
174200, 'TR174200', 'Siegfried', 'Wiltshaw', 9381090623, 'swiltshawkm@hp.com'
);

/* INSERT QUERY NO: 744 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
174300, 'TR174300', 'Grayce', 'Halls', 6117760412, 'ghallskn@shareasale.com'
);

/* INSERT QUERY NO: 745 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
174400, 'TR174400', 'Karalynn', 'St. Paul', 4729261091, 'kstpaulko@zimbio.com'
);

/* INSERT QUERY NO: 746 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
174500, 'TR174500', 'Kikelia', 'Hrihorovich', 6127703989, 'khrihorovichkp@jiathis.com'
);

/* INSERT QUERY NO: 747 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
174600, 'TR174600', 'Freida', 'Pedel', 6779493277, 'fpedelkq@time.com'
);

/* INSERT QUERY NO: 748 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
174700, 'TR174700', 'Moe', 'Alves', 4339617354, 'malveskr@bigcartel.com'
);

/* INSERT QUERY NO: 749 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
174800, 'TR174800', 'Chic', 'Genn', 6056685836, 'cgennks@google.it'
);

/* INSERT QUERY NO: 750 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
174900, 'TR174900', 'Daveta', 'Wayte', 4233965541, 'dwaytekt@dell.com'
);

/* INSERT QUERY NO: 751 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
175000, 'TR175000', 'Kipper', 'Frandsen', 9513006072, 'kfrandsenku@dell.com'
);

/* INSERT QUERY NO: 752 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
175100, 'TR175100', 'Gaile', 'Petriello', 5709143307, 'gpetriellokv@instagram.com'
);

/* INSERT QUERY NO: 753 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
175200, 'TR175200', 'Byrom', 'Marte', 1587955925, 'bmartekw@springer.com'
);

/* INSERT QUERY NO: 754 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
175300, 'TR175300', 'Frederich', 'Iddy', 8937320261, 'fiddykx@timesonline.co.uk'
);

/* INSERT QUERY NO: 755 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
175400, 'TR175400', 'Anica', 'Kidman', 7753119888, 'akidmanky@biglobe.ne.jp'
);

/* INSERT QUERY NO: 756 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
175500, 'TR175500', 'Jobie', 'Lampart', 8753787974, 'jlampartkz@microsoft.com'
);

/* INSERT QUERY NO: 757 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
175600, 'TR175600', 'Jennine', 'Inglesent', 8007015440, 'jinglesentl0@ucoz.ru'
);

/* INSERT QUERY NO: 758 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
175700, 'TR175700', 'Chantalle', 'Baigent', 1901071691, 'cbaigentl1@epa.gov'
);

/* INSERT QUERY NO: 759 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
175800, 'TR175800', 'Odessa', 'Hateley', 8378313324, 'ohateleyl2@dell.com'
);

/* INSERT QUERY NO: 760 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
175900, 'TR175900', 'Bobbi', 'Casotti', 7313620810, 'bcasottil3@mtv.com'
);

/* INSERT QUERY NO: 761 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
176000, 'TR176000', 'Ezri', 'Flisher', 5182109482, 'eflisherl4@google.co.jp'
);

/* INSERT QUERY NO: 762 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
176100, 'TR176100', 'Shelley', 'Colquete', 6802909115, 'scolquetel5@oaic.gov.au'
);

/* INSERT QUERY NO: 763 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
176200, 'TR176200', 'Karyn', 'Sainte Paul', 8492841827, 'ksaintepaull6@techcrunch.com'
);

/* INSERT QUERY NO: 764 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
176300, 'TR176300', 'Chrissie', 'Tetlow', 6697695371, 'ctetlowl7@forbes.com'
);

/* INSERT QUERY NO: 765 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
176400, 'TR176400', 'Ally', 'Basford', 2688900308, 'abasfordl8@tiny.cc'
);

/* INSERT QUERY NO: 766 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
176500, 'TR176500', 'Oran', 'Confait', 4016915684, 'oconfaitl9@ask.com'
);

/* INSERT QUERY NO: 767 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
176600, 'TR176600', 'Tamarra', 'Corbet', 9097211798, 'tcorbetla@sbwire.com'
);

/* INSERT QUERY NO: 768 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
176700, 'TR176700', 'Annamarie', 'Millan', 2253351023, 'amillanlb@cisco.com'
);

/* INSERT QUERY NO: 769 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
176800, 'TR176800', 'Carissa', 'Chilley', 4942745527, 'cchilleylc@ning.com'
);

/* INSERT QUERY NO: 770 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
176900, 'TR176900', 'Kandace', 'Lorrimer', 6109912390, 'klorrimerld@devhub.com'
);

/* INSERT QUERY NO: 771 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
177000, 'TR177000', 'Marketa', 'Zaple', 8573810180, 'mzaplele@webs.com'
);

/* INSERT QUERY NO: 772 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
177100, 'TR177100', 'Maudie', 'Eldrid', 3894789853, 'meldridlf@discovery.com'
);

/* INSERT QUERY NO: 773 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
177200, 'TR177200', 'De', 'Blance', 1455586648, 'dblancelg@bing.com'
);

/* INSERT QUERY NO: 774 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
177300, 'TR177300', 'Karlene', 'Kohring', 8129548149, 'kkohringlh@aol.com'
);

/* INSERT QUERY NO: 775 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
177400, 'TR177400', 'Maudie', 'St Ledger', 4104349960, 'mstledgerli@seesaa.net'
);

/* INSERT QUERY NO: 776 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
177500, 'TR177500', 'Hurley', 'Chessun', 3094030727, 'hchessunlj@fc2.com'
);

/* INSERT QUERY NO: 777 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
177600, 'TR177600', 'Ayn', 'Cready', 5352164353, 'acreadylk@chron.com'
);

/* INSERT QUERY NO: 778 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
177700, 'TR177700', 'Randee', 'Cloughton', 6315718370, 'rcloughtonll@chicagotribune.com'
);

/* INSERT QUERY NO: 779 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
177800, 'TR177800', 'Weber', 'Carbett', 4651192183, 'wcarbettlm@alexa.com'
);

/* INSERT QUERY NO: 780 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
177900, 'TR177900', 'Mariejeanne', 'Oxenbury', 7939086486, 'moxenburyln@g.co'
);

/* INSERT QUERY NO: 781 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
178000, 'TR178000', 'Brynn', 'Vassel', 5927925881, 'bvassello@usda.gov'
);

/* INSERT QUERY NO: 782 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
178100, 'TR178100', 'Lay', 'Smeath', 4628949493, 'lsmeathlp@comcast.net'
);

/* INSERT QUERY NO: 783 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
178200, 'TR178200', 'Faber', 'Kreuzer', 1042091248, 'fkreuzerlq@arstechnica.com'
);

/* INSERT QUERY NO: 784 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
178300, 'TR178300', 'Mar', 'Sidebotton', 7382023217, 'msidebottonlr@washington.edu'
);

/* INSERT QUERY NO: 785 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
178400, 'TR178400', 'Tirrell', 'Driffe', 3486269818, 'tdriffels@unesco.org'
);

/* INSERT QUERY NO: 786 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
178500, 'TR178500', 'Domini', 'Reeveley', 9244858568, 'dreeveleylt@answers.com'
);

/* INSERT QUERY NO: 787 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
178600, 'TR178600', 'Portia', 'Betteriss', 4107867429, 'pbetterisslu@wordpress.org'
);

/* INSERT QUERY NO: 788 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
178700, 'TR178700', 'Deb', 'Schachter', 9985940768, 'dschachterlv@cocolognifty.com'
);

/* INSERT QUERY NO: 789 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
178800, 'TR178800', 'Hallsy', 'Doreward', 8299325465, 'hdorewardlw@hatena.ne.jp'
);

/* INSERT QUERY NO: 790 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
178900, 'TR178900', 'Loleta', 'Karczinski', 1835032209, 'lkarczinskilx@weather.com'
);

/* INSERT QUERY NO: 791 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
179000, 'TR179000', 'Iolanthe', 'DErrico', 7873631650, 'iderricoly@etsy.com'
);

/* INSERT QUERY NO: 792 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
179100, 'TR179100', 'Mignon', 'Staveley', 9217204765, 'mstaveleylz@clickbank.net'
);

/* INSERT QUERY NO: 793 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
179200, 'TR179200', 'Georgina', 'Impson', 8033979274, 'gimpsonm0@trellian.com'
);

/* INSERT QUERY NO: 794 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
179300, 'TR179300', 'Spense', 'Langdridge', 8875962460, 'slangdridgem1@google.ru'
);

/* INSERT QUERY NO: 795 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
179400, 'TR179400', 'Glyn', 'Weiss', 4085988818, 'gweissm2@google.pl'
);

/* INSERT QUERY NO: 796 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
179500, 'TR179500', 'Alisun', 'Liddiard', 9386678534, 'aliddiardm3@opera.com'
);

/* INSERT QUERY NO: 797 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
179600, 'TR179600', 'Cosmo', 'Argo', 9795227539, 'cargom4@kickstarter.com'
);

/* INSERT QUERY NO: 798 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
179700, 'TR179700', 'Clywd', 'Hedin', 9847898415, 'chedinm5@nifty.com'
);

/* INSERT QUERY NO: 799 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
179800, 'TR179800', 'Kaycee', 'Critcher', 1751717538, 'kcritcherm6@ibm.com'
);

/* INSERT QUERY NO: 800 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
179900, 'TR179900', 'Winfred', 'Hainning', 4313982698, 'whainningm7@fotki.com'
);

/* INSERT QUERY NO: 801 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
180000, 'TR180000', 'Mary', 'Arber', 6218823184, 'marberm8@vk.com'
);

/* INSERT QUERY NO: 802 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
180100, 'TR180100', 'Beniamino', 'Voce', 7836698846, 'bvocem9@nps.gov'
);

/* INSERT QUERY NO: 803 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
180200, 'TR180200', 'Lori', 'Sowman', 7458330624, 'lsowmanma@is.gd'
);

/* INSERT QUERY NO: 804 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
180300, 'TR180300', 'Zea', 'Redford', 8328920522, 'zredfordmb@mayoclinic.com'
);

/* INSERT QUERY NO: 805 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
180400, 'TR180400', 'Sheff', 'Vasilov', 6193132572, 'svasilovmc@skype.com'
);

/* INSERT QUERY NO: 806 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
180500, 'TR180500', 'Margeaux', 'Peers', 5652986054, 'mpeersmd@1und1.de'
);

/* INSERT QUERY NO: 807 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
180600, 'TR180600', 'Suki', 'Kingshott', 8507689073, 'skingshottme@myspace.com'
);

/* INSERT QUERY NO: 808 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
180700, 'TR180700', 'Muffin', 'Reisenberg', 6781912647, 'mreisenbergmf@weibo.com'
);

/* INSERT QUERY NO: 809 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
180800, 'TR180800', 'Eldredge', 'Stobbes', 7082182497, 'estobbesmg@illinois.edu'
);

/* INSERT QUERY NO: 810 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
180900, 'TR180900', 'Ferrel', 'Gierek', 5731930651, 'fgierekmh@hao123.com'
);

/* INSERT QUERY NO: 811 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
181000, 'TR181000', 'Tilly', 'Lattimer', 7336398198, 'tlattimermi@youtu.be'
);

/* INSERT QUERY NO: 812 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
181100, 'TR181100', 'Em', 'Jendrassik', 3047342044, 'ejendrassikmj@sina.com.cn'
);

/* INSERT QUERY NO: 813 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
181200, 'TR181200', 'Buiron', 'Maffia', 7628313880, 'bmaffiamk@desdev.cn'
);

/* INSERT QUERY NO: 814 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
181300, 'TR181300', 'Konstanze', 'Eyer', 3187890460, 'keyerml@4shared.com'
);

/* INSERT QUERY NO: 815 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
181400, 'TR181400', 'Emery', 'Scrauniage', 2705492961, 'escrauniagemm@canalblog.com'
);

/* INSERT QUERY NO: 816 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
181500, 'TR181500', 'Dolley', 'Davie', 2325838977, 'ddaviemn@sogou.com'
);

/* INSERT QUERY NO: 817 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
181600, 'TR181600', 'Lisa', 'Piola', 3716720045, 'lpiolamo@oaic.gov.au'
);

/* INSERT QUERY NO: 818 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
181700, 'TR181700', 'Fenelia', 'Winkle', 7309775393, 'fwinklemp@blogger.com'
);

/* INSERT QUERY NO: 819 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
181800, 'TR181800', 'Glynda', 'Craze', 6965428352, 'gcrazemq@posterous.com'
);

/* INSERT QUERY NO: 820 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
181900, 'TR181900', 'Angus', 'Jaukovic', 2601264518, 'ajaukovicmr@sciencedaily.com'
);

/* INSERT QUERY NO: 821 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
182000, 'TR182000', 'Gardy', 'Briscoe', 8115347654, 'gbriscoems@state.tx.us'
);

/* INSERT QUERY NO: 822 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
182100, 'TR182100', 'Sherie', 'Curnow', 2271571640, 'scurnowmt@com.com'
);

/* INSERT QUERY NO: 823 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
182200, 'TR182200', 'Antone', 'MacKeig', 6968687342, 'amackeigmu@vistaprint.com'
);

/* INSERT QUERY NO: 824 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
182300, 'TR182300', 'Artemis', 'MacConnel', 4965882908, 'amacconnelmv@vkontakte.ru'
);

/* INSERT QUERY NO: 825 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
182400, 'TR182400', 'Haskel', 'Mason', 4699600885, 'hmasonmw@accuweather.com'
);

/* INSERT QUERY NO: 826 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
182500, 'TR182500', 'Otes', 'Deam', 3146721286, 'odeammx@cdbaby.com'
);

/* INSERT QUERY NO: 827 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
182600, 'TR182600', 'Emogene', 'Cadamy', 1443079034, 'ecadamymy@digg.com'
);

/* INSERT QUERY NO: 828 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
182700, 'TR182700', 'Trixy', 'Restall', 4538009374, 'trestallmz@about.me'
);

/* INSERT QUERY NO: 829 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
182800, 'TR182800', 'Torre', 'Carabine', 5204964291, 'tcarabinen0@exblog.jp'
);

/* INSERT QUERY NO: 830 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
182900, 'TR182900', 'Rinaldo', 'Duckitt', 5499404179, 'rduckittn1@slashdot.org'
);

/* INSERT QUERY NO: 831 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
183000, 'TR183000', 'Cornela', 'Trewhela', 2191543554, 'ctrewhelan2@bizjournals.com'
);

/* INSERT QUERY NO: 832 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
183100, 'TR183100', 'Sybille', 'Garfath', 9231983822, 'sgarfathn3@multiply.com'
);

/* INSERT QUERY NO: 833 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
183200, 'TR183200', 'Pincus', 'Maneylaws', 2323550190, 'pmaneylawsn4@about.me'
);

/* INSERT QUERY NO: 834 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
183300, 'TR183300', 'Mayor', 'Fredson', 4743682504, 'mfredsonn5@odnoklassniki.ru'
);

/* INSERT QUERY NO: 835 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
183400, 'TR183400', 'Robbin', 'Jowitt', 3613505765, 'rjowittn6@mlb.com'
);

/* INSERT QUERY NO: 836 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
183500, 'TR183500', 'Averill', 'Kitson', 4208965248, 'akitsonn7@apple.com'
);

/* INSERT QUERY NO: 837 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
183600, 'TR183600', 'Herminia', 'Foale', 9304636573, 'hfoalen8@hp.com'
);

/* INSERT QUERY NO: 838 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
183700, 'TR183700', 'Carolann', 'Wingham', 2201483590, 'cwinghamn9@ifeng.com'
);

/* INSERT QUERY NO: 839 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
183800, 'TR183800', 'Cullan', 'Sneyd', 9028342809, 'csneydna@adobe.com'
);

/* INSERT QUERY NO: 840 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
183900, 'TR183900', 'Sibelle', 'Turnor', 5879464319, 'sturnornb@joomla.org'
);

/* INSERT QUERY NO: 841 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
184000, 'TR184000', 'Malachi', 'Hursthouse', 3224514174, 'mhursthousenc@cbc.ca'
);

/* INSERT QUERY NO: 842 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
184100, 'TR184100', 'Kathryn', 'Foulds', 5265116747, 'kfouldsnd@com.com'
);

/* INSERT QUERY NO: 843 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
184200, 'TR184200', 'Matilda', 'Cheverton', 9336962725, 'mchevertonne@lycos.com'
);

/* INSERT QUERY NO: 844 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
184300, 'TR184300', 'Risa', 'Pocklington', 4603040943, 'rpocklingtonnf@liveinternet.ru'
);

/* INSERT QUERY NO: 845 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
184400, 'TR184400', 'Vittorio', 'Tiley', 4881273288, 'vtileyng@fastcompany.com'
);

/* INSERT QUERY NO: 846 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
184500, 'TR184500', 'Sheri', 'Brimman', 8005970351, 'sbrimmannh@jimdo.com'
);

/* INSERT QUERY NO: 847 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
184600, 'TR184600', 'Seymour', 'Hancell', 9648722989, 'shancellni@constantcontact.com'
);

/* INSERT QUERY NO: 848 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
184700, 'TR184700', 'Perren', 'Kirmond', 3492606098, 'pkirmondnj@noaa.gov'
);

/* INSERT QUERY NO: 849 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
184800, 'TR184800', 'Bendicty', 'Cutts', 7047165748, 'bcuttsnk@youtu.be'
);

/* INSERT QUERY NO: 850 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
184900, 'TR184900', 'Jarrad', 'Huxtable', 4965007991, 'jhuxtablenl@ovh.net'
);

/* INSERT QUERY NO: 851 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
185000, 'TR185000', 'Ramsey', 'Kett', 6256582100, 'rkettnm@sohu.com'
);

/* INSERT QUERY NO: 852 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
185100, 'TR185100', 'Dunn', 'Gillcrist', 2127816222, 'dgillcristnn@skype.com'
);

/* INSERT QUERY NO: 853 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
185200, 'TR185200', 'Loy', 'Pyrke', 9126482960, 'lpyrkeno@github.io'
);

/* INSERT QUERY NO: 854 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
185300, 'TR185300', 'Brose', 'Kitson', 2363407808, 'bkitsonnp@bloglines.com'
);

/* INSERT QUERY NO: 855 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
185400, 'TR185400', 'Danielle', 'Crevy', 8438420935, 'dcrevynq@spotify.com'
);

/* INSERT QUERY NO: 856 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
185500, 'TR185500', 'Taber', 'Blooman', 5176697158, 'tbloomannr@rambler.ru'
);

/* INSERT QUERY NO: 857 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
185600, 'TR185600', 'Lotta', 'Paggitt', 2325137183, 'lpaggittns@forbes.com'
);

/* INSERT QUERY NO: 858 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
185700, 'TR185700', 'Tedi', 'Skelington', 1318190170, 'tskelingtonnt@sakura.ne.jp'
);

/* INSERT QUERY NO: 859 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
185800, 'TR185800', 'Adria', 'Birley', 4737719951, 'abirleynu@sciencedaily.com'
);

/* INSERT QUERY NO: 860 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
185900, 'TR185900', 'Grady', 'Henken', 9484871020, 'ghenkennv@hatena.ne.jp'
);

/* INSERT QUERY NO: 861 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
186000, 'TR186000', 'Gisele', 'McCambridge', 8768412389, 'gmccambridgenw@amazon.co.jp'
);

/* INSERT QUERY NO: 862 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
186100, 'TR186100', 'Neda', 'Fruser', 3742676970, 'nfrusernx@printfriendly.com'
);

/* INSERT QUERY NO: 863 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
186200, 'TR186200', 'Alec', 'Audiss', 6605313710, 'aaudissny@chicagotribune.com'
);

/* INSERT QUERY NO: 864 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
186300, 'TR186300', 'Olva', 'Cloney', 5112628307, 'ocloneynz@ezinearticles.com'
);

/* INSERT QUERY NO: 865 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
186400, 'TR186400', 'Del', 'Janus', 1719263668, 'djanuso0@shoppro.jp'
);

/* INSERT QUERY NO: 866 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
186500, 'TR186500', 'Anneliese', 'Jerrom', 5983627071, 'ajerromo1@posterous.com'
);

/* INSERT QUERY NO: 867 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
186600, 'TR186600', 'Alleyn', 'Ochterlony', 4693658141, 'aochterlonyo2@arstechnica.com'
);

/* INSERT QUERY NO: 868 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
186700, 'TR186700', 'Corney', 'Endrizzi', 4841195620, 'cendrizzio3@dropbox.com'
);

/* INSERT QUERY NO: 869 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
186800, 'TR186800', 'Sherrie', 'McKenney', 3622425068, 'smckenneyo4@blogtalkradio.com'
);

/* INSERT QUERY NO: 870 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
186900, 'TR186900', 'Cristy', 'Waddicor', 7444686183, 'cwaddicoro5@stumbleupon.com'
);

/* INSERT QUERY NO: 871 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
187000, 'TR187000', 'Anya', 'Dickinson', 2472222849, 'adickinsono6@ucsd.edu'
);

/* INSERT QUERY NO: 872 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
187100, 'TR187100', 'Lorilee', 'Purkess', 7234812290, 'lpurkesso7@jigsy.com'
);

/* INSERT QUERY NO: 873 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
187200, 'TR187200', 'Caril', 'Robarts', 1681431554, 'crobartso8@overblog.com'
);

/* INSERT QUERY NO: 874 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
187300, 'TR187300', 'Lanny', 'Nise', 1396212412, 'lniseo9@homestead.com'
);

/* INSERT QUERY NO: 875 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
187400, 'TR187400', 'Bastian', 'Paaso', 7898198574, 'bpaasooa@arstechnica.com'
);

/* INSERT QUERY NO: 876 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
187500, 'TR187500', 'Collen', 'Frampton', 4381987273, 'cframptonob@who.int'
);

/* INSERT QUERY NO: 877 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
187600, 'TR187600', 'Rania', 'Hing', 4463509385, 'rhingoc@hubpages.com'
);

/* INSERT QUERY NO: 878 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
187700, 'TR187700', 'Jandy', 'Bringloe', 8282862254, 'jbringloeod@netvibes.com'
);

/* INSERT QUERY NO: 879 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
187800, 'TR187800', 'Emlyn', 'Zuann', 9327105755, 'ezuannoe@tonline.de'
);

/* INSERT QUERY NO: 880 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
187900, 'TR187900', 'Johannah', 'Illingsworth', 3188189304, 'jillingsworthof@cornell.edu'
);

/* INSERT QUERY NO: 881 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
188000, 'TR188000', 'Ryan', 'Scanlin', 4706131101, 'rscanlinog@dagondesign.com'
);

/* INSERT QUERY NO: 882 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
188100, 'TR188100', 'Ruben', 'Salery', 5929275195, 'rsaleryoh@slashdot.org'
);

/* INSERT QUERY NO: 883 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
188200, 'TR188200', 'Gracie', 'Antoniottii', 6438563080, 'gantoniottiioi@hp.com'
);

/* INSERT QUERY NO: 884 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
188300, 'TR188300', 'Lynne', 'Hurlestone', 6738180131, 'lhurlestoneoj@com.com'
);

/* INSERT QUERY NO: 885 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
188400, 'TR188400', 'Adamo', 'Gothliff', 3748260762, 'agothliffok@bizjournals.com'
);

/* INSERT QUERY NO: 886 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
188500, 'TR188500', 'Benetta', 'Suermeiers', 8573841198, 'bsuermeiersol@cnbc.com'
);

/* INSERT QUERY NO: 887 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
188600, 'TR188600', 'Christoforo', 'Caldron', 8224645409, 'ccaldronom@cmu.edu'
);

/* INSERT QUERY NO: 888 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
188700, 'TR188700', 'Jon', 'Abilowitz', 2935735927, 'jabilowitzon@bandcamp.com'
);

/* INSERT QUERY NO: 889 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
188800, 'TR188800', 'Calhoun', 'Sargant', 6854622322, 'csargantoo@csmonitor.com'
);

/* INSERT QUERY NO: 890 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
188900, 'TR188900', 'Tessi', 'Goodier', 9286582392, 'tgoodierop@nyu.edu'
);

/* INSERT QUERY NO: 891 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
189000, 'TR189000', 'Adena', 'Charlot', 9002652181, 'acharlotoq@icq.com'
);

/* INSERT QUERY NO: 892 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
189100, 'TR189100', 'Jacques', 'Wickwar', 2178895672, 'jwickwaror@erecht24.de'
);

/* INSERT QUERY NO: 893 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
189200, 'TR189200', 'Vevay', 'Greenan', 7047825352, 'vgreenanos@mail.ru'
);

/* INSERT QUERY NO: 894 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
189300, 'TR189300', 'Ned', 'Kubanek', 4315654146, 'nkubanekot@statcounter.com'
);

/* INSERT QUERY NO: 895 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
189400, 'TR189400', 'Chrystal', 'Webling', 4583987812, 'cweblingou@liveinternet.ru'
);

/* INSERT QUERY NO: 896 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
189500, 'TR189500', 'Elsi', 'Dearlove', 3588192110, 'edearloveov@princeton.edu'
);

/* INSERT QUERY NO: 897 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
189600, 'TR189600', 'Anastasie', 'Rantoul', 1007003478, 'arantoulow@washington.edu'
);

/* INSERT QUERY NO: 898 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
189700, 'TR189700', 'Fedora', 'Lattka', 5599393438, 'flattkaox@privacy.gov.au'
);

/* INSERT QUERY NO: 899 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
189800, 'TR189800', 'Parker', 'Perillo', 9641115908, 'pperillooy@qq.com'
);

/* INSERT QUERY NO: 900 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
189900, 'TR189900', 'Kayle', 'Harome', 9681234707, 'kharomeoz@icio.us'
);

/* INSERT QUERY NO: 901 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
190000, 'TR190000', 'Drusy', 'Dmtrovic', 5069825885, 'ddmtrovicp0@usda.gov'
);

/* INSERT QUERY NO: 902 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
190100, 'TR190100', 'Doris', 'Smullen', 1784825427, 'dsmullenp1@biglobe.ne.jp'
);

/* INSERT QUERY NO: 903 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
190200, 'TR190200', 'Barbe', 'Lambswood', 2053839186, 'blambswoodp2@webmd.com'
);

/* INSERT QUERY NO: 904 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
190300, 'TR190300', 'Aluin', 'Splevin', 7119181062, 'asplevinp3@delicious.com'
);

/* INSERT QUERY NO: 905 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
190400, 'TR190400', 'Pepe', 'Dransfield', 7585859342, 'pdransfieldp4@latimes.com'
);

/* INSERT QUERY NO: 906 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
190500, 'TR190500', 'Ruthann', 'Razzell', 6459274772, 'rrazzellp5@posterous.com'
);

/* INSERT QUERY NO: 907 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
190600, 'TR190600', 'Aveline', 'Gaveltone', 2189879605, 'agaveltonep6@meetup.com'
);

/* INSERT QUERY NO: 908 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
190700, 'TR190700', 'Carolyne', 'Yerby', 8759044257, 'cyerbyp7@gov.uk'
);

/* INSERT QUERY NO: 909 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
190800, 'TR190800', 'Garald', 'Tuddenham', 2755956871, 'gtuddenhamp8@rambler.ru'
);

/* INSERT QUERY NO: 910 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
190900, 'TR190900', 'Tiertza', 'Grishaev', 2783922736, 'tgrishaevp9@blogs.com'
);

/* INSERT QUERY NO: 911 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
191000, 'TR191000', 'Hortense', 'Ashpital', 6545800766, 'hashpitalpa@earthlink.net'
);

/* INSERT QUERY NO: 912 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
191100, 'TR191100', 'Jaime', 'McKaile', 4087584131, 'jmckailepb@wikispaces.com'
);

/* INSERT QUERY NO: 913 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
191200, 'TR191200', 'Mona', 'Mahady', 6951482529, 'mmahadypc@webeden.co.uk'
);

/* INSERT QUERY NO: 914 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
191300, 'TR191300', 'Gabby', 'Mulliss', 8069628593, 'gmullisspd@yandex.ru'
);

/* INSERT QUERY NO: 915 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
191400, 'TR191400', 'Barbra', 'Skews', 2586736390, 'bskewspe@smh.com.au'
);

/* INSERT QUERY NO: 916 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
191500, 'TR191500', 'Jarad', 'Tregensoe', 4305590558, 'jtregensoepf@technorati.com'
);

/* INSERT QUERY NO: 917 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
191600, 'TR191600', 'Lazarus', 'Cregg', 3563082854, 'lcreggpg@buzzfeed.com'
);

/* INSERT QUERY NO: 918 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
191700, 'TR191700', 'Julee', 'Halpine', 2373872961, 'jhalpineph@google.com.hk'
);

/* INSERT QUERY NO: 919 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
191800, 'TR191800', 'Robinette', 'Kingswood', 9834735601, 'rkingswoodpi@cloudflare.com'
);

/* INSERT QUERY NO: 920 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
191900, 'TR191900', 'Adan', 'Rosenau', 6476209665, 'arosenaupj@paginegialle.it'
);

/* INSERT QUERY NO: 921 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
192000, 'TR192000', 'Margarete', 'Chaundy', 2974718703, 'mchaundypk@ihg.com'
);

/* INSERT QUERY NO: 922 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
192100, 'TR192100', 'Travers', 'Haward', 5619215269, 'thawardpl@netlog.com'
);

/* INSERT QUERY NO: 923 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
192200, 'TR192200', 'Marsiella', 'Davitti', 8047804523, 'mdavittipm@wikimedia.org'
);

/* INSERT QUERY NO: 924 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
192300, 'TR192300', 'Dorothea', 'Frizzell', 9432848540, 'dfrizzellpn@wikia.com'
);

/* INSERT QUERY NO: 925 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
192400, 'TR192400', 'Welby', 'Nanelli', 6273587106, 'wnanellipo@wunderground.com'
);

/* INSERT QUERY NO: 926 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
192500, 'TR192500', 'Kai', 'Arnould', 3284369360, 'karnouldpp@networksolutions.com'
);

/* INSERT QUERY NO: 927 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
192600, 'TR192600', 'Vinnie', 'Wiltsher', 6412486567, 'vwiltsherpq@usnews.com'
);

/* INSERT QUERY NO: 928 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
192700, 'TR192700', 'Cathlene', 'Voss', 2598466852, 'cvosspr@rediff.com'
);

/* INSERT QUERY NO: 929 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
192800, 'TR192800', 'Rory', 'Thomasson', 2903590765, 'rthomassonps@amazon.de'
);

/* INSERT QUERY NO: 930 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
192900, 'TR192900', 'August', 'Tibbotts', 2763152333, 'atibbottspt@nymag.com'
);

/* INSERT QUERY NO: 931 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
193000, 'TR193000', 'Aristotle', 'Shovel', 7259106678, 'ashovelpu@hao123.com'
);

/* INSERT QUERY NO: 932 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
193100, 'TR193100', 'Germain', 'Finey', 3535854886, 'gfineypv@va.gov'
);

/* INSERT QUERY NO: 933 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
193200, 'TR193200', 'Emlynne', 'Cumberledge', 1305309669, 'ecumberledgepw@homestead.com'
);

/* INSERT QUERY NO: 934 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
193300, 'TR193300', 'Suzette', 'Huey', 4086191080, 'shueypx@1und1.de'
);

/* INSERT QUERY NO: 935 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
193400, 'TR193400', 'Lefty', 'Balleine', 5105067613, 'lballeinepy@latimes.com'
);

/* INSERT QUERY NO: 936 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
193500, 'TR193500', 'Cinnamon', 'Tompkin', 1114980316, 'ctompkinpz@uol.com.br'
);

/* INSERT QUERY NO: 937 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
193600, 'TR193600', 'Mylo', 'Bothram', 1775448788, 'mbothramq0@prlog.org'
);

/* INSERT QUERY NO: 938 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
193700, 'TR193700', 'Micky', 'Johananoff', 3263698399, 'mjohananoffq1@ebay.co.uk'
);

/* INSERT QUERY NO: 939 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
193800, 'TR193800', 'Eleanor', 'Stellin', 3432994237, 'estellinq2@arstechnica.com'
);

/* INSERT QUERY NO: 940 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
193900, 'TR193900', 'Deidre', 'Phalip', 5151907853, 'dphalipq3@pen.io'
);

/* INSERT QUERY NO: 941 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
194000, 'TR194000', 'Janet', 'Redpath', 7897897613, 'jredpathq4@buzzfeed.com'
);

/* INSERT QUERY NO: 942 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
194100, 'TR194100', 'Rurik', 'Auchterlonie', 4367727065, 'rauchterlonieq5@bizjournals.com'
);

/* INSERT QUERY NO: 943 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
194200, 'TR194200', 'Clerkclaude', 'Mattityahou', 3528348847, 'cmattityahouq6@sourceforge.net'
);

/* INSERT QUERY NO: 944 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
194300, 'TR194300', 'Dudley', 'Kildahl', 6096223153, 'dkildahlq7@umich.edu'
);

/* INSERT QUERY NO: 945 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
194400, 'TR194400', 'Courtnay', 'Morgon', 8704495878, 'cmorgonq8@purevolume.com'
);

/* INSERT QUERY NO: 946 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
194500, 'TR194500', 'Wynny', 'Chisnell', 9544839654, 'wchisnellq9@soup.io'
);

/* INSERT QUERY NO: 947 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
194600, 'TR194600', 'Bord', 'Sambrook', 2052510906, 'bsambrookqa@multiply.com'
);

/* INSERT QUERY NO: 948 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
194700, 'TR194700', 'Ethelbert', 'Seifert', 8094777030, 'eseifertqb@businesswire.com'
);

/* INSERT QUERY NO: 949 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
194800, 'TR194800', 'Dasha', 'Bullick', 5848424298, 'dbullickqc@usnews.com'
);

/* INSERT QUERY NO: 950 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
194900, 'TR194900', 'Nonnah', 'Ketley', 7474075692, 'nketleyqd@edublogs.org'
);

/* INSERT QUERY NO: 951 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
195000, 'TR195000', 'Trudie', 'Tellenbach', 6416370113, 'ttellenbachqe@house.gov'
);

/* INSERT QUERY NO: 952 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
195100, 'TR195100', 'Malia', 'Blakes', 7973229365, 'mblakesqf@quantcast.com'
);

/* INSERT QUERY NO: 953 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
195200, 'TR195200', 'Addia', 'Chilles', 6167014686, 'achillesqg@jiathis.com'
);

/* INSERT QUERY NO: 954 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
195300, 'TR195300', 'Margaretta', 'McRobbie', 3523169875, 'mmcrobbieqh@intel.com'
);

/* INSERT QUERY NO: 955 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
195400, 'TR195400', 'Chelsey', 'Hurndall', 4178037053, 'churndallqi@facebook.com'
);

/* INSERT QUERY NO: 956 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
195500, 'TR195500', 'Todd', 'Jelfs', 2242460155, 'tjelfsqj@ow.ly'
);

/* INSERT QUERY NO: 957 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
195600, 'TR195600', 'Jess', 'Giral', 9285627126, 'jgiralqk@devhub.com'
);

/* INSERT QUERY NO: 958 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
195700, 'TR195700', 'Dorena', 'Ajsik', 9845377601, 'dajsikql@princeton.edu'
);

/* INSERT QUERY NO: 959 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
195800, 'TR195800', 'Stacia', 'OHalligan', 9002025722, 'sohalliganqm@free.fr'
);

/* INSERT QUERY NO: 960 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
195900, 'TR195900', 'Bradney', 'McIsaac', 8794901785, 'bmcisaacqn@businesswire.com'
);

/* INSERT QUERY NO: 961 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
196000, 'TR196000', 'Casper', 'Moscon', 9152419365, 'cmosconqo@unblog.fr'
);

/* INSERT QUERY NO: 962 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
196100, 'TR196100', 'Emogene', 'Piatkow', 4584689015, 'epiatkowqp@people.com.cn'
);

/* INSERT QUERY NO: 963 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
196200, 'TR196200', 'Loni', 'Tilbey', 4564663997, 'ltilbeyqq@clickbank.net'
);

/* INSERT QUERY NO: 964 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
196300, 'TR196300', 'Lianne', 'Cosslett', 7019921319, 'lcosslettqr@wufoo.com'
);

/* INSERT QUERY NO: 965 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
196400, 'TR196400', 'Laetitia', 'Limeburner', 3282459276, 'llimeburnerqs@paypal.com'
);

/* INSERT QUERY NO: 966 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
196500, 'TR196500', 'Isabelita', 'Taudevin', 1093534557, 'itaudevinqt@qq.com'
);

/* INSERT QUERY NO: 967 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
196600, 'TR196600', 'Cleo', 'Worrell', 4349270328, 'cworrellqu@bloglines.com'
);

/* INSERT QUERY NO: 968 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
196700, 'TR196700', 'Clarance', 'Pechacek', 9698606510, 'cpechacekqv@nifty.com'
);

/* INSERT QUERY NO: 969 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
196800, 'TR196800', 'Alameda', 'Rochelle', 8436533482, 'arochelleqw@blogs.com'
);

/* INSERT QUERY NO: 970 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
196900, 'TR196900', 'Katrina', 'McSporon', 3105624186, 'kmcsporonqx@mlb.com'
);

/* INSERT QUERY NO: 971 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
197000, 'TR197000', 'Vasily', 'Lochet', 4436288127, 'vlochetqy@hc360.com'
);

/* INSERT QUERY NO: 972 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
197100, 'TR197100', 'Twyla', 'Seagrave', 3624840006, 'tseagraveqz@is.gd'
);

/* INSERT QUERY NO: 973 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
197200, 'TR197200', 'Christa', 'Munt', 5279883792, 'cmuntr0@hostgator.com'
);

/* INSERT QUERY NO: 974 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
197300, 'TR197300', 'Paulie', 'Lunney', 3168966047, 'plunneyr1@businessinsider.com'
);

/* INSERT QUERY NO: 975 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
197400, 'TR197400', 'Charlot', 'Derle', 1354388606, 'cderler2@accuweather.com'
);

/* INSERT QUERY NO: 976 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
197500, 'TR197500', 'Adoree', 'Croson', 7278287038, 'acrosonr3@theatlantic.com'
);

/* INSERT QUERY NO: 977 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
197600, 'TR197600', 'Agnes', 'Barajaz', 1793528074, 'abarajazr4@merriamwebster.com'
);

/* INSERT QUERY NO: 978 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
197700, 'TR197700', 'Jase', 'Maffioni', 8812708845, 'jmaffionir5@tmall.com'
);

/* INSERT QUERY NO: 979 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
197800, 'TR197800', 'Bat', 'Bromage', 4175010006, 'bbromager6@artisteer.com'
);

/* INSERT QUERY NO: 980 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
197900, 'TR197900', 'Sydelle', 'Scrivener', 4071849987, 'sscrivenerr7@bluehost.com'
);

/* INSERT QUERY NO: 981 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
198000, 'TR198000', 'Emerson', 'Nanetti', 3316767291, 'enanettir8@networksolutions.com'
);

/* INSERT QUERY NO: 982 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
198100, 'TR198100', 'Gennie', 'Scardifield', 4007236495, 'gscardifieldr9@cdbaby.com'
);

/* INSERT QUERY NO: 983 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
198200, 'TR198200', 'Kora', 'Merkel', 1526569742, 'kmerkelra@hhs.gov'
);

/* INSERT QUERY NO: 984 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
198300, 'TR198300', 'Ingunna', 'Eakly', 9736043699, 'ieaklyrb@economist.com'
);

/* INSERT QUERY NO: 985 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
198400, 'TR198400', 'Toddie', 'Degan', 6456581970, 'tdeganrc@businesswire.com'
);

/* INSERT QUERY NO: 986 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
198500, 'TR198500', 'Arnaldo', 'Kingsland', 4226307212, 'akingslandrd@prweb.com'
);

/* INSERT QUERY NO: 987 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
198600, 'TR198600', 'Beauregard', 'Pea', 9896023767, 'bpeare@etsy.com'
);

/* INSERT QUERY NO: 988 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
198700, 'TR198700', 'Pearl', 'Yandle', 2759025070, 'pyandlerf@princeton.edu'
);

/* INSERT QUERY NO: 989 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
198800, 'TR198800', 'Julita', 'La Vigne', 9153194486, 'jlavignerg@macromedia.com'
);

/* INSERT QUERY NO: 990 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
198900, 'TR198900', 'Opal', 'Lipprose', 2607189231, 'olipproserh@github.io'
);

/* INSERT QUERY NO: 991 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
199000, 'TR199000', 'Starlin', 'Bragginton', 1708810838, 'sbraggintonri@accuweather.com'
);

/* INSERT QUERY NO: 992 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
199100, 'TR199100', 'Sigfrid', 'Martusov', 8369176830, 'smartusovrj@usda.gov'
);

/* INSERT QUERY NO: 993 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
199200, 'TR199200', 'Tatiana', 'Dawidowitz', 1641030719, 'tdawidowitzrk@nih.gov'
);

/* INSERT QUERY NO: 994 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
199300, 'TR199300', 'Winna', 'Wollacott', 5808773829, 'wwollacottrl@wikimedia.org'
);

/* INSERT QUERY NO: 995 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
199400, 'TR199400', 'Lynda', 'Wedon', 9368272836, 'lwedonrm@4shared.com'
);

/* INSERT QUERY NO: 996 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
199500, 'TR199500', 'Adorne', 'Lowin', 7083472800, 'alowinrn@auda.org.au'
);

/* INSERT QUERY NO: 997 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
199600, 'TR199600', 'Boniface', 'Kuschel', 3171625001, 'bkuschelro@oakley.com'
);

/* INSERT QUERY NO: 998 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
199700, 'TR199700', 'Ermina', 'Messenger', 4102380781, 'emessengerrp@kickstarter.com'
);

/* INSERT QUERY NO: 999 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
199800, 'TR199800', 'Zonda', 'Rollings', 6297747399, 'zrollingsrq@vk.com'
);

/* INSERT QUERY NO: 1000 */
INSERT INTO Abogados(Identificacion, TarProfesional, Nombre, Apellido, Telefono, Correo)
VALUES
(
199900, 'TR199900', 'Lucien', 'Oxton', 3767128452, 'loxtonrr@army.mil'
);

