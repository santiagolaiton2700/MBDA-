

/* INSERT QUERY NO: 1 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504621, 'Helaina', 'Date', 'C1', 'N10151', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO151@gmail.com', 4036669125, 10123, 20123
);

/* INSERT QUERY NO: 2 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504622, 'Ogden', 'Chaff', 'C1', 'N10152', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO152@gmail.com', 4036669126, 10125, 20124
);

/* INSERT QUERY NO: 3 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504623, 'Melony', 'Lyddiard', 'C1', 'N10153', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO153@gmail.com', 4036669127, 10126, 20125
);

/* INSERT QUERY NO: 4 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504624, 'Shelley', 'De Zuani', 'C1', 'N10154', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO154@gmail.com', 4036669128, 10127, 20126
);

/* INSERT QUERY NO: 5 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504625, 'Jaymee', 'Chene', 'C1', 'N10155', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO155@gmail.com', 4036669129, 10128, 20127
);

/* INSERT QUERY NO: 6 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504626, 'Julius', 'Gooders', 'C1', 'N10156', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO156@gmail.com', 4036669130, 10129, 20128
);

/* INSERT QUERY NO: 7 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504627, 'Erroll', 'Di Giacomo', 'C1', 'N10157', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO157@gmail.com', 4036669131, 10130, 20129
);

/* INSERT QUERY NO: 8 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504628, 'Ruddie', 'Bainbrigge', 'C1', 'N10158', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO158@gmail.com', 4036669132, 10131, 20130
);

/* INSERT QUERY NO: 9 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504629, 'Alysia', 'Sinden', 'C1', 'N10159', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO159@gmail.com', 4036669133, 10132, 20131
);

/* INSERT QUERY NO: 10 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504630, 'Ely', 'Sulman', 'C1', 'N10160', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO160@gmail.com', 4036669134, 10133, 20132
);

/* INSERT QUERY NO: 11 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504631, 'Seward', 'Sancho', 'C1', 'N10161', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO161@gmail.com', 4036669135, 10134, 20133
);

/* INSERT QUERY NO: 12 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504632, 'Aloisia', 'Traise', 'C1', 'N10162', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO162@gmail.com', 4036669136, 10135, 20134
);

/* INSERT QUERY NO: 13 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504633, 'Reese', 'Matushevich', 'C1', 'N10163', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO163@gmail.com', 4036669137, 10136, 20135
);

/* INSERT QUERY NO: 14 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504634, 'Lucita', 'Kevane', 'C1', 'N10164', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO164@gmail.com', 4036669138, 10137, 20136
);

/* INSERT QUERY NO: 15 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504635, 'Joane', 'MacMurray', 'C1', 'N10165', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO165@gmail.com', 4036669139, 10138, 20137
);

/* INSERT QUERY NO: 16 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504636, 'Caterina', 'Gerren', 'C1', 'N10166', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO166@gmail.com', 4036669140, 10139, 20138
);

/* INSERT QUERY NO: 17 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504637, 'Harman', 'Bigg', 'C1', 'N10167', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO167@gmail.com', 4036669141, 10140, 20139
);

/* INSERT QUERY NO: 18 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504638, 'Idalina', 'Leggen', 'C1', 'N10168', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO168@gmail.com', 4036669142, 10141, 20140
);

/* INSERT QUERY NO: 19 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504639, 'Clarice', 'Borrott', 'C1', 'N10169', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO169@gmail.com', 4036669143, 10142, 20141
);

/* INSERT QUERY NO: 20 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504640, 'Hedwig', 'Crocker', 'C1', 'N10170', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO170@gmail.com', 4036669144, 10143, 20142
);

/* INSERT QUERY NO: 21 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504641, 'Lazaro', 'McKerlie', 'C1', 'N10171', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO171@gmail.com', 4036669145, 10144, 20143
);

/* INSERT QUERY NO: 22 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504642, 'Kania', 'Paolazzi', 'C1', 'N10172', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO172@gmail.com', 4036669146, 10145, 20144
);

/* INSERT QUERY NO: 23 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504643, 'Karl', 'Rake', 'C1', 'N10173', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO173@gmail.com', 4036669147, 10146, 20145
);

/* INSERT QUERY NO: 24 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504644, 'Skipp', 'Dragge', 'C1', 'N10174', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO174@gmail.com', 4036669148, 10147, 20146
);

/* INSERT QUERY NO: 25 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504645, 'Rosabella', 'Booton', 'C1', 'N10175', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO175@gmail.com', 4036669149, 10148, 20147
);

/* INSERT QUERY NO: 26 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504646, 'Lowell', 'Goodchild', 'C1', 'N10176', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO176@gmail.com', 4036669150, 10149, 20148
);

/* INSERT QUERY NO: 27 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504647, 'Ginnie', 'Kop', 'C1', 'N10177', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO177@gmail.com', 4036669151, 10150, 20149
);

/* INSERT QUERY NO: 28 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504648, 'Gill', 'Hauck', 'C1', 'N10178', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO178@gmail.com', 4036669152, 10151, 20150
);

/* INSERT QUERY NO: 29 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504649, 'Johan', 'Weedon', 'C1', 'N10179', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO179@gmail.com', 4036669153, 10152, 20151
);

/* INSERT QUERY NO: 30 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504650, 'Guinevere', 'Ingley', 'C1', 'N10180', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO180@gmail.com', 4036669154, 10153, 20152
);

/* INSERT QUERY NO: 31 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504651, 'Garrott', 'Westoff', 'C1', 'N10181', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO181@gmail.com', 4036669155, 10154, 20153
);

/* INSERT QUERY NO: 32 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504652, 'Nicolina', 'Bosch', 'C1', 'N10182', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO182@gmail.com', 4036669156, 10155, 20154
);

/* INSERT QUERY NO: 33 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504653, 'Melantha', 'Bletsoe', 'C1', 'N10183', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO183@gmail.com', 4036669157, 10156, 20155
);

/* INSERT QUERY NO: 34 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504654, 'Gardiner', 'Edrich', 'C1', 'N10184', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO184@gmail.com', 4036669158, 10157, 20156
);

/* INSERT QUERY NO: 35 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504655, 'Carree', 'Imlacke', 'C1', 'N10185', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO185@gmail.com', 4036669159, 10158, 20157
);

/* INSERT QUERY NO: 36 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504656, 'Agnese', 'Meakin', 'C1', 'N10186', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO186@gmail.com', 4036669160, 10159, 20158
);

/* INSERT QUERY NO: 37 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504657, 'Simonette', 'MacCallion', 'C1', 'N10187', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO187@gmail.com', 4036669161, 10160, 20159
);

/* INSERT QUERY NO: 38 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504658, 'Cordy', 'Bayly', 'C1', 'N10188', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO188@gmail.com', 4036669162, 10161, 20160
);

/* INSERT QUERY NO: 39 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504659, 'Melisande', 'Van Brug', 'C1', 'N10189', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO189@gmail.com', 4036669163, 10162, 20161
);

/* INSERT QUERY NO: 40 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504660, 'Tabor', 'Farraway', 'C1', 'N10190', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO190@gmail.com', 4036669164, 10163, 20162
);

/* INSERT QUERY NO: 41 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504661, 'Wandie', 'Ovington', 'C1', 'N10191', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO191@gmail.com', 4036669165, 10164, 20163
);

/* INSERT QUERY NO: 42 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504662, 'Giordano', 'Kenefick', 'C1', 'N10192', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO192@gmail.com', 4036669166, 10165, 20164
);

/* INSERT QUERY NO: 43 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504663, 'Lalo', 'Jervois', 'C1', 'N10193', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO193@gmail.com', 4036669167, 10166, 20165
);

/* INSERT QUERY NO: 44 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504664, 'Marley', 'Tozer', 'C1', 'N10194', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO194@gmail.com', 4036669168, 10167, 20166
);

/* INSERT QUERY NO: 45 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504665, 'Hildegarde', 'Williment', 'C1', 'N10195', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO195@gmail.com', 4036669169, 10168, 20167
);

/* INSERT QUERY NO: 46 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504666, 'Blinni', 'Doiley', 'C1', 'N10196', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO196@gmail.com', 4036669170, 10169, 20168
);

/* INSERT QUERY NO: 47 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504667, 'Elijah', 'Sulley', 'C1', 'N10197', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO197@gmail.com', 4036669171, 10170, 20169
);

/* INSERT QUERY NO: 48 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504668, 'Burt', 'Sallan', 'C1', 'N10198', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO198@gmail.com', 4036669172, 10171, 20170
);

/* INSERT QUERY NO: 49 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504669, 'Vince', 'Holdworth', 'C1', 'N10199', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO199@gmail.com', 4036669173, 10172, 20171
);

/* INSERT QUERY NO: 50 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504670, 'Reynard', 'Karel', 'C1', 'N10200', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO200@gmail.com', 4036669174, 10173, 20172
);

/* INSERT QUERY NO: 51 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504671, 'Ramonda', 'Dibdall', 'C1', 'N10201', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO201@gmail.com', 4036669175, 10174, 20173
);

/* INSERT QUERY NO: 52 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504672, 'Xenos', 'Candey', 'C1', 'N10202', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO202@gmail.com', 4036669176, 10175, 20174
);

/* INSERT QUERY NO: 53 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504673, 'Gloria', 'Creasy', 'C1', 'N10203', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO203@gmail.com', 4036669177, 10176, 20175
);

/* INSERT QUERY NO: 54 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504674, 'Portia', 'Cadwallader', 'C1', 'N10204', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO204@gmail.com', 4036669178, 10177, 20176
);

/* INSERT QUERY NO: 55 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504675, 'Claudelle', 'Joannet', 'C1', 'N10205', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO205@gmail.com', 4036669179, 10178, 20177
);

/* INSERT QUERY NO: 56 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504676, 'Burlie', 'Sorbey', 'C1', 'N10206', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO206@gmail.com', 4036669180, 10179, 20178
);

/* INSERT QUERY NO: 57 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504677, 'Malanie', 'Higgoe', 'C1', 'N10207', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO207@gmail.com', 4036669181, 10180, 20179
);

/* INSERT QUERY NO: 58 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504678, 'Janeczka', 'McQuirk', 'C1', 'N10208', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO208@gmail.com', 4036669182, 10181, 20180
);

/* INSERT QUERY NO: 59 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504679, 'Don', 'Traves', 'C1', 'N10209', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO209@gmail.com', 4036669183, 10182, 20181
);

/* INSERT QUERY NO: 60 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504680, 'Laurella', 'Duffell', 'C1', 'N10210', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO210@gmail.com', 4036669184, 10183, 20182
);

/* INSERT QUERY NO: 61 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504681, 'Peadar', 'Dusting', 'C1', 'N10211', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO211@gmail.com', 4036669185, 10184, 20183
);

/* INSERT QUERY NO: 62 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504682, 'Masha', 'Kernock', 'C1', 'N10212', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO212@gmail.com', 4036669186, 10185, 20184
);

/* INSERT QUERY NO: 63 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504683, 'Gabi', 'Woodwin', 'C1', 'N10213', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO213@gmail.com', 4036669187, 10186, 20185
);

/* INSERT QUERY NO: 64 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504684, 'Nanny', 'Caseborne', 'C1', 'N10214', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO214@gmail.com', 4036669188, 10187, 20186
);

/* INSERT QUERY NO: 65 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504685, 'Vidovic', 'Zoren', 'C1', 'N10215', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO215@gmail.com', 4036669189, 10188, 20187
);

/* INSERT QUERY NO: 66 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504686, 'Jesse', 'Bailey', 'C1', 'N10216', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO216@gmail.com', 4036669190, 10189, 20188
);

/* INSERT QUERY NO: 67 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504687, 'Fraze', 'Pawling', 'C1', 'N10217', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO217@gmail.com', 4036669191, 10190, 20189
);

/* INSERT QUERY NO: 68 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504688, 'Martainn', 'Steen', 'C1', 'N10218', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO218@gmail.com', 4036669192, 10191, 20190
);

/* INSERT QUERY NO: 69 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504689, 'Alysa', 'Scoble', 'C1', 'N10219', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO219@gmail.com', 4036669193, 10192, 20191
);

/* INSERT QUERY NO: 70 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504690, 'Ernst', 'Parmiter', 'C1', 'N10220', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO220@gmail.com', 4036669194, 10193, 20192
);

/* INSERT QUERY NO: 71 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504691, 'Mella', 'Wightman', 'C1', 'N10221', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO221@gmail.com', 4036669195, 10194, 20193
);

/* INSERT QUERY NO: 72 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504692, 'Sibilla', 'Lourenco', 'C1', 'N10222', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO222@gmail.com', 4036669196, 10195, 20194
);

/* INSERT QUERY NO: 73 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504693, 'Itch', 'Dowsey', 'C1', 'N10223', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO223@gmail.com', 4036669197, 10196, 20195
);

/* INSERT QUERY NO: 74 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504694, 'Bernardo', 'Pagen', 'C1', 'N10224', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO224@gmail.com', 4036669198, 10197, 20196
);

/* INSERT QUERY NO: 75 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504695, 'Leigha', 'Pylkynyton', 'C1', 'N10225', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO225@gmail.com', 4036669199, 10198, 20197
);

/* INSERT QUERY NO: 76 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504696, 'Agnola', 'Jirak', 'C1', 'N10226', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO226@gmail.com', 4036669200, 10199, 20198
);

/* INSERT QUERY NO: 77 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504697, 'Brodie', 'Gwioneth', 'C1', 'N10227', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO227@gmail.com', 4036669201, 10200, 20199
);

/* INSERT QUERY NO: 78 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504698, 'Shurlock', 'Bandt', 'C1', 'N10228', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO228@gmail.com', 4036669202, 10201, 20200
);

/* INSERT QUERY NO: 79 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504699, 'Rafi', 'Stevings', 'C1', 'N10229', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO229@gmail.com', 4036669203, 10202, 20201
);

/* INSERT QUERY NO: 80 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504700, 'Wilma', 'Cloney', 'C1', 'N10230', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO230@gmail.com', 4036669204, 10203, 20202
);

/* INSERT QUERY NO: 81 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504701, 'Gan', 'Jordeson', 'C1', 'N10231', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO231@gmail.com', 4036669205, 10204, 20203
);

/* INSERT QUERY NO: 82 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504702, 'Cozmo', 'Aldwich', 'C1', 'N10232', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO232@gmail.com', 4036669206, 10205, 20204
);

/* INSERT QUERY NO: 83 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504703, 'Deva', 'Mountjoy', 'C1', 'N10233', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO233@gmail.com', 4036669207, 10206, 20205
);

/* INSERT QUERY NO: 84 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504704, 'Henka', 'Caville', 'C1', 'N10234', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO234@gmail.com', 4036669208, 10207, 20206
);

/* INSERT QUERY NO: 85 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504705, 'Mar', 'Huckell', 'C1', 'N10235', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO235@gmail.com', 4036669209, 10208, 20207
);

/* INSERT QUERY NO: 86 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504706, 'Audi', 'Harsent', 'C1', 'N10236', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO236@gmail.com', 4036669210, 10209, 20208
);

/* INSERT QUERY NO: 87 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504707, 'Romeo', 'Meriguet', 'C1', 'N10237', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO237@gmail.com', 4036669211, 10210, 20209
);

/* INSERT QUERY NO: 88 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504708, 'Dorian', 'de Voiels', 'C1', 'N10238', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO238@gmail.com', 4036669212, 10211, 20210
);

/* INSERT QUERY NO: 89 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504709, 'Odelia', 'Stoyell', 'C1', 'N10239', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO239@gmail.com', 4036669213, 10212, 20211
);

/* INSERT QUERY NO: 90 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504710, 'Ignazio', 'Fetherstan', 'C1', 'N10240', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO240@gmail.com', 4036669214, 10213, 20212
);

/* INSERT QUERY NO: 91 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504711, 'Garrott', 'Seebert', 'C1', 'N10241', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO241@gmail.com', 4036669215, 10214, 20213
);

/* INSERT QUERY NO: 92 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504712, 'Xavier', 'Caddens', 'C1', 'N10242', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO242@gmail.com', 4036669216, 10215, 20214
);

/* INSERT QUERY NO: 93 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504713, 'Shandee', 'Mattiazzi', 'C1', 'N10243', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO243@gmail.com', 4036669217, 10216, 20215
);

/* INSERT QUERY NO: 94 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504714, 'Vickie', 'Papez', 'C1', 'N10244', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO244@gmail.com', 4036669218, 10217, 20216
);

/* INSERT QUERY NO: 95 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504715, 'Carmon', 'Sergant', 'C1', 'N10245', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO245@gmail.com', 4036669219, 10218, 20217
);

/* INSERT QUERY NO: 96 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504716, 'Jillana', 'Coit', 'C1', 'N10246', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO246@gmail.com', 4036669220, 10219, 20218
);

/* INSERT QUERY NO: 97 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504717, 'Fritz', 'Mussetti', 'C1', 'N10247', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO247@gmail.com', 4036669221, 10220, 20219
);

/* INSERT QUERY NO: 98 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504718, 'Harris', 'Rime', 'C1', 'N10248', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO248@gmail.com', 4036669222, 10221, 20220
);

/* INSERT QUERY NO: 99 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504719, 'Shay', 'Hagwood', 'C1', 'N10249', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO249@gmail.com', 4036669223, 10222, 20221
);

/* INSERT QUERY NO: 100 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504720, 'Cyb', 'Cholomin', 'C1', 'N10250', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO250@gmail.com', 4036669224, 10223, 20222
);

/* INSERT QUERY NO: 101 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504721, 'Obadiah', 'Looks', 'C1', 'N10251', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO251@gmail.com', 4036669225, 10224, 20223
);

/* INSERT QUERY NO: 102 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504722, 'Anatola', 'Lysaght', 'C1', 'N10252', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO252@gmail.com', 4036669226, 10225, 20224
);

/* INSERT QUERY NO: 103 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504723, 'Clemmie', 'Swainger', 'C1', 'N10253', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO253@gmail.com', 4036669227, 10226, 20225
);

/* INSERT QUERY NO: 104 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504724, 'Warden', 'Pollington', 'C1', 'N10254', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO254@gmail.com', 4036669228, 10227, 20226
);

/* INSERT QUERY NO: 105 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504725, 'Hagan', 'Andriolli', 'C1', 'N10255', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO255@gmail.com', 4036669229, 10228, 20227
);

/* INSERT QUERY NO: 106 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504726, 'Shay', 'Simonazzi', 'C1', 'N10256', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO256@gmail.com', 4036669230, 10229, 20228
);

/* INSERT QUERY NO: 107 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504727, 'Alexandro', 'Hauxby', 'C1', 'N10257', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO257@gmail.com', 4036669231, 10230, 20229
);

/* INSERT QUERY NO: 108 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504728, 'Rasla', 'Vowden', 'C1', 'N10258', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO258@gmail.com', 4036669232, 10231, 20230
);

/* INSERT QUERY NO: 109 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504729, 'Clarie', 'Trever', 'C1', 'N10259', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO259@gmail.com', 4036669233, 10232, 20231
);

/* INSERT QUERY NO: 110 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504730, 'Wilma', 'Carmen', 'C1', 'N10260', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO260@gmail.com', 4036669234, 10233, 20232
);

/* INSERT QUERY NO: 111 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504731, 'Corbet', 'Ganford', 'C1', 'N10261', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO261@gmail.com', 4036669235, 10234, 20233
);

/* INSERT QUERY NO: 112 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504732, 'Billie', 'Dionisi', 'C1', 'N10262', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO262@gmail.com', 4036669236, 10235, 20234
);

/* INSERT QUERY NO: 113 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504733, 'Glyn', 'Traise', 'C1', 'N10263', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO263@gmail.com', 4036669237, 10236, 20235
);

/* INSERT QUERY NO: 114 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504734, 'Petunia', 'Gittins', 'C1', 'N10264', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO264@gmail.com', 4036669238, 10237, 20236
);

/* INSERT QUERY NO: 115 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504735, 'Benedetta', 'Yapp', 'C1', 'N10265', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO265@gmail.com', 4036669239, 10238, 20237
);

/* INSERT QUERY NO: 116 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504736, 'Fred', 'Sketh', 'C1', 'N10266', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO266@gmail.com', 4036669240, 10239, 20238
);

/* INSERT QUERY NO: 117 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504737, 'Gladi', 'Basset', 'C1', 'N10267', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO267@gmail.com', 4036669241, 10240, 20239
);

/* INSERT QUERY NO: 118 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504738, 'Gussie', 'Habershaw', 'C1', 'N10268', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO268@gmail.com', 4036669242, 10241, 20240
);

/* INSERT QUERY NO: 119 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504739, 'Dallis', 'Sarath', 'C1', 'N10269', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO269@gmail.com', 4036669243, 10242, 20241
);

/* INSERT QUERY NO: 120 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504740, 'Jacinta', 'Bawles', 'C1', 'N10270', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO270@gmail.com', 4036669244, 10243, 20242
);

/* INSERT QUERY NO: 121 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504741, 'Brian', 'Ellacott', 'C1', 'N10271', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO271@gmail.com', 4036669245, 10244, 20243
);

/* INSERT QUERY NO: 122 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504742, 'Alisa', 'Bogaert', 'C1', 'N10272', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO272@gmail.com', 4036669246, 10245, 20244
);

/* INSERT QUERY NO: 123 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504743, 'Nicholle', 'Nisby', 'C1', 'N10273', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO273@gmail.com', 4036669247, 10246, 20245
);

/* INSERT QUERY NO: 124 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504744, 'Ondrea', 'Knappe', 'C1', 'N10274', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO274@gmail.com', 4036669248, 10247, 20246
);

/* INSERT QUERY NO: 125 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504745, 'Millicent', 'Vanyakin', 'C1', 'N10275', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO275@gmail.com', 4036669249, 10248, 20247
);

/* INSERT QUERY NO: 126 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504746, 'Dominica', 'Hudel', 'C1', 'N10276', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO276@gmail.com', 4036669250, 10249, 20248
);

/* INSERT QUERY NO: 127 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504747, 'Hedvig', 'Elloit', 'C1', 'N10277', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO277@gmail.com', 4036669251, 10250, 20249
);

/* INSERT QUERY NO: 128 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504748, 'Chrotoem', 'Golde', 'C1', 'N10278', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO278@gmail.com', 4036669252, 10251, 20250
);

/* INSERT QUERY NO: 129 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504749, 'Welch', 'Bullion', 'C1', 'N10279', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO279@gmail.com', 4036669253, 10252, 20251
);

/* INSERT QUERY NO: 130 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504750, 'Rudy', 'Ianson', 'C1', 'N10280', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO280@gmail.com', 4036669254, 10253, 20252
);

/* INSERT QUERY NO: 131 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504751, 'Dodie', 'Allabarton', 'C1', 'N10281', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO281@gmail.com', 4036669255, 10254, 20253
);

/* INSERT QUERY NO: 132 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504752, 'Dela', 'Brimmell', 'C1', 'N10282', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO282@gmail.com', 4036669256, 10255, 20254
);

/* INSERT QUERY NO: 133 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504753, 'Lisle', 'Hucke', 'C1', 'N10283', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO283@gmail.com', 4036669257, 10256, 20255
);

/* INSERT QUERY NO: 134 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504754, 'Thorndike', 'Kaye', 'C1', 'N10284', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO284@gmail.com', 4036669258, 10257, 20256
);

/* INSERT QUERY NO: 135 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504755, 'Porty', 'Snodden', 'C1', 'N10285', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO285@gmail.com', 4036669259, 10258, 20257
);

/* INSERT QUERY NO: 136 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504756, 'Sol', 'Wadelin', 'C1', 'N10286', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO286@gmail.com', 4036669260, 10259, 20258
);

/* INSERT QUERY NO: 137 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504757, 'Justis', 'Brende', 'C1', 'N10287', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO287@gmail.com', 4036669261, 10260, 20259
);

/* INSERT QUERY NO: 138 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504758, 'Trudy', 'Gero', 'C1', 'N10288', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO288@gmail.com', 4036669262, 10261, 20260
);

/* INSERT QUERY NO: 139 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504759, 'Gifford', 'Innocenti', 'C1', 'N10289', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO289@gmail.com', 4036669263, 10262, 20261
);

/* INSERT QUERY NO: 140 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504760, 'Jobey', 'Weatherup', 'C1', 'N10290', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO290@gmail.com', 4036669264, 10263, 20262
);

/* INSERT QUERY NO: 141 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504761, 'Cody', 'Glading', 'C1', 'N10291', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO291@gmail.com', 4036669265, 10264, 20263
);

/* INSERT QUERY NO: 142 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504762, 'Ollie', 'Blencoe', 'C1', 'N10292', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO292@gmail.com', 4036669266, 10265, 20264
);

/* INSERT QUERY NO: 143 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504763, 'Ruben', 'Proom', 'C1', 'N10293', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO293@gmail.com', 4036669267, 10266, 20265
);

/* INSERT QUERY NO: 144 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504764, 'Cally', 'Iceton', 'C1', 'N10294', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO294@gmail.com', 4036669268, 10267, 20266
);

/* INSERT QUERY NO: 145 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504765, 'Margaretha', 'Vatini', 'C1', 'N10295', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO295@gmail.com', 4036669269, 10268, 20267
);

/* INSERT QUERY NO: 146 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504766, 'Gannon', 'Ramshay', 'C1', 'N10296', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO296@gmail.com', 4036669270, 10269, 20268
);

/* INSERT QUERY NO: 147 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504767, 'Lothario', 'Moulds', 'C1', 'N10297', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO297@gmail.com', 4036669271, 10270, 20269
);

/* INSERT QUERY NO: 148 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504768, 'Ryan', 'Circuit', 'C1', 'N10298', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO298@gmail.com', 4036669272, 10271, 20270
);

/* INSERT QUERY NO: 149 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504769, 'Weston', 'Doreward', 'C1', 'N10299', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO299@gmail.com', 4036669273, 10272, 20271
);

/* INSERT QUERY NO: 150 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504770, 'Clarisse', 'Tschersich', 'C1', 'N10300', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO300@gmail.com', 4036669274, 10273, 20272
);

/* INSERT QUERY NO: 151 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504771, 'Yolande', 'Tatham', 'C1', 'N10301', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO301@gmail.com', 4036669275, 10274, 20273
);

/* INSERT QUERY NO: 152 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504772, 'Tiphani', 'George', 'C1', 'N10302', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO302@gmail.com', 4036669276, 10275, 20274
);

/* INSERT QUERY NO: 153 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504773, 'Ingaborg', 'Cornill', 'C1', 'N10303', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO303@gmail.com', 4036669277, 10276, 20275
);

/* INSERT QUERY NO: 154 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504774, 'Alta', 'Budcock', 'C1', 'N10304', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO304@gmail.com', 4036669278, 10277, 20276
);

/* INSERT QUERY NO: 155 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504775, 'Randolph', 'Ackery', 'C1', 'N10305', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO305@gmail.com', 4036669279, 10278, 20277
);

/* INSERT QUERY NO: 156 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504776, 'Odele', 'Arnet', 'C1', 'N10306', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO306@gmail.com', 4036669280, 10279, 20278
);

/* INSERT QUERY NO: 157 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504777, 'Chico', 'Sindle', 'C1', 'N10307', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO307@gmail.com', 4036669281, 10280, 20279
);

/* INSERT QUERY NO: 158 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504778, 'Ulrika', 'Rillatt', 'C1', 'N10308', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO308@gmail.com', 4036669282, 10281, 20280
);

/* INSERT QUERY NO: 159 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504779, 'Willamina', 'Denington', 'C1', 'N10309', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO309@gmail.com', 4036669283, 10282, 20281
);

/* INSERT QUERY NO: 160 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504780, 'Franky', 'Hanne', 'C1', 'N10310', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO310@gmail.com', 4036669284, 10283, 20282
);

/* INSERT QUERY NO: 161 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504781, 'Waverly', 'Alforde', 'C1', 'N10311', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO311@gmail.com', 4036669285, 10284, 20283
);

/* INSERT QUERY NO: 162 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504782, 'Renault', 'Bain', 'C1', 'N10312', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO312@gmail.com', 4036669286, 10285, 20284
);

/* INSERT QUERY NO: 163 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504783, 'Selene', 'Kimmince', 'C1', 'N10313', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO313@gmail.com', 4036669287, 10286, 20285
);

/* INSERT QUERY NO: 164 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504784, 'Ciro', 'Matiasek', 'C1', 'N10314', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO314@gmail.com', 4036669288, 10287, 20286
);

/* INSERT QUERY NO: 165 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504785, 'Stesha', 'Loxley', 'C1', 'N10315', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO315@gmail.com', 4036669289, 10288, 20287
);

/* INSERT QUERY NO: 166 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504786, 'Philbert', 'Kays', 'C1', 'N10316', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO316@gmail.com', 4036669290, 10289, 20288
);

/* INSERT QUERY NO: 167 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504787, 'Man', 'Abbado', 'C1', 'N10317', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO317@gmail.com', 4036669291, 10290, 20289
);

/* INSERT QUERY NO: 168 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504788, 'Domini', 'Keenlyside', 'C1', 'N10318', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO318@gmail.com', 4036669292, 10291, 20290
);

/* INSERT QUERY NO: 169 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504789, 'Sherry', 'Kilduff', 'C1', 'N10319', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO319@gmail.com', 4036669293, 10292, 20291
);

/* INSERT QUERY NO: 170 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504790, 'Rora', 'Laundon', 'C1', 'N10320', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO320@gmail.com', 4036669294, 10293, 20292
);

/* INSERT QUERY NO: 171 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504791, 'Eldridge', 'Cubbon', 'C1', 'N10321', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO321@gmail.com', 4036669295, 10294, 20293
);

/* INSERT QUERY NO: 172 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504792, 'Randy', 'Bunny', 'C1', 'N10322', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO322@gmail.com', 4036669296, 10295, 20294
);

/* INSERT QUERY NO: 173 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504793, 'Velvet', 'Colbridge', 'C1', 'N10323', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO323@gmail.com', 4036669297, 10296, 20295
);

/* INSERT QUERY NO: 174 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504794, 'Templeton', 'Benford', 'C1', 'N10324', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO324@gmail.com', 4036669298, 10297, 20296
);

/* INSERT QUERY NO: 175 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504795, 'Marijn', 'Brunon', 'C1', 'N10325', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO325@gmail.com', 4036669299, 10298, 20297
);

/* INSERT QUERY NO: 176 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504796, 'Rockie', 'Rengger', 'C1', 'N10326', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO326@gmail.com', 4036669300, 10299, 20298
);

/* INSERT QUERY NO: 177 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504797, 'Annabel', 'Jenkins', 'C1', 'N10327', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO327@gmail.com', 4036669301, 10300, 20299
);

/* INSERT QUERY NO: 178 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504798, 'Ronda', 'Tinniswood', 'C1', 'N10328', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO328@gmail.com', 4036669302, 10301, 20300
);

/* INSERT QUERY NO: 179 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504799, 'Bonita', 'Begent', 'C1', 'N10329', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO329@gmail.com', 4036669303, 10302, 20301
);

/* INSERT QUERY NO: 180 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504800, 'Adlai', 'Defond', 'C1', 'N10330', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO330@gmail.com', 4036669304, 10303, 20302
);

/* INSERT QUERY NO: 181 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504801, 'Cobby', 'Bestiman', 'C1', 'N10331', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO331@gmail.com', 4036669305, 10304, 20303
);

/* INSERT QUERY NO: 182 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504802, 'Wernher', 'Fevier', 'C1', 'N10332', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO332@gmail.com', 4036669306, 10305, 20304
);

/* INSERT QUERY NO: 183 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504803, 'Mandy', 'Salters', 'C1', 'N10333', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO333@gmail.com', 4036669307, 10306, 20305
);

/* INSERT QUERY NO: 184 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504804, 'Dionysus', 'Andress', 'C1', 'N10334', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO334@gmail.com', 4036669308, 10307, 20306
);

/* INSERT QUERY NO: 185 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504805, 'Putnam', 'Bitten', 'C1', 'N10335', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO335@gmail.com', 4036669309, 10308, 20307
);

/* INSERT QUERY NO: 186 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504806, 'Angel', 'Apted', 'C1', 'N10336', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO336@gmail.com', 4036669310, 10309, 20308
);

/* INSERT QUERY NO: 187 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504807, 'Der', 'Dibbs', 'C1', 'N10337', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO337@gmail.com', 4036669311, 10310, 20309
);

/* INSERT QUERY NO: 188 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504808, 'Lanette', 'Nuttey', 'C1', 'N10338', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO338@gmail.com', 4036669312, 10311, 20310
);

/* INSERT QUERY NO: 189 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504809, 'Raddy', 'Etuck', 'C1', 'N10339', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO339@gmail.com', 4036669313, 10312, 20311
);

/* INSERT QUERY NO: 190 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504810, 'Dwight', 'Merlin', 'C1', 'N10340', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO340@gmail.com', 4036669314, 10313, 20312
);

/* INSERT QUERY NO: 191 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504811, 'Hinda', 'Turner', 'C1', 'N10341', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO341@gmail.com', 4036669315, 10314, 20313
);

/* INSERT QUERY NO: 192 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504812, 'Stefano', 'Mingey', 'C1', 'N10342', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO342@gmail.com', 4036669316, 10315, 20314
);

/* INSERT QUERY NO: 193 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504813, 'Adele', 'Fairn', 'C1', 'N10343', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO343@gmail.com', 4036669317, 10316, 20315
);

/* INSERT QUERY NO: 194 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504814, 'Caldwell', 'Critoph', 'C1', 'N10344', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO344@gmail.com', 4036669318, 10317, 20316
);

/* INSERT QUERY NO: 195 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504815, 'Leonelle', 'Teesdale', 'C1', 'N10345', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO345@gmail.com', 4036669319, 10318, 20317
);

/* INSERT QUERY NO: 196 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504816, 'Corabel', 'Garbutt', 'C1', 'N10346', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO346@gmail.com', 4036669320, 10319, 20318
);

/* INSERT QUERY NO: 197 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504817, 'Pepillo', 'Staves', 'C1', 'N10347', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO347@gmail.com', 4036669321, 10320, 20319
);

/* INSERT QUERY NO: 198 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504818, 'Isacco', 'Anfusso', 'C1', 'N10348', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO348@gmail.com', 4036669322, 10321, 20320
);

/* INSERT QUERY NO: 199 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504819, 'Barton', 'Van Hesteren', 'C1', 'N10349', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO349@gmail.com', 4036669323, 10322, 20321
);

/* INSERT QUERY NO: 200 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504820, 'Ethelyn', 'Buchan', 'C1', 'N10350', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO350@gmail.com', 4036669324, 10323, 20322
);

/* INSERT QUERY NO: 201 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504821, 'Yolanda', 'Trimmill', 'C1', 'N10351', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO351@gmail.com', 4036669325, 10324, 20323
);

/* INSERT QUERY NO: 202 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504822, 'Isac', 'Dunlop', 'C1', 'N10352', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO352@gmail.com', 4036669326, 10325, 20324
);

/* INSERT QUERY NO: 203 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504823, 'Byram', 'Elecum', 'C1', 'N10353', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO353@gmail.com', 4036669327, 10326, 20325
);

/* INSERT QUERY NO: 204 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504824, 'Trenton', 'Griswood', 'C1', 'N10354', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO354@gmail.com', 4036669328, 10327, 20326
);

/* INSERT QUERY NO: 205 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504825, 'Gilles', 'Spellman', 'C1', 'N10355', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO355@gmail.com', 4036669329, 10328, 20327
);

/* INSERT QUERY NO: 206 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504826, 'Caesar', 'Ashley', 'C1', 'N10356', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO356@gmail.com', 4036669330, 10329, 20328
);

/* INSERT QUERY NO: 207 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504827, 'Kara', 'Sacchetti', 'C1', 'N10357', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO357@gmail.com', 4036669331, 10330, 20329
);

/* INSERT QUERY NO: 208 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504828, 'Lulita', 'Hertwell', 'C1', 'N10358', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO358@gmail.com', 4036669332, 10331, 20330
);

/* INSERT QUERY NO: 209 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504829, 'Fran', 'Eymer', 'C1', 'N10359', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO359@gmail.com', 4036669333, 10332, 20331
);

/* INSERT QUERY NO: 210 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504830, 'Barbey', 'Tadlow', 'C1', 'N10360', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO360@gmail.com', 4036669334, 10333, 20332
);

/* INSERT QUERY NO: 211 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504831, 'Fernanda', 'Fox', 'C1', 'N10361', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO361@gmail.com', 4036669335, 10334, 20333
);

/* INSERT QUERY NO: 212 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504832, 'Les', 'Brickwood', 'C1', 'N10362', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO362@gmail.com', 4036669336, 10335, 20334
);

/* INSERT QUERY NO: 213 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504833, 'Sylvan', 'Bocken', 'C1', 'N10363', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO363@gmail.com', 4036669337, 10336, 20335
);

/* INSERT QUERY NO: 214 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504834, 'Dore', 'Pietraszek', 'C1', 'N10364', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO364@gmail.com', 4036669338, 10337, 20336
);

/* INSERT QUERY NO: 215 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504835, 'Geordie', 'Martinovsky', 'C1', 'N10365', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO365@gmail.com', 4036669339, 10338, 20337
);

/* INSERT QUERY NO: 216 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504836, 'Fidelity', 'Rivallant', 'C1', 'N10366', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO366@gmail.com', 4036669340, 10339, 20338
);

/* INSERT QUERY NO: 217 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504837, 'Ailee', 'Churchin', 'C1', 'N10367', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO367@gmail.com', 4036669341, 10340, 20339
);

/* INSERT QUERY NO: 218 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504838, 'Cathyleen', 'Lakenden', 'C1', 'N10368', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO368@gmail.com', 4036669342, 10341, 20340
);

/* INSERT QUERY NO: 219 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504839, 'Jeannine', 'Denge', 'C1', 'N10369', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO369@gmail.com', 4036669343, 10342, 20341
);

/* INSERT QUERY NO: 220 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504840, 'Rosamund', 'Troyes', 'C1', 'N10370', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO370@gmail.com', 4036669344, 10343, 20342
);

/* INSERT QUERY NO: 221 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504841, 'Melisent', 'Van Eeden', 'C1', 'N10371', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO371@gmail.com', 4036669345, 10344, 20343
);

/* INSERT QUERY NO: 222 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504842, 'Tina', 'Dacca', 'C1', 'N10372', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO372@gmail.com', 4036669346, 10345, 20344
);

/* INSERT QUERY NO: 223 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504843, 'Dorisa', 'Iacovaccio', 'C1', 'N10373', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO373@gmail.com', 4036669347, 10346, 20345
);

/* INSERT QUERY NO: 224 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504844, 'Brigitte', 'Maben', 'C1', 'N10374', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO374@gmail.com', 4036669348, 10347, 20346
);

/* INSERT QUERY NO: 225 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504845, 'Lon', 'Hornung', 'C1', 'N10375', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO375@gmail.com', 4036669349, 10348, 20347
);

/* INSERT QUERY NO: 226 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504846, 'Tedra', 'Groomebridge', 'C1', 'N10376', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO376@gmail.com', 4036669350, 10349, 20348
);

/* INSERT QUERY NO: 227 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504847, 'Emmy', 'Fleeming', 'C1', 'N10377', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO377@gmail.com', 4036669351, 10350, 20349
);

/* INSERT QUERY NO: 228 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504848, 'Malorie', 'Chessil', 'C1', 'N10378', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO378@gmail.com', 4036669352, 10351, 20350
);

/* INSERT QUERY NO: 229 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504849, 'Ivette', 'Sylett', 'C1', 'N10379', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO379@gmail.com', 4036669353, 10352, 20351
);

/* INSERT QUERY NO: 230 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504850, 'Darn', 'Garard', 'C1', 'N10380', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO380@gmail.com', 4036669354, 10353, 20352
);

/* INSERT QUERY NO: 231 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504851, 'Derry', 'Boutellier', 'C1', 'N10381', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO381@gmail.com', 4036669355, 10354, 20353
);

/* INSERT QUERY NO: 232 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504852, 'Rodie', 'Stone', 'C1', 'N10382', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO382@gmail.com', 4036669356, 10355, 20354
);

/* INSERT QUERY NO: 233 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504853, 'Marion', 'Hairsnape', 'C1', 'N10383', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO383@gmail.com', 4036669357, 10356, 20355
);

/* INSERT QUERY NO: 234 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504854, 'Domingo', 'Lanfare', 'C1', 'N10384', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO384@gmail.com', 4036669358, 10357, 20356
);

/* INSERT QUERY NO: 235 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504855, 'Andros', 'Sivyour', 'C1', 'N10385', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO385@gmail.com', 4036669359, 10358, 20357
);

/* INSERT QUERY NO: 236 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504856, 'Saree', 'Kitter', 'C1', 'N10386', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO386@gmail.com', 4036669360, 10359, 20358
);

/* INSERT QUERY NO: 237 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504857, 'Cher', 'Argyle', 'C1', 'N10387', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO387@gmail.com', 4036669361, 10360, 20359
);

/* INSERT QUERY NO: 238 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504858, 'Joy', 'Romanski', 'C1', 'N10388', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO388@gmail.com', 4036669362, 10361, 20360
);

/* INSERT QUERY NO: 239 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504859, 'Anton', 'Cressingham', 'C1', 'N10389', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO389@gmail.com', 4036669363, 10362, 20361
);

/* INSERT QUERY NO: 240 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504860, 'Frances', 'Philcock', 'C1', 'N10390', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO390@gmail.com', 4036669364, 10363, 20362
);

/* INSERT QUERY NO: 241 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504861, 'Odell', 'Brittlebank', 'C1', 'N10391', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO391@gmail.com', 4036669365, 10364, 20363
);

/* INSERT QUERY NO: 242 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504862, 'Dorice', 'Blaxter', 'C1', 'N10392', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO392@gmail.com', 4036669366, 10365, 20364
);

/* INSERT QUERY NO: 243 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504863, 'Christabel', 'Rabier', 'C1', 'N10393', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO393@gmail.com', 4036669367, 10366, 20365
);

/* INSERT QUERY NO: 244 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504864, 'Tyrus', 'Vasichev', 'C1', 'N10394', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO394@gmail.com', 4036669368, 10367, 20366
);

/* INSERT QUERY NO: 245 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504865, 'Brod', 'Lawfull', 'C1', 'N10395', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO395@gmail.com', 4036669369, 10368, 20367
);

/* INSERT QUERY NO: 246 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504866, 'Ranee', 'Oliva', 'C1', 'N10396', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO396@gmail.com', 4036669370, 10369, 20368
);

/* INSERT QUERY NO: 247 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504867, 'Rivkah', 'Fellibrand', 'C1', 'N10397', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO397@gmail.com', 4036669371, 10370, 20369
);

/* INSERT QUERY NO: 248 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504868, 'Gonzalo', 'Stanley', 'C1', 'N10398', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO398@gmail.com', 4036669372, 10371, 20370
);

/* INSERT QUERY NO: 249 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504869, 'Germain', 'Orgen', 'C1', 'N10399', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO399@gmail.com', 4036669373, 10372, 20371
);

/* INSERT QUERY NO: 250 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504870, 'Giselbert', 'Gribben', 'C1', 'N10400', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO400@gmail.com', 4036669374, 10373, 20372
);

/* INSERT QUERY NO: 251 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504871, 'Nikoletta', 'Athy', 'C1', 'N10401', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO401@gmail.com', 4036669375, 10374, 20373
);

/* INSERT QUERY NO: 252 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504872, 'Louisa', 'Plaice', 'C1', 'N10402', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO402@gmail.com', 4036669376, 10375, 20374
);

/* INSERT QUERY NO: 253 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504873, 'Sebastian', 'Caldecot', 'C1', 'N10403', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO403@gmail.com', 4036669377, 10376, 20375
);

/* INSERT QUERY NO: 254 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504874, 'Berk', 'Donnison', 'C1', 'N10404', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO404@gmail.com', 4036669378, 10377, 20376
);

/* INSERT QUERY NO: 255 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504875, 'Dew', 'Grigorushkin', 'C1', 'N10405', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO405@gmail.com', 4036669379, 10378, 20377
);

/* INSERT QUERY NO: 256 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504876, 'Brion', 'Petyankin', 'C1', 'N10406', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO406@gmail.com', 4036669380, 10379, 20378
);

/* INSERT QUERY NO: 257 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504877, 'Hyacinthie', 'Bigrigg', 'C1', 'N10407', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO407@gmail.com', 4036669381, 10380, 20379
);

/* INSERT QUERY NO: 258 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504878, 'Rozelle', 'Handrahan', 'C1', 'N10408', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO408@gmail.com', 4036669382, 10381, 20380
);

/* INSERT QUERY NO: 259 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504879, 'Chloette', 'Wooller', 'C1', 'N10409', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO409@gmail.com', 4036669383, 10382, 20381
);

/* INSERT QUERY NO: 260 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504880, 'Grata', 'Simenot', 'C1', 'N10410', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO410@gmail.com', 4036669384, 10383, 20382
);

/* INSERT QUERY NO: 261 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504881, 'Ringo', 'Gobert', 'C1', 'N10411', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO411@gmail.com', 4036669385, 10384, 20383
);

/* INSERT QUERY NO: 262 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504882, 'Richmond', 'Fonquernie', 'C1', 'N10412', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO412@gmail.com', 4036669386, 10385, 20384
);

/* INSERT QUERY NO: 263 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504883, 'Averill', 'Kenworthy', 'C1', 'N10413', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO413@gmail.com', 4036669387, 10386, 20385
);

/* INSERT QUERY NO: 264 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504884, 'Darnall', 'Telfer', 'C1', 'N10414', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO414@gmail.com', 4036669388, 10387, 20386
);

/* INSERT QUERY NO: 265 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504885, 'Jesse', 'Skains', 'C1', 'N10415', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO415@gmail.com', 4036669389, 10388, 20387
);

/* INSERT QUERY NO: 266 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504886, 'Neall', 'Luckcuck', 'C1', 'N10416', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO416@gmail.com', 4036669390, 10389, 20388
);

/* INSERT QUERY NO: 267 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504887, 'Teodoro', 'Sweedy', 'C1', 'N10417', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO417@gmail.com', 4036669391, 10390, 20389
);

/* INSERT QUERY NO: 268 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504888, 'Jacynth', 'MacPharlain', 'C1', 'N10418', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO418@gmail.com', 4036669392, 10391, 20390
);

/* INSERT QUERY NO: 269 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504889, 'Nikola', 'Sweeny', 'C1', 'N10419', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO419@gmail.com', 4036669393, 10392, 20391
);

/* INSERT QUERY NO: 270 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504890, 'Rosaleen', 'Ransfield', 'C1', 'N10420', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO420@gmail.com', 4036669394, 10393, 20392
);

/* INSERT QUERY NO: 271 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504891, 'Giorgi', 'Keyte', 'C1', 'N10421', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO421@gmail.com', 4036669395, 10394, 20393
);

/* INSERT QUERY NO: 272 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504892, 'Bill', 'Heustice', 'C1', 'N10422', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO422@gmail.com', 4036669396, 10395, 20394
);

/* INSERT QUERY NO: 273 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504893, 'Livvy', 'Chiverton', 'C1', 'N10423', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO423@gmail.com', 4036669397, 10396, 20395
);

/* INSERT QUERY NO: 274 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504894, 'Brody', 'Grayling', 'C1', 'N10424', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO424@gmail.com', 4036669398, 10397, 20396
);

/* INSERT QUERY NO: 275 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504895, 'Winonah', 'Paton', 'C1', 'N10425', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO425@gmail.com', 4036669399, 10398, 20397
);

/* INSERT QUERY NO: 276 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504896, 'Hollyanne', 'Pilkinton', 'C1', 'N10426', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO426@gmail.com', 4036669400, 10399, 20398
);

/* INSERT QUERY NO: 277 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504897, 'Roana', 'Ianiello', 'C1', 'N10427', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO427@gmail.com', 4036669401, 10400, 20399
);

/* INSERT QUERY NO: 278 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504898, 'Vince', 'Hendrich', 'C1', 'N10428', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO428@gmail.com', 4036669402, 10401, 20400
);

/* INSERT QUERY NO: 279 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504899, 'Joel', 'Tinan', 'C1', 'N10429', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO429@gmail.com', 4036669403, 10402, 20401
);

/* INSERT QUERY NO: 280 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504900, 'Viole', 'Oseland', 'C1', 'N10430', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO430@gmail.com', 4036669404, 10403, 20402
);

/* INSERT QUERY NO: 281 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504901, 'Robin', 'Regglar', 'C1', 'N10431', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO431@gmail.com', 4036669405, 10404, 20403
);

/* INSERT QUERY NO: 282 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504902, 'Lanita', 'Rowlson', 'C1', 'N10432', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO432@gmail.com', 4036669406, 10405, 20404
);

/* INSERT QUERY NO: 283 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504903, 'Skipper', 'Smardon', 'C1', 'N10433', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO433@gmail.com', 4036669407, 10406, 20405
);

/* INSERT QUERY NO: 284 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504904, 'Morton', 'Ivison', 'C1', 'N10434', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO434@gmail.com', 4036669408, 10407, 20406
);

/* INSERT QUERY NO: 285 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504905, 'Sharia', 'Hardwich', 'C1', 'N10435', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO435@gmail.com', 4036669409, 10408, 20407
);

/* INSERT QUERY NO: 286 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504906, 'Vivianne', 'Mohammad', 'C1', 'N10436', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO436@gmail.com', 4036669410, 10409, 20408
);

/* INSERT QUERY NO: 287 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504907, 'Gerardo', 'Bevington', 'C1', 'N10437', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO437@gmail.com', 4036669411, 10410, 20409
);

/* INSERT QUERY NO: 288 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504908, 'Sherwynd', 'Barbisch', 'C1', 'N10438', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO438@gmail.com', 4036669412, 10411, 20410
);

/* INSERT QUERY NO: 289 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504909, 'Hal', 'Nussey', 'C1', 'N10439', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO439@gmail.com', 4036669413, 10412, 20411
);

/* INSERT QUERY NO: 290 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504910, 'Teador', 'Duigenan', 'C1', 'N10440', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO440@gmail.com', 4036669414, 10413, 20412
);

/* INSERT QUERY NO: 291 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504911, 'Maybelle', 'Todarini', 'C1', 'N10441', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO441@gmail.com', 4036669415, 10414, 20413
);

/* INSERT QUERY NO: 292 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504912, 'Natalee', 'Prickett', 'C1', 'N10442', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO442@gmail.com', 4036669416, 10415, 20414
);

/* INSERT QUERY NO: 293 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504913, 'Rosaline', 'Callen', 'C1', 'N10443', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO443@gmail.com', 4036669417, 10416, 20415
);

/* INSERT QUERY NO: 294 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504914, 'Arielle', 'Feighry', 'C1', 'N10444', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO444@gmail.com', 4036669418, 10417, 20416
);

/* INSERT QUERY NO: 295 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504915, 'Merlina', 'Manolov', 'C1', 'N10445', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO445@gmail.com', 4036669419, 10418, 20417
);

/* INSERT QUERY NO: 296 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504916, 'Clayborne', 'Featherstone', 'C1', 'N10446', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO446@gmail.com', 4036669420, 10419, 20418
);

/* INSERT QUERY NO: 297 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504917, 'Benni', 'Barnwell', 'C1', 'N10447', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO447@gmail.com', 4036669421, 10420, 20419
);

/* INSERT QUERY NO: 298 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504918, 'Cori', 'Winsbury', 'C1', 'N10448', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO448@gmail.com', 4036669422, 10421, 20420
);

/* INSERT QUERY NO: 299 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504919, 'Gale', 'Biaggioli', 'C1', 'N10449', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO449@gmail.com', 4036669423, 10422, 20421
);

/* INSERT QUERY NO: 300 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504920, 'Cloris', 'Brody', 'C1', 'N10450', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO450@gmail.com', 4036669424, 10423, 20422
);

/* INSERT QUERY NO: 301 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504921, 'Neil', 'Abram', 'C1', 'N10451', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO451@gmail.com', 4036669425, 10424, 20423
);

/* INSERT QUERY NO: 302 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504922, 'Etti', 'Denisyuk', 'C1', 'N10452', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO452@gmail.com', 4036669426, 10425, 20424
);

/* INSERT QUERY NO: 303 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504923, 'Denny', 'Nabarro', 'C1', 'N10453', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO453@gmail.com', 4036669427, 10426, 20425
);

/* INSERT QUERY NO: 304 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504924, 'Ara', 'Tomkinson', 'C1', 'N10454', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO454@gmail.com', 4036669428, 10427, 20426
);

/* INSERT QUERY NO: 305 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504925, 'Clare', 'Cabena', 'C1', 'N10455', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO455@gmail.com', 4036669429, 10428, 20427
);

/* INSERT QUERY NO: 306 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504926, 'Tony', 'Dary', 'C1', 'N10456', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO456@gmail.com', 4036669430, 10429, 20428
);

/* INSERT QUERY NO: 307 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504927, 'Budd', 'Coolson', 'C1', 'N10457', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO457@gmail.com', 4036669431, 10430, 20429
);

/* INSERT QUERY NO: 308 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504928, 'Elene', 'Tailour', 'C1', 'N10458', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO458@gmail.com', 4036669432, 10431, 20430
);

/* INSERT QUERY NO: 309 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504929, 'Cathie', 'Worvill', 'C1', 'N10459', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO459@gmail.com', 4036669433, 10432, 20431
);

/* INSERT QUERY NO: 310 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504930, 'Lorene', 'Brun', 'C1', 'N10460', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO460@gmail.com', 4036669434, 10433, 20432
);

/* INSERT QUERY NO: 311 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504931, 'Ketty', 'Twiddell', 'C1', 'N10461', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO461@gmail.com', 4036669435, 10434, 20433
);

/* INSERT QUERY NO: 312 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504932, 'Giselbert', 'Cuerdall', 'C1', 'N10462', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO462@gmail.com', 4036669436, 10435, 20434
);

/* INSERT QUERY NO: 313 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504933, 'Sheridan', 'Husset', 'C1', 'N10463', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO463@gmail.com', 4036669437, 10436, 20435
);

/* INSERT QUERY NO: 314 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504934, 'Juliann', 'Cottrill', 'C1', 'N10464', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO464@gmail.com', 4036669438, 10437, 20436
);

/* INSERT QUERY NO: 315 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504935, 'Crista', 'Creeboe', 'C1', 'N10465', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO465@gmail.com', 4036669439, 10438, 20437
);

/* INSERT QUERY NO: 316 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504936, 'Corry', 'Brotherhood', 'C1', 'N10466', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO466@gmail.com', 4036669440, 10439, 20438
);

/* INSERT QUERY NO: 317 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504937, 'Hyacinth', 'Dodds', 'C1', 'N10467', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO467@gmail.com', 4036669441, 10440, 20439
);

/* INSERT QUERY NO: 318 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504938, 'Arnaldo', 'Gain', 'C1', 'N10468', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO468@gmail.com', 4036669442, 10441, 20440
);

/* INSERT QUERY NO: 319 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504939, 'Hamilton', 'Gerkens', 'C1', 'N10469', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO469@gmail.com', 4036669443, 10442, 20441
);

/* INSERT QUERY NO: 320 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504940, 'Waneta', 'Febry', 'C1', 'N10470', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO470@gmail.com', 4036669444, 10443, 20442
);

/* INSERT QUERY NO: 321 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504941, 'Ernie', 'Desseine', 'C1', 'N10471', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO471@gmail.com', 4036669445, 10444, 20443
);

/* INSERT QUERY NO: 322 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504942, 'Stanley', 'Meeke', 'C1', 'N10472', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO472@gmail.com', 4036669446, 10445, 20444
);

/* INSERT QUERY NO: 323 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504943, 'Filberte', 'Armin', 'C1', 'N10473', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO473@gmail.com', 4036669447, 10446, 20445
);

/* INSERT QUERY NO: 324 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504944, 'Brittney', 'Vigrass', 'C1', 'N10474', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO474@gmail.com', 4036669448, 10447, 20446
);

/* INSERT QUERY NO: 325 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504945, 'Chaddie', 'Allbones', 'C1', 'N10475', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO475@gmail.com', 4036669449, 10448, 20447
);

/* INSERT QUERY NO: 326 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504946, 'Kattie', 'Mayhew', 'C1', 'N10476', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO476@gmail.com', 4036669450, 10449, 20448
);

/* INSERT QUERY NO: 327 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504947, 'Dewey', 'Whissell', 'C1', 'N10477', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO477@gmail.com', 4036669451, 10450, 20449
);

/* INSERT QUERY NO: 328 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504948, 'Karlens', 'Ruddock', 'C1', 'N10478', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO478@gmail.com', 4036669452, 10451, 20450
);

/* INSERT QUERY NO: 329 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504949, 'Tiffanie', 'Bysh', 'C1', 'N10479', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO479@gmail.com', 4036669453, 10452, 20451
);

/* INSERT QUERY NO: 330 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504950, 'Estrella', 'Givens', 'C1', 'N10480', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO480@gmail.com', 4036669454, 10453, 20452
);

/* INSERT QUERY NO: 331 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504951, 'Murray', 'Norewood', 'C1', 'N10481', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO481@gmail.com', 4036669455, 10454, 20453
);

/* INSERT QUERY NO: 332 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504952, 'Violet', 'Kevane', 'C1', 'N10482', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO482@gmail.com', 4036669456, 10455, 20454
);

/* INSERT QUERY NO: 333 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504953, 'Felipa', 'Kettlewell', 'C1', 'N10483', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO483@gmail.com', 4036669457, 10456, 20455
);

/* INSERT QUERY NO: 334 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504954, 'Alvinia', 'Le Floch', 'C1', 'N10484', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO484@gmail.com', 4036669458, 10457, 20456
);

/* INSERT QUERY NO: 335 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504955, 'Jorie', 'Parken', 'C1', 'N10485', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO485@gmail.com', 4036669459, 10458, 20457
);

/* INSERT QUERY NO: 336 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504956, 'Kale', 'Navarro', 'C1', 'N10486', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO486@gmail.com', 4036669460, 10459, 20458
);

/* INSERT QUERY NO: 337 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504957, 'Alex', 'Beagan', 'C1', 'N10487', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO487@gmail.com', 4036669461, 10460, 20459
);

/* INSERT QUERY NO: 338 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504958, 'Franni', 'Allanby', 'C1', 'N10488', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO488@gmail.com', 4036669462, 10461, 20460
);

/* INSERT QUERY NO: 339 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504959, 'Mella', 'Edgeley', 'C1', 'N10489', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO489@gmail.com', 4036669463, 10462, 20461
);

/* INSERT QUERY NO: 340 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504960, 'Spike', 'Bartolommeo', 'C1', 'N10490', 'O+', TO_DATE('4/5/1985','DD/MM/YYYY'), 'BOGOTA', 'CORREO490@gmail.com', 4036669464, 10463, 20462
);

/* INSERT QUERY NO: 341 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504961, 'Jeth', 'Finker', 'C1', 'N10491', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO491@gmail.com', 4036669465, 10464, 20463
);

/* INSERT QUERY NO: 342 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504962, 'Ennis', 'Croix', 'C1', 'N10492', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO492@gmail.com', 4036669466, 10465, 20464
);

/* INSERT QUERY NO: 343 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504963, 'Prue', 'Atton', 'C1', 'N10493', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO493@gmail.com', 4036669467, 10466, 20465
);

/* INSERT QUERY NO: 344 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504964, 'Damian', 'Sowrah', 'C1', 'N10494', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO494@gmail.com', 4036669468, 10467, 20466
);

/* INSERT QUERY NO: 345 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504965, 'Wylma', 'Regan', 'C1', 'N10495', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO495@gmail.com', 4036669469, 10468, 20467
);

/* INSERT QUERY NO: 346 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504966, 'Nikoletta', 'Bliven', 'C1', 'N10496', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO496@gmail.com', 4036669470, 10469, 20468
);

/* INSERT QUERY NO: 347 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504967, 'Harrison', 'Goodbanne', 'C1', 'N10497', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO497@gmail.com', 4036669471, 10470, 20469
);

/* INSERT QUERY NO: 348 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504968, 'Rossie', 'Fuge', 'C1', 'N10498', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO498@gmail.com', 4036669472, 10471, 20470
);

/* INSERT QUERY NO: 349 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504969, 'Patricio', 'Hurdidge', 'C1', 'N10499', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO499@gmail.com', 4036669473, 10472, 20471
);

/* INSERT QUERY NO: 350 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504970, 'Maia', 'Soule', 'C1', 'N10500', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO500@gmail.com', 4036669474, 10473, 20472
);

/* INSERT QUERY NO: 351 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504971, 'Reynold', 'Chawkley', 'C1', 'N10501', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO501@gmail.com', 4036669475, 10474, 20473
);

/* INSERT QUERY NO: 352 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504972, 'Shea', 'Cattow', 'C1', 'N10502', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO502@gmail.com', 4036669476, 10475, 20474
);

/* INSERT QUERY NO: 353 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504973, 'Gilbert', 'Praundl', 'C1', 'N10503', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO503@gmail.com', 4036669477, 10476, 20475
);

/* INSERT QUERY NO: 354 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504974, 'Alasteir', 'Shyram', 'C1', 'N10504', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO504@gmail.com', 4036669478, 10477, 20476
);

/* INSERT QUERY NO: 355 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504975, 'Nanci', 'Blight', 'C1', 'N10505', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO505@gmail.com', 4036669479, 10478, 20477
);

/* INSERT QUERY NO: 356 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504976, 'Ingmar', 'Cawson', 'C1', 'N10506', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO506@gmail.com', 4036669480, 10479, 20478
);

/* INSERT QUERY NO: 357 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504977, 'Alexina', 'Bundock', 'C1', 'N10507', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO507@gmail.com', 4036669481, 10480, 20479
);

/* INSERT QUERY NO: 358 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504978, 'Kendrick', 'Sturror', 'C1', 'N10508', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO508@gmail.com', 4036669482, 10481, 20480
);

/* INSERT QUERY NO: 359 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504979, 'Kass', 'Rawood', 'C1', 'N10509', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO509@gmail.com', 4036669483, 10482, 20481
);

/* INSERT QUERY NO: 360 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504980, 'Carmelina', 'Kellar', 'C1', 'N10510', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO510@gmail.com', 4036669484, 10483, 20482
);

/* INSERT QUERY NO: 361 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504981, 'Ransom', 'Rubinovitch', 'C1', 'N10511', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO511@gmail.com', 4036669485, 10484, 20483
);

/* INSERT QUERY NO: 362 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504982, 'Aurelia', 'Connew', 'C1', 'N10512', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO512@gmail.com', 4036669486, 10485, 20484
);

/* INSERT QUERY NO: 363 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504983, 'Marget', 'Giannini', 'C1', 'N10513', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO513@gmail.com', 4036669487, 10486, 20485
);

/* INSERT QUERY NO: 364 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504984, 'Christiano', 'Schonfelder', 'C1', 'N10514', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO514@gmail.com', 4036669488, 10487, 20486
);

/* INSERT QUERY NO: 365 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504985, 'Austin', 'Placido', 'C1', 'N10515', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO515@gmail.com', 4036669489, 10488, 20487
);

/* INSERT QUERY NO: 366 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504986, 'Kip', 'Steuhlmeyer', 'C1', 'N10516', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO516@gmail.com', 4036669490, 10489, 20488
);

/* INSERT QUERY NO: 367 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504987, 'Lincoln', 'Vannucci', 'C1', 'N10517', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO517@gmail.com', 4036669491, 10490, 20489
);

/* INSERT QUERY NO: 368 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504988, 'Ann', 'Arthy', 'C1', 'N10518', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO518@gmail.com', 4036669492, 10491, 20490
);

/* INSERT QUERY NO: 369 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504989, 'Francisco', 'Syer', 'C1', 'N10519', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO519@gmail.com', 4036669493, 10492, 20491
);

/* INSERT QUERY NO: 370 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504990, 'Ly', 'Mungham', 'C1', 'N10520', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO520@gmail.com', 4036669494, 10493, 20492
);

/* INSERT QUERY NO: 371 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504991, 'Pepita', 'Charlotte', 'C1', 'N10521', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO521@gmail.com', 4036669495, 10494, 20493
);

/* INSERT QUERY NO: 372 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504992, 'Manolo', 'Rowney', 'C1', 'N10522', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO522@gmail.com', 4036669496, 10495, 20494
);

/* INSERT QUERY NO: 373 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504993, 'Madelene', 'Skuce', 'C1', 'N10523', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO523@gmail.com', 4036669497, 10496, 20495
);

/* INSERT QUERY NO: 374 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504994, 'Winna', 'McFarlan', 'C1', 'N10524', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO524@gmail.com', 4036669498, 10497, 20496
);

/* INSERT QUERY NO: 375 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504995, 'Marta', 'Barsby', 'C1', 'N10525', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO525@gmail.com', 4036669499, 10498, 20497
);

/* INSERT QUERY NO: 376 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504996, 'Aaron', 'Catton', 'C1', 'N10526', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO526@gmail.com', 4036669500, 10499, 20498
);

/* INSERT QUERY NO: 377 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504997, 'Duky', 'Hulburd', 'C1', 'N10527', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO527@gmail.com', 4036669501, 10500, 20499
);

/* INSERT QUERY NO: 378 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504998, 'Aylmer', 'Manhood', 'C1', 'N10528', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO528@gmail.com', 4036669502, 10501, 20500
);

/* INSERT QUERY NO: 379 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52504999, 'Audy', 'Wimpress', 'C1', 'N10529', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO529@gmail.com', 4036669503, 10502, 20501
);

/* INSERT QUERY NO: 380 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505000, 'Marna', 'Risdall', 'C1', 'N10530', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO530@gmail.com', 4036669504, 10503, 20502
);

/* INSERT QUERY NO: 381 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505001, 'Ann', 'Tender', 'C1', 'N10531', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO531@gmail.com', 4036669505, 10504, 20503
);

/* INSERT QUERY NO: 382 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505002, 'Filia', 'Hawler', 'C1', 'N10532', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO532@gmail.com', 4036669506, 10505, 20504
);

/* INSERT QUERY NO: 383 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505003, 'Temp', 'Arundel', 'C1', 'N10533', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO533@gmail.com', 4036669507, 10506, 20505
);

/* INSERT QUERY NO: 384 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505004, 'Valle', 'Betham', 'C1', 'N10534', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO534@gmail.com', 4036669508, 10507, 20506
);

/* INSERT QUERY NO: 385 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505005, 'Ginnifer', 'Welham', 'C1', 'N10535', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO535@gmail.com', 4036669509, 10508, 20507
);

/* INSERT QUERY NO: 386 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505006, 'Dorothee', 'Acland', 'C1', 'N10536', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO536@gmail.com', 4036669510, 10509, 20508
);

/* INSERT QUERY NO: 387 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505007, 'Linc', 'Mead', 'C1', 'N10537', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO537@gmail.com', 4036669511, 10510, 20509
);

/* INSERT QUERY NO: 388 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505008, 'Harmonia', 'Malbon', 'C1', 'N10538', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO538@gmail.com', 4036669512, 10511, 20510
);

/* INSERT QUERY NO: 389 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505009, 'Tedie', 'Meritt', 'C1', 'N10539', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO539@gmail.com', 4036669513, 10512, 20511
);

/* INSERT QUERY NO: 390 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505010, 'Susannah', 'Evill', 'C1', 'N10540', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO540@gmail.com', 4036669514, 10513, 20512
);

/* INSERT QUERY NO: 391 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505011, 'Harrison', 'Laker', 'C1', 'N10541', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO541@gmail.com', 4036669515, 10514, 20513
);

/* INSERT QUERY NO: 392 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505012, 'Felicle', 'Helliwell', 'C1', 'N10542', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO542@gmail.com', 4036669516, 10515, 20514
);

/* INSERT QUERY NO: 393 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505013, 'Fowler', 'Fulle', 'C1', 'N10543', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO543@gmail.com', 4036669517, 10516, 20515
);

/* INSERT QUERY NO: 394 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505014, 'Ursuline', 'McNeice', 'C1', 'N10544', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO544@gmail.com', 4036669518, 10517, 20516
);

/* INSERT QUERY NO: 395 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505015, 'Carrol', 'Firebrace', 'C1', 'N10545', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO545@gmail.com', 4036669519, 10518, 20517
);

/* INSERT QUERY NO: 396 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505016, 'Pail', 'Beardsall', 'C1', 'N10546', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO546@gmail.com', 4036669520, 10519, 20518
);

/* INSERT QUERY NO: 397 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505017, 'Cindie', 'Jolland', 'C1', 'N10547', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO547@gmail.com', 4036669521, 10520, 20519
);

/* INSERT QUERY NO: 398 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505018, 'Jyoti', 'Cranson', 'C1', 'N10548', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO548@gmail.com', 4036669522, 10521, 20520
);

/* INSERT QUERY NO: 399 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505019, 'Hilton', 'Easby', 'C1', 'N10549', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO549@gmail.com', 4036669523, 10522, 20521
);

/* INSERT QUERY NO: 400 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505020, 'Babita', 'Aronson', 'C1', 'N10550', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO550@gmail.com', 4036669524, 10523, 20522
);

/* INSERT QUERY NO: 401 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505021, 'Gill', 'Stevenson', 'C1', 'N10551', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO551@gmail.com', 4036669525, 10524, 20523
);

/* INSERT QUERY NO: 402 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505022, 'Merl', 'Pavey', 'C1', 'N10552', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO552@gmail.com', 4036669526, 10525, 20524
);

/* INSERT QUERY NO: 403 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505023, 'Candida', 'Abrahami', 'C1', 'N10553', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO553@gmail.com', 4036669527, 10526, 20525
);

/* INSERT QUERY NO: 404 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505024, 'Tildy', 'Evenett', 'C1', 'N10554', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO554@gmail.com', 4036669528, 10527, 20526
);

/* INSERT QUERY NO: 405 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505025, 'Duane', 'Manuelli', 'C1', 'N10555', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO555@gmail.com', 4036669529, 10528, 20527
);

/* INSERT QUERY NO: 406 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505026, 'Kalil', 'Eastby', 'C1', 'N10556', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO556@gmail.com', 4036669530, 10529, 20528
);

/* INSERT QUERY NO: 407 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505027, 'Gabrila', 'Dymond', 'C1', 'N10557', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO557@gmail.com', 4036669531, 10530, 20529
);

/* INSERT QUERY NO: 408 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505028, 'Pattie', 'McLevie', 'C1', 'N10558', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO558@gmail.com', 4036669532, 10531, 20530
);

/* INSERT QUERY NO: 409 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505029, 'Gypsy', 'Kleinschmidt', 'C1', 'N10559', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO559@gmail.com', 4036669533, 10532, 20531
);

/* INSERT QUERY NO: 410 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505030, 'Rafaello', 'Bossom', 'C1', 'N10560', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO560@gmail.com', 4036669534, 10533, 20532
);

/* INSERT QUERY NO: 411 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505031, 'Lishe', 'Fessler', 'C1', 'N10561', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO561@gmail.com', 4036669535, 10534, 20533
);

/* INSERT QUERY NO: 412 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505032, 'Robert', 'Strawbridge', 'C1', 'N10562', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO562@gmail.com', 4036669536, 10535, 20534
);

/* INSERT QUERY NO: 413 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505033, 'Elvyn', 'Weigh', 'C1', 'N10563', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO563@gmail.com', 4036669537, 10536, 20535
);

/* INSERT QUERY NO: 414 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505034, 'Merle', 'Lamlin', 'C1', 'N10564', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO564@gmail.com', 4036669538, 10537, 20536
);

/* INSERT QUERY NO: 415 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505035, 'Helena', 'Le Provost', 'C1', 'N10565', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO565@gmail.com', 4036669539, 10538, 20537
);

/* INSERT QUERY NO: 416 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505036, 'Winifred', 'Flay', 'C1', 'N10566', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO566@gmail.com', 4036669540, 10539, 20538
);

/* INSERT QUERY NO: 417 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505037, 'Omero', 'De Paepe', 'C1', 'N10567', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO567@gmail.com', 4036669541, 10540, 20539
);

/* INSERT QUERY NO: 418 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505038, 'Curran', 'Kemetz', 'C1', 'N10568', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO568@gmail.com', 4036669542, 10541, 20540
);

/* INSERT QUERY NO: 419 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505039, 'Ives', 'Gahagan', 'C1', 'N10569', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO569@gmail.com', 4036669543, 10542, 20541
);

/* INSERT QUERY NO: 420 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505040, 'Marni', 'Blenkinsop', 'C1', 'N10570', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO570@gmail.com', 4036669544, 10543, 20542
);

/* INSERT QUERY NO: 421 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505041, 'Harlie', 'Buckie', 'C1', 'N10571', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO571@gmail.com', 4036669545, 10544, 20543
);

/* INSERT QUERY NO: 422 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505042, 'Bernetta', 'Chelnam', 'C1', 'N10572', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO572@gmail.com', 4036669546, 10545, 20544
);

/* INSERT QUERY NO: 423 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505043, 'Correy', 'Petracco', 'C1', 'N10573', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO573@gmail.com', 4036669547, 10546, 20545
);

/* INSERT QUERY NO: 424 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505044, 'Gabbey', 'Coulson', 'C1', 'N10574', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO574@gmail.com', 4036669548, 10547, 20546
);

/* INSERT QUERY NO: 425 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505045, 'Denny', 'Robelow', 'C1', 'N10575', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO575@gmail.com', 4036669549, 10548, 20547
);

/* INSERT QUERY NO: 426 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505046, 'Kettie', 'Piborn', 'C1', 'N10576', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO576@gmail.com', 4036669550, 10549, 20548
);

/* INSERT QUERY NO: 427 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505047, 'Kellen', 'Laidlaw', 'C1', 'N10577', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO577@gmail.com', 4036669551, 10550, 20549
);

/* INSERT QUERY NO: 428 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505048, 'Erin', 'Tointon', 'C1', 'N10578', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO578@gmail.com', 4036669552, 10551, 20550
);

/* INSERT QUERY NO: 429 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505049, 'Mag', 'Mozzini', 'C1', 'N10579', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO579@gmail.com', 4036669553, 10552, 20551
);

/* INSERT QUERY NO: 430 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505050, 'Oriana', 'Couper', 'C1', 'N10580', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO580@gmail.com', 4036669554, 10553, 20552
);

/* INSERT QUERY NO: 431 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505051, 'Herbie', 'Baskerfield', 'C1', 'N10581', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO581@gmail.com', 4036669555, 10554, 20553
);

/* INSERT QUERY NO: 432 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505052, 'Coretta', 'Peracco', 'C1', 'N10582', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO582@gmail.com', 4036669556, 10555, 20554
);

/* INSERT QUERY NO: 433 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505053, 'Kevina', 'Graysmark', 'C1', 'N10583', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO583@gmail.com', 4036669557, 10556, 20555
);

/* INSERT QUERY NO: 434 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505054, 'Julian', 'Spellar', 'C1', 'N10584', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO584@gmail.com', 4036669558, 10557, 20556
);

/* INSERT QUERY NO: 435 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505055, 'Alexia', 'Bernardelli', 'C1', 'N10585', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO585@gmail.com', 4036669559, 10558, 20557
);

/* INSERT QUERY NO: 436 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505056, 'Norby', 'Stoneman', 'C1', 'N10586', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO586@gmail.com', 4036669560, 10559, 20558
);

/* INSERT QUERY NO: 437 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505057, 'Marc', 'Potteril', 'C1', 'N10587', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO587@gmail.com', 4036669561, 10560, 20559
);

/* INSERT QUERY NO: 438 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505058, 'Winonah', 'Prattington', 'C1', 'N10588', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO588@gmail.com', 4036669562, 10561, 20560
);

/* INSERT QUERY NO: 439 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505059, 'Nicky', 'Snibson', 'C1', 'N10589', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO589@gmail.com', 4036669563, 10562, 20561
);

/* INSERT QUERY NO: 440 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505060, 'Puff', 'McKeurton', 'C1', 'N10590', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO590@gmail.com', 4036669564, 10563, 20562
);

/* INSERT QUERY NO: 441 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505061, 'Godfree', 'Ellph', 'C1', 'N10591', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO591@gmail.com', 4036669565, 10564, 20563
);

/* INSERT QUERY NO: 442 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505062, 'Alanna', 'Beevors', 'C1', 'N10592', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO592@gmail.com', 4036669566, 10565, 20564
);

/* INSERT QUERY NO: 443 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505063, 'Cathrin', 'Winteringham', 'C1', 'N10593', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO593@gmail.com', 4036669567, 10566, 20565
);

/* INSERT QUERY NO: 444 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505064, 'Deni', 'Finlry', 'C1', 'N10594', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO594@gmail.com', 4036669568, 10567, 20566
);

/* INSERT QUERY NO: 445 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505065, 'Benedetta', 'Newman', 'C1', 'N10595', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO595@gmail.com', 4036669569, 10568, 20567
);

/* INSERT QUERY NO: 446 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505066, 'Althea', 'Balfour', 'C1', 'N10596', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO596@gmail.com', 4036669570, 10569, 20568
);

/* INSERT QUERY NO: 447 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505067, 'Nanon', 'Krahl', 'C1', 'N10597', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO597@gmail.com', 4036669571, 10570, 20569
);

/* INSERT QUERY NO: 448 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505068, 'Tessi', 'Trorey', 'C1', 'N10598', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO598@gmail.com', 4036669572, 10571, 20570
);

/* INSERT QUERY NO: 449 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505069, 'Ulrike', 'Westcot', 'C1', 'N10599', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO599@gmail.com', 4036669573, 10572, 20571
);

/* INSERT QUERY NO: 450 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505070, 'Benny', 'Roback', 'C1', 'N10600', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO600@gmail.com', 4036669574, 10573, 20572
);

/* INSERT QUERY NO: 451 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505071, 'Derron', 'Cumbes', 'C1', 'N10601', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO601@gmail.com', 4036669575, 10574, 20573
);

/* INSERT QUERY NO: 452 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505072, 'Eddi', 'Keble', 'C1', 'N10602', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO602@gmail.com', 4036669576, 10575, 20574
);

/* INSERT QUERY NO: 453 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505073, 'Spenser', 'Cristoforo', 'C1', 'N10603', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO603@gmail.com', 4036669577, 10576, 20575
);

/* INSERT QUERY NO: 454 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505074, 'Darnall', 'Semmens', 'C1', 'N10604', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO604@gmail.com', 4036669578, 10577, 20576
);

/* INSERT QUERY NO: 455 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505075, 'Peria', 'Crippin', 'C1', 'N10605', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO605@gmail.com', 4036669579, 10578, 20577
);

/* INSERT QUERY NO: 456 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505076, 'Judy', 'Kettell', 'C1', 'N10606', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO606@gmail.com', 4036669580, 10579, 20578
);

/* INSERT QUERY NO: 457 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505077, 'Corissa', 'Sawkins', 'C1', 'N10607', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO607@gmail.com', 4036669581, 10580, 20579
);

/* INSERT QUERY NO: 458 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505078, 'Luis', 'Caff', 'C1', 'N10608', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO608@gmail.com', 4036669582, 10581, 20580
);

/* INSERT QUERY NO: 459 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505079, 'Maynord', 'Greensmith', 'C1', 'N10609', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO609@gmail.com', 4036669583, 10582, 20581
);

/* INSERT QUERY NO: 460 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505080, 'Lionello', 'Oiseau', 'C1', 'N10610', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO610@gmail.com', 4036669584, 10583, 20582
);

/* INSERT QUERY NO: 461 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505081, 'Cheryl', 'Rechert', 'C1', 'N10611', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO611@gmail.com', 4036669585, 10584, 20583
);

/* INSERT QUERY NO: 462 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505082, 'Antonetta', 'Lovelady', 'C1', 'N10612', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO612@gmail.com', 4036669586, 10585, 20584
);

/* INSERT QUERY NO: 463 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505083, 'Jonathan', 'Satyford', 'C1', 'N10613', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO613@gmail.com', 4036669587, 10586, 20585
);

/* INSERT QUERY NO: 464 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505084, 'Saundra', 'Yakunchikov', 'C1', 'N10614', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO614@gmail.com', 4036669588, 10587, 20586
);

/* INSERT QUERY NO: 465 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505085, 'Phyllida', 'Gero', 'C1', 'N10615', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO615@gmail.com', 4036669589, 10588, 20587
);

/* INSERT QUERY NO: 466 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505086, 'Lidia', 'Tayspell', 'C1', 'N10616', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO616@gmail.com', 4036669590, 10589, 20588
);

/* INSERT QUERY NO: 467 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505087, 'Miguelita', 'Schruur', 'C1', 'N10617', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO617@gmail.com', 4036669591, 10590, 20589
);

/* INSERT QUERY NO: 468 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505088, 'Fernande', 'Klaussen', 'C1', 'N10618', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO618@gmail.com', 4036669592, 10591, 20590
);

/* INSERT QUERY NO: 469 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505089, 'Oby', 'Castano', 'C1', 'N10619', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO619@gmail.com', 4036669593, 10592, 20591
);

/* INSERT QUERY NO: 470 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505090, 'Willie', 'Emby', 'C1', 'N10620', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO620@gmail.com', 4036669594, 10593, 20592
);

/* INSERT QUERY NO: 471 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505091, 'Sybille', 'Luckett', 'C1', 'N10621', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO621@gmail.com', 4036669595, 10594, 20593
);

/* INSERT QUERY NO: 472 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505092, 'Ogdan', 'Brattan', 'C1', 'N10622', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO622@gmail.com', 4036669596, 10595, 20594
);

/* INSERT QUERY NO: 473 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505093, 'Marci', 'Rosenblatt', 'C1', 'N10623', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO623@gmail.com', 4036669597, 10596, 20595
);

/* INSERT QUERY NO: 474 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505094, 'Dyanne', 'Barehead', 'C1', 'N10624', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO624@gmail.com', 4036669598, 10597, 20596
);

/* INSERT QUERY NO: 475 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505095, 'Sutherland', 'Maskill', 'C1', 'N10625', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO625@gmail.com', 4036669599, 10598, 20597
);

/* INSERT QUERY NO: 476 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505096, 'Ringo', 'State', 'C1', 'N10626', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO626@gmail.com', 4036669600, 10599, 20598
);

/* INSERT QUERY NO: 477 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505097, 'Isidore', 'ODaly', 'C1', 'N10627', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO627@gmail.com', 4036669601, 10600, 20599
);

/* INSERT QUERY NO: 478 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505098, 'Noe', 'Krysztofiak', 'C1', 'N10628', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO628@gmail.com', 4036669602, 10601, 20600
);

/* INSERT QUERY NO: 479 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505099, 'Trudi', 'Losselyong', 'C1', 'N10629', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO629@gmail.com', 4036669603, 10602, 20601
);

/* INSERT QUERY NO: 480 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505100, 'Rafi', 'Haville', 'C1', 'N10630', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO630@gmail.com', 4036669604, 10603, 20602
);

/* INSERT QUERY NO: 481 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505101, 'Valentino', 'Sparkes', 'C1', 'N10631', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO631@gmail.com', 4036669605, 10604, 20603
);

/* INSERT QUERY NO: 482 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505102, 'Cammi', 'Loxley', 'C1', 'N10632', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO632@gmail.com', 4036669606, 10605, 20604
);

/* INSERT QUERY NO: 483 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505103, 'Leshia', 'Donet', 'C1', 'N10633', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO633@gmail.com', 4036669607, 10606, 20605
);

/* INSERT QUERY NO: 484 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505104, 'Anderea', 'Hallitt', 'C1', 'N10634', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO634@gmail.com', 4036669608, 10607, 20606
);

/* INSERT QUERY NO: 485 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505105, 'Claudetta', 'Drydale', 'C1', 'N10635', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO635@gmail.com', 4036669609, 10608, 20607
);

/* INSERT QUERY NO: 486 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505106, 'Revkah', 'OShaughnessy', 'C1', 'N10636', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO636@gmail.com', 4036669610, 10609, 20608
);

/* INSERT QUERY NO: 487 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505107, 'Jordain', 'Matus', 'C1', 'N10637', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO637@gmail.com', 4036669611, 10610, 20609
);

/* INSERT QUERY NO: 488 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505108, 'Ignacius', 'Grigorushkin', 'C1', 'N10638', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO638@gmail.com', 4036669612, 10611, 20610
);

/* INSERT QUERY NO: 489 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505109, 'Helyn', 'Gurden', 'C1', 'N10639', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO639@gmail.com', 4036669613, 10612, 20611
);

/* INSERT QUERY NO: 490 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505110, 'Alvan', 'Kirkman', 'C1', 'N10640', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO640@gmail.com', 4036669614, 10613, 20612
);

/* INSERT QUERY NO: 491 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505111, 'Susie', 'Martelet', 'C1', 'N10641', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO641@gmail.com', 4036669615, 10614, 20613
);

/* INSERT QUERY NO: 492 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505112, 'Berky', 'Lace', 'C1', 'N10642', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO642@gmail.com', 4036669616, 10615, 20614
);

/* INSERT QUERY NO: 493 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505113, 'Sholom', 'Caudwell', 'C1', 'N10643', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO643@gmail.com', 4036669617, 10616, 20615
);

/* INSERT QUERY NO: 494 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505114, 'Tildi', 'Dominelli', 'C1', 'N10644', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO644@gmail.com', 4036669618, 10617, 20616
);

/* INSERT QUERY NO: 495 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505115, 'Melly', 'Broodes', 'C1', 'N10645', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO645@gmail.com', 4036669619, 10618, 20617
);

/* INSERT QUERY NO: 496 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505116, 'Will', 'Allam', 'C1', 'N10646', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO646@gmail.com', 4036669620, 10619, 20618
);

/* INSERT QUERY NO: 497 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505117, 'Baxy', 'Reinisch', 'C1', 'N10647', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO647@gmail.com', 4036669621, 10620, 20619
);

/* INSERT QUERY NO: 498 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505118, 'Carmel', 'Minithorpe', 'C1', 'N10648', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO648@gmail.com', 4036669622, 10621, 20620
);

/* INSERT QUERY NO: 499 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505119, 'Gretel', 'Errichi', 'C1', 'N10649', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO649@gmail.com', 4036669623, 10622, 20621
);

/* INSERT QUERY NO: 500 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505120, 'Kelby', 'Salsbury', 'C1', 'N10650', 'O-', TO_DATE('4/5/1985','DD/MM/YYYY'), 'MEDELLIN', 'CORREO650@gmail.com', 4036669624, 10623, 20622
);

/* INSERT QUERY NO: 501 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505121, 'Coralie', 'Mournian', 'C2', 'N10651', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO651@gmail.com', 4036669625, 10624, 20623
);

/* INSERT QUERY NO: 502 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505122, 'Tan', 'Franies', 'C2', 'N10652', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO652@gmail.com', 4036669626, 10625, 20624
);

/* INSERT QUERY NO: 503 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505123, 'Sukey', 'Hobson', 'C2', 'N10653', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO653@gmail.com', 4036669627, 10626, 20625
);

/* INSERT QUERY NO: 504 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505124, 'Maxine', 'Callf', 'C2', 'N10654', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO654@gmail.com', 4036669628, 10627, 20626
);

/* INSERT QUERY NO: 505 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505125, 'Priscella', 'Harget', 'C2', 'N10655', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO655@gmail.com', 4036669629, 10628, 20627
);

/* INSERT QUERY NO: 506 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505126, 'Saunderson', 'Torregiani', 'C2', 'N10656', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO656@gmail.com', 4036669630, 10629, 20628
);

/* INSERT QUERY NO: 507 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505127, 'Klement', 'Lawlie', 'C2', 'N10657', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO657@gmail.com', 4036669631, 10630, 20629
);

/* INSERT QUERY NO: 508 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505128, 'Terencio', 'MacGee', 'C2', 'N10658', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO658@gmail.com', 4036669632, 10631, 20630
);

/* INSERT QUERY NO: 509 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505129, 'Ingeberg', 'Sattin', 'C2', 'N10659', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO659@gmail.com', 4036669633, 10632, 20631
);

/* INSERT QUERY NO: 510 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505130, 'Danielle', 'Fockes', 'C2', 'N10660', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO660@gmail.com', 4036669634, 10633, 20632
);

/* INSERT QUERY NO: 511 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505131, 'Brittany', 'Cheesworth', 'C2', 'N10661', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO661@gmail.com', 4036669635, 10634, 20633
);

/* INSERT QUERY NO: 512 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505132, 'Terri-jo', 'Hylands', 'C2', 'N10662', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO662@gmail.com', 4036669636, 10635, 20634
);

/* INSERT QUERY NO: 513 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505133, 'Jacquenetta', 'Schaben', 'C2', 'N10663', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO663@gmail.com', 4036669637, 10636, 20635
);

/* INSERT QUERY NO: 514 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505134, 'Bronson', 'Gozney', 'C2', 'N10664', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO664@gmail.com', 4036669638, 10637, 20636
);

/* INSERT QUERY NO: 515 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505135, 'Jeralee', 'Harriagn', 'C2', 'N10665', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO665@gmail.com', 4036669639, 10638, 20637
);

/* INSERT QUERY NO: 516 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505136, 'Danya', 'Koppes', 'C2', 'N10666', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO666@gmail.com', 4036669640, 10639, 20638
);

/* INSERT QUERY NO: 517 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505137, 'Roosevelt', 'Oxborrow', 'C2', 'N10667', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO667@gmail.com', 4036669641, 10640, 20639
);

/* INSERT QUERY NO: 518 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505138, 'Latisha', 'Steketee', 'C2', 'N10668', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO668@gmail.com', 4036669642, 10641, 20640
);

/* INSERT QUERY NO: 519 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505139, 'Rockie', 'Tidbold', 'C2', 'N10669', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO669@gmail.com', 4036669643, 10642, 20641
);

/* INSERT QUERY NO: 520 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505140, 'Kristos', 'Wyre', 'C2', 'N10670', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO670@gmail.com', 4036669644, 10643, 20642
);

/* INSERT QUERY NO: 521 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505141, 'Carlin', 'Tripe', 'C2', 'N10671', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO671@gmail.com', 4036669645, 10644, 20643
);

/* INSERT QUERY NO: 522 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505142, 'Gennie', 'Tirone', 'C2', 'N10672', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO672@gmail.com', 4036669646, 10645, 20644
);

/* INSERT QUERY NO: 523 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505143, 'Kayley', 'MacGeffen', 'C2', 'N10673', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO673@gmail.com', 4036669647, 10646, 20645
);

/* INSERT QUERY NO: 524 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505144, 'Filip', 'Kirsz', 'C2', 'N10674', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO674@gmail.com', 4036669648, 10647, 20646
);

/* INSERT QUERY NO: 525 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505145, 'Opalina', 'Rice', 'C2', 'N10675', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO675@gmail.com', 4036669649, 10648, 20647
);

/* INSERT QUERY NO: 526 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505146, 'Ware', 'Sneyd', 'C2', 'N10676', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO676@gmail.com', 4036669650, 10649, 20648
);

/* INSERT QUERY NO: 527 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505147, 'Annette', 'Endersby', 'C2', 'N10677', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO677@gmail.com', 4036669651, 10650, 20649
);

/* INSERT QUERY NO: 528 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505148, 'Boigie', 'Selborne', 'C2', 'N10678', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO678@gmail.com', 4036669652, 10651, 20650
);

/* INSERT QUERY NO: 529 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505149, 'Ara', 'Domingues', 'C2', 'N10679', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO679@gmail.com', 4036669653, 10652, 20651
);

/* INSERT QUERY NO: 530 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505150, 'Meryl', 'Cowtherd', 'C2', 'N10680', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO680@gmail.com', 4036669654, 10653, 20652
);

/* INSERT QUERY NO: 531 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505151, 'Oswell', 'Bowkley', 'C2', 'N10681', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO681@gmail.com', 4036669655, 10654, 20653
);

/* INSERT QUERY NO: 532 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505152, 'Morten', 'Corkitt', 'C2', 'N10682', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO682@gmail.com', 4036669656, 10655, 20654
);

/* INSERT QUERY NO: 533 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505153, 'Hedda', 'Pembery', 'C2', 'N10683', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO683@gmail.com', 4036669657, 10656, 20655
);

/* INSERT QUERY NO: 534 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505154, 'Fran', 'Bortoli', 'C2', 'N10684', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO684@gmail.com', 4036669658, 10657, 20656
);

/* INSERT QUERY NO: 535 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505155, 'Lilllie', 'Bartlam', 'C2', 'N10685', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO685@gmail.com', 4036669659, 10658, 20657
);

/* INSERT QUERY NO: 536 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505156, 'Michael', 'Anscott', 'C2', 'N10686', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO686@gmail.com', 4036669660, 10659, 20658
);

/* INSERT QUERY NO: 537 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505157, 'Siouxie', 'Le Grys', 'C2', 'N10687', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO687@gmail.com', 4036669661, 10660, 20659
);

/* INSERT QUERY NO: 538 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505158, 'Franchot', 'Pettyfer', 'C2', 'N10688', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO688@gmail.com', 4036669662, 10661, 20660
);

/* INSERT QUERY NO: 539 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505159, 'Trudi', 'Ropcke', 'C2', 'N10689', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO689@gmail.com', 4036669663, 10662, 20661
);

/* INSERT QUERY NO: 540 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505160, 'Bruno', 'Abden', 'C2', 'N10690', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO690@gmail.com', 4036669664, 10663, 20662
);

/* INSERT QUERY NO: 541 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505161, 'Hyacinthia', 'Borchardt', 'C2', 'N10691', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO691@gmail.com', 4036669665, 10664, 20663
);

/* INSERT QUERY NO: 542 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505162, 'Ebonee', 'Deviney', 'C2', 'N10692', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO692@gmail.com', 4036669666, 10665, 20664
);

/* INSERT QUERY NO: 543 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505163, 'Elinore', 'Glanville', 'C2', 'N10693', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO693@gmail.com', 4036669667, 10666, 20665
);

/* INSERT QUERY NO: 544 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505164, 'Mignon', 'Medler', 'C2', 'N10694', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO694@gmail.com', 4036669668, 10667, 20666
);

/* INSERT QUERY NO: 545 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505165, 'Shaina', 'Goodredge', 'C2', 'N10695', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO695@gmail.com', 4036669669, 10668, 20667
);

/* INSERT QUERY NO: 546 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505166, 'Celestyn', 'McTague', 'C2', 'N10696', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO696@gmail.com', 4036669670, 10669, 20668
);

/* INSERT QUERY NO: 547 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505167, 'Myra', 'Farnham', 'C2', 'N10697', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO697@gmail.com', 4036669671, 10670, 20669
);

/* INSERT QUERY NO: 548 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505168, 'Giulia', 'Caesar', 'C2', 'N10698', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO698@gmail.com', 4036669672, 10671, 20670
);

/* INSERT QUERY NO: 549 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505169, 'Derby', 'Wingeatt', 'C2', 'N10699', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO699@gmail.com', 4036669673, 10672, 20671
);

/* INSERT QUERY NO: 550 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505170, 'Gardener', 'Sibbald', 'C2', 'N10700', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO700@gmail.com', 4036669674, 10673, 20672
);

/* INSERT QUERY NO: 551 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505171, 'Ebony', 'Boyford', 'C2', 'N10701', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO701@gmail.com', 4036669675, 10674, 20673
);

/* INSERT QUERY NO: 552 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505172, 'Meade', 'Remirez', 'C2', 'N10702', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO702@gmail.com', 4036669676, 10675, 20674
);

/* INSERT QUERY NO: 553 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505173, 'Dene', 'Labell', 'C2', 'N10703', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO703@gmail.com', 4036669677, 10676, 20675
);

/* INSERT QUERY NO: 554 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505174, 'Saloma', 'Preshaw', 'C2', 'N10704', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO704@gmail.com', 4036669678, 10677, 20676
);

/* INSERT QUERY NO: 555 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505175, 'Stephannie', 'Topham', 'C2', 'N10705', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO705@gmail.com', 4036669679, 10678, 20677
);

/* INSERT QUERY NO: 556 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505176, 'Cam', 'Fisby', 'C2', 'N10706', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO706@gmail.com', 4036669680, 10679, 20678
);

/* INSERT QUERY NO: 557 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505177, 'Jolyn', 'Levay', 'C2', 'N10707', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO707@gmail.com', 4036669681, 10680, 20679
);

/* INSERT QUERY NO: 558 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505178, 'Nettie', 'Raiman', 'C2', 'N10708', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO708@gmail.com', 4036669682, 10681, 20680
);

/* INSERT QUERY NO: 559 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505179, 'Salvatore', 'Berceros', 'C2', 'N10709', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO709@gmail.com', 4036669683, 10682, 20681
);

/* INSERT QUERY NO: 560 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505180, 'Skye', 'Kewley', 'C2', 'N10710', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO710@gmail.com', 4036669684, 10683, 20682
);

/* INSERT QUERY NO: 561 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505181, 'Adelice', 'Duncklee', 'C2', 'N10711', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO711@gmail.com', 4036669685, 10684, 20683
);

/* INSERT QUERY NO: 562 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505182, 'Brand', 'Mattingson', 'C2', 'N10712', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO712@gmail.com', 4036669686, 10685, 20684
);

/* INSERT QUERY NO: 563 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505183, 'Hester', 'Meys', 'C2', 'N10713', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO713@gmail.com', 4036669687, 10686, 20685
);

/* INSERT QUERY NO: 564 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505184, 'Solly', 'Pergens', 'C2', 'N10714', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO714@gmail.com', 4036669688, 10687, 20686
);

/* INSERT QUERY NO: 565 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505185, 'Afton', 'Erat', 'C2', 'N10715', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO715@gmail.com', 4036669689, 10688, 20687
);

/* INSERT QUERY NO: 566 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505186, 'Burke', 'Redier', 'C2', 'N10716', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO716@gmail.com', 4036669690, 10689, 20688
);

/* INSERT QUERY NO: 567 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505187, 'Jeannine', 'Stockney', 'C2', 'N10717', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO717@gmail.com', 4036669691, 10690, 20689
);

/* INSERT QUERY NO: 568 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505188, 'Nyssa', 'Dulwitch', 'C2', 'N10718', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO718@gmail.com', 4036669692, 10691, 20690
);

/* INSERT QUERY NO: 569 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505189, 'Glenn', 'Gooderson', 'C2', 'N10719', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO719@gmail.com', 4036669693, 10692, 20691
);

/* INSERT QUERY NO: 570 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505190, 'Niven', 'Pottell', 'C2', 'N10720', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO720@gmail.com', 4036669694, 10693, 20692
);

/* INSERT QUERY NO: 571 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505191, 'Ario', 'Aldine', 'C2', 'N10721', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO721@gmail.com', 4036669695, 10694, 20693
);

/* INSERT QUERY NO: 572 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505192, 'Mack', 'Baxter', 'C2', 'N10722', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO722@gmail.com', 4036669696, 10695, 20694
);

/* INSERT QUERY NO: 573 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505193, 'Uri', 'Giraudoux', 'C2', 'N10723', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO723@gmail.com', 4036669697, 10696, 20695
);

/* INSERT QUERY NO: 574 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505194, 'Evangeline', 'Sabatier', 'C2', 'N10724', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO724@gmail.com', 4036669698, 10697, 20696
);

/* INSERT QUERY NO: 575 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505195, 'Leroy', 'Laurenceau', 'C2', 'N10725', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO725@gmail.com', 4036669699, 10698, 20697
);

/* INSERT QUERY NO: 576 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505196, 'Angelina', 'Becaris', 'C2', 'N10726', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO726@gmail.com', 4036669700, 10699, 20698
);

/* INSERT QUERY NO: 577 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505197, 'Cirstoforo', 'Charlson', 'C2', 'N10727', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO727@gmail.com', 4036669701, 10700, 20699
);

/* INSERT QUERY NO: 578 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505198, 'Sterne', 'Chidler', 'C2', 'N10728', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO728@gmail.com', 4036669702, 10701, 20700
);

/* INSERT QUERY NO: 579 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505199, 'Jada', 'Hemstead', 'C2', 'N10729', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO729@gmail.com', 4036669703, 10702, 20701
);

/* INSERT QUERY NO: 580 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505200, 'Elsi', 'Sieb', 'C2', 'N10730', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO730@gmail.com', 4036669704, 10703, 20702
);

/* INSERT QUERY NO: 581 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505201, 'Kiele', 'Arsnell', 'C2', 'N10731', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO731@gmail.com', 4036669705, 10704, 20703
);

/* INSERT QUERY NO: 582 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505202, 'Una', 'Saterweyte', 'C2', 'N10732', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO732@gmail.com', 4036669706, 10705, 20704
);

/* INSERT QUERY NO: 583 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505203, 'Ivette', 'Forman', 'C2', 'N10733', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO733@gmail.com', 4036669707, 10706, 20705
);

/* INSERT QUERY NO: 584 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505204, 'Hilliary', 'Hughs', 'C2', 'N10734', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO734@gmail.com', 4036669708, 10707, 20706
);

/* INSERT QUERY NO: 585 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505205, 'Sayre', 'Becke', 'C2', 'N10735', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO735@gmail.com', 4036669709, 10708, 20707
);

/* INSERT QUERY NO: 586 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505206, 'Dredi', 'Widdowfield', 'C2', 'N10736', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO736@gmail.com', 4036669710, 10709, 20708
);

/* INSERT QUERY NO: 587 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505207, 'Dasya', 'Girodin', 'C2', 'N10737', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO737@gmail.com', 4036669711, 10710, 20709
);

/* INSERT QUERY NO: 588 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505208, 'Malachi', 'Graffham', 'C2', 'N10738', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO738@gmail.com', 4036669712, 10711, 20710
);

/* INSERT QUERY NO: 589 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505209, 'Blanca', 'Geekie', 'C2', 'N10739', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO739@gmail.com', 4036669713, 10712, 20711
);

/* INSERT QUERY NO: 590 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505210, 'Rosalia', 'Creese', 'C2', 'N10740', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO740@gmail.com', 4036669714, 10713, 20712
);

/* INSERT QUERY NO: 591 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505211, 'Tammy', 'Epinay', 'C2', 'N10741', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO741@gmail.com', 4036669715, 10714, 20713
);

/* INSERT QUERY NO: 592 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505212, 'Robinetta', 'Topper', 'C2', 'N10742', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO742@gmail.com', 4036669716, 10715, 20714
);

/* INSERT QUERY NO: 593 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505213, 'Mayne', 'Ianilli', 'C2', 'N10743', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO743@gmail.com', 4036669717, 10716, 20715
);

/* INSERT QUERY NO: 594 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505214, 'Elwira', 'Carous', 'C2', 'N10744', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO744@gmail.com', 4036669718, 10717, 20716
);

/* INSERT QUERY NO: 595 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505215, 'Alecia', 'Dreamer', 'C2', 'N10745', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO745@gmail.com', 4036669719, 10718, 20717
);

/* INSERT QUERY NO: 596 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505216, 'Codie', 'Lockart', 'C2', 'N10746', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO746@gmail.com', 4036669720, 10719, 20718
);

/* INSERT QUERY NO: 597 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505217, 'Leisha', 'January 1st', 'C2', 'N10747', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO747@gmail.com', 4036669721, 10720, 20719
);

/* INSERT QUERY NO: 598 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505218, 'Lemmy', 'Champain', 'C2', 'N10748', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO748@gmail.com', 4036669722, 10721, 20720
);

/* INSERT QUERY NO: 599 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505219, 'Garner', 'Shapcote', 'C2', 'N10749', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO749@gmail.com', 4036669723, 10722, 20721
);

/* INSERT QUERY NO: 600 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505220, 'Feliza', 'Skelhorne', 'C2', 'N10750', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO750@gmail.com', 4036669724, 10723, 20722
);

/* INSERT QUERY NO: 601 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505221, 'Hattie', 'Daybell', 'C2', 'N10751', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO751@gmail.com', 4036669725, 10724, 20723
);

/* INSERT QUERY NO: 602 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505222, 'Gracia', 'Tinwell', 'C2', 'N10752', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO752@gmail.com', 4036669726, 10725, 20724
);

/* INSERT QUERY NO: 603 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505223, 'Berni', 'Gerdts', 'C2', 'N10753', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO753@gmail.com', 4036669727, 10726, 20725
);

/* INSERT QUERY NO: 604 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505224, 'Lorant', 'Eichmann', 'C2', 'N10754', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO754@gmail.com', 4036669728, 10727, 20726
);

/* INSERT QUERY NO: 605 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505225, 'Katya', 'Cissen', 'C2', 'N10755', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO755@gmail.com', 4036669729, 10728, 20727
);

/* INSERT QUERY NO: 606 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505226, 'Ryun', 'Kellett', 'C2', 'N10756', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO756@gmail.com', 4036669730, 10729, 20728
);

/* INSERT QUERY NO: 607 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505227, 'Tamar', 'Cork', 'C2', 'N10757', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO757@gmail.com', 4036669731, 10730, 20729
);

/* INSERT QUERY NO: 608 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505228, 'Winona', 'Gregersen', 'C2', 'N10758', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO758@gmail.com', 4036669732, 10731, 20730
);

/* INSERT QUERY NO: 609 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505229, 'Georgeanna', 'Simenon', 'C2', 'N10759', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO759@gmail.com', 4036669733, 10732, 20731
);

/* INSERT QUERY NO: 610 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505230, 'Mamie', 'Danjoie', 'C2', 'N10760', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO760@gmail.com', 4036669734, 10733, 20732
);

/* INSERT QUERY NO: 611 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505231, 'Harriott', 'Starton', 'C2', 'N10761', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO761@gmail.com', 4036669735, 10734, 20733
);

/* INSERT QUERY NO: 612 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505232, 'Tybalt', 'Bousquet', 'C2', 'N10762', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO762@gmail.com', 4036669736, 10735, 20734
);

/* INSERT QUERY NO: 613 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505233, 'Loydie', 'Arthurs', 'C2', 'N10763', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO763@gmail.com', 4036669737, 10736, 20735
);

/* INSERT QUERY NO: 614 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505234, 'Lukas', 'Causon', 'C2', 'N10764', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO764@gmail.com', 4036669738, 10737, 20736
);

/* INSERT QUERY NO: 615 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505235, 'Teodoro', 'Denyer', 'C2', 'N10765', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO765@gmail.com', 4036669739, 10738, 20737
);

/* INSERT QUERY NO: 616 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505236, 'Nobie', 'Denton', 'C2', 'N10766', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO766@gmail.com', 4036669740, 10739, 20738
);

/* INSERT QUERY NO: 617 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505237, 'Rickert', 'McCrow', 'C2', 'N10767', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO767@gmail.com', 4036669741, 10740, 20739
);

/* INSERT QUERY NO: 618 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505238, 'Claudio', 'Routh', 'C2', 'N10768', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO768@gmail.com', 4036669742, 10741, 20740
);

/* INSERT QUERY NO: 619 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505239, 'Bat', 'Didball', 'C2', 'N10769', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO769@gmail.com', 4036669743, 10742, 20741
);

/* INSERT QUERY NO: 620 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505240, 'Patin', 'Elvin', 'C2', 'N10770', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO770@gmail.com', 4036669744, 10743, 20742
);

/* INSERT QUERY NO: 621 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505241, 'Hernando', 'Westney', 'C2', 'N10771', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO771@gmail.com', 4036669745, 10744, 20743
);

/* INSERT QUERY NO: 622 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505242, 'Karmen', 'Laver', 'C2', 'N10772', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO772@gmail.com', 4036669746, 10745, 20744
);

/* INSERT QUERY NO: 623 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505243, 'Moshe', 'Pallant', 'C2', 'N10773', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO773@gmail.com', 4036669747, 10746, 20745
);

/* INSERT QUERY NO: 624 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505244, 'Alice', 'Lenaghen', 'C2', 'N10774', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO774@gmail.com', 4036669748, 10747, 20746
);

/* INSERT QUERY NO: 625 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505245, 'Cybill', 'Somerton', 'C2', 'N10775', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO775@gmail.com', 4036669749, 10748, 20747
);

/* INSERT QUERY NO: 626 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505246, 'Sherman', 'Normington', 'C2', 'N10776', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO776@gmail.com', 4036669750, 10749, 20748
);

/* INSERT QUERY NO: 627 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505247, 'Frayda', 'Prescote', 'C2', 'N10777', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO777@gmail.com', 4036669751, 10750, 20749
);

/* INSERT QUERY NO: 628 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505248, 'Karyl', 'Wakenshaw', 'C2', 'N10778', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO778@gmail.com', 4036669752, 10751, 20750
);

/* INSERT QUERY NO: 629 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505249, 'Winonah', 'Conner', 'C2', 'N10779', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO779@gmail.com', 4036669753, 10752, 20751
);

/* INSERT QUERY NO: 630 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505250, 'Othilie', 'Forsyth', 'C2', 'N10780', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO780@gmail.com', 4036669754, 10753, 20752
);

/* INSERT QUERY NO: 631 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505251, 'Cecilla', 'Pattinson', 'C2', 'N10781', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO781@gmail.com', 4036669755, 10754, 20753
);

/* INSERT QUERY NO: 632 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505252, 'Rudyard', 'Letixier', 'C2', 'N10782', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO782@gmail.com', 4036669756, 10755, 20754
);

/* INSERT QUERY NO: 633 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505253, 'Etty', 'Balhatchet', 'C2', 'N10783', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO783@gmail.com', 4036669757, 10756, 20755
);

/* INSERT QUERY NO: 634 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505254, 'Tyson', 'Castles', 'C2', 'N10784', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO784@gmail.com', 4036669758, 10757, 20756
);

/* INSERT QUERY NO: 635 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505255, 'Ella', 'Cressor', 'C2', 'N10785', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO785@gmail.com', 4036669759, 10758, 20757
);

/* INSERT QUERY NO: 636 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505256, 'Cyndy', 'Froom', 'C2', 'N10786', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO786@gmail.com', 4036669760, 10759, 20758
);

/* INSERT QUERY NO: 637 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505257, 'Gui', 'Maasz', 'C2', 'N10787', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO787@gmail.com', 4036669761, 10760, 20759
);

/* INSERT QUERY NO: 638 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505258, 'Vasily', 'Landsborough', 'C2', 'N10788', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO788@gmail.com', 4036669762, 10761, 20760
);

/* INSERT QUERY NO: 639 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505259, 'Christine', 'Evett', 'C2', 'N10789', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO789@gmail.com', 4036669763, 10762, 20761
);

/* INSERT QUERY NO: 640 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505260, 'May', 'Paviour', 'C2', 'N10790', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO790@gmail.com', 4036669764, 10763, 20762
);

/* INSERT QUERY NO: 641 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505261, 'Dall', 'Gerhartz', 'C2', 'N10791', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO791@gmail.com', 4036669765, 10764, 20763
);

/* INSERT QUERY NO: 642 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505262, 'Doris', 'Conway', 'C2', 'N10792', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO792@gmail.com', 4036669766, 10765, 20764
);

/* INSERT QUERY NO: 643 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505263, 'Tamma', 'Mathe', 'C2', 'N10793', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO793@gmail.com', 4036669767, 10766, 20765
);

/* INSERT QUERY NO: 644 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505264, 'Jacquie', 'Stranger', 'C2', 'N10794', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO794@gmail.com', 4036669768, 10767, 20766
);

/* INSERT QUERY NO: 645 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505265, 'Olivette', 'Cumpton', 'C2', 'N10795', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO795@gmail.com', 4036669769, 10768, 20767
);

/* INSERT QUERY NO: 646 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505266, 'Leigh', 'Joynson', 'C2', 'N10796', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO796@gmail.com', 4036669770, 10769, 20768
);

/* INSERT QUERY NO: 647 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505267, 'Vernor', 'Barosch', 'C2', 'N10797', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO797@gmail.com', 4036669771, 10770, 20769
);

/* INSERT QUERY NO: 648 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505268, 'Jinny', 'Crispin', 'C2', 'N10798', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO798@gmail.com', 4036669772, 10771, 20770
);

/* INSERT QUERY NO: 649 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505269, 'Reeta', 'Brill', 'C2', 'N10799', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO799@gmail.com', 4036669773, 10772, 20771
);

/* INSERT QUERY NO: 650 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505270, 'Abbie', 'Penella', 'C2', 'N10800', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO800@gmail.com', 4036669774, 10773, 20772
);

/* INSERT QUERY NO: 651 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505271, 'Heloise', 'Behnen', 'C2', 'N10801', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO801@gmail.com', 4036669775, 10774, 20773
);

/* INSERT QUERY NO: 652 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505272, 'Leeann', 'Oertzen', 'C2', 'N10802', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO802@gmail.com', 4036669776, 10775, 20774
);

/* INSERT QUERY NO: 653 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505273, 'Ann', 'Tremellan', 'C2', 'N10803', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO803@gmail.com', 4036669777, 10776, 20775
);

/* INSERT QUERY NO: 654 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505274, 'Vito', 'Sturdy', 'C2', 'N10804', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO804@gmail.com', 4036669778, 10777, 20776
);

/* INSERT QUERY NO: 655 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505275, 'Aigneis', 'Mossbee', 'C2', 'N10805', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO805@gmail.com', 4036669779, 10778, 20777
);

/* INSERT QUERY NO: 656 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505276, 'Sacha', 'Raynton', 'C2', 'N10806', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO806@gmail.com', 4036669780, 10779, 20778
);

/* INSERT QUERY NO: 657 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505277, 'Lindi', 'Brideau', 'C2', 'N10807', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO807@gmail.com', 4036669781, 10780, 20779
);

/* INSERT QUERY NO: 658 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505278, 'Leeanne', 'Trappe', 'C2', 'N10808', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO808@gmail.com', 4036669782, 10781, 20780
);

/* INSERT QUERY NO: 659 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505279, 'Patton', 'Jime', 'C2', 'N10809', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO809@gmail.com', 4036669783, 10782, 20781
);

/* INSERT QUERY NO: 660 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505280, 'Vernon', 'Loweth', 'C2', 'N10810', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO810@gmail.com', 4036669784, 10783, 20782
);

/* INSERT QUERY NO: 661 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505281, 'Lisetta', 'Dorran', 'C2', 'N10811', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO811@gmail.com', 4036669785, 10784, 20783
);

/* INSERT QUERY NO: 662 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505282, 'Clyde', 'Rasher', 'C2', 'N10812', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO812@gmail.com', 4036669786, 10785, 20784
);

/* INSERT QUERY NO: 663 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505283, 'Malina', 'Pau', 'C2', 'N10813', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO813@gmail.com', 4036669787, 10786, 20785
);

/* INSERT QUERY NO: 664 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505284, 'Marie-ann', 'Frediani', 'C2', 'N10814', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO814@gmail.com', 4036669788, 10787, 20786
);

/* INSERT QUERY NO: 665 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505285, 'Stefanie', 'Moppett', 'C2', 'N10815', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO815@gmail.com', 4036669789, 10788, 20787
);

/* INSERT QUERY NO: 666 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505286, 'Tabby', 'Nuzzi', 'C2', 'N10816', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO816@gmail.com', 4036669790, 10789, 20788
);

/* INSERT QUERY NO: 667 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505287, 'Rose', 'Milesop', 'C2', 'N10817', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO817@gmail.com', 4036669791, 10790, 20789
);

/* INSERT QUERY NO: 668 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505288, 'Gwenni', 'Moncrieffe', 'C2', 'N10818', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO818@gmail.com', 4036669792, 10791, 20790
);

/* INSERT QUERY NO: 669 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505289, 'Kippie', 'Newbigging', 'C2', 'N10819', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO819@gmail.com', 4036669793, 10792, 20791
);

/* INSERT QUERY NO: 670 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505290, 'Viviene', 'Cheyenne', 'C2', 'N10820', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO820@gmail.com', 4036669794, 10793, 20792
);

/* INSERT QUERY NO: 671 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505291, 'Madalena', 'Lovitt', 'C2', 'N10821', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO821@gmail.com', 4036669795, 10794, 20793
);

/* INSERT QUERY NO: 672 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505292, 'Joseito', 'Downing', 'C2', 'N10822', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO822@gmail.com', 4036669796, 10795, 20794
);

/* INSERT QUERY NO: 673 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505293, 'Immanuel', 'Worssam', 'C2', 'N10823', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO823@gmail.com', 4036669797, 10796, 20795
);

/* INSERT QUERY NO: 674 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505294, 'Aldrich', 'Baythrop', 'C2', 'N10824', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO824@gmail.com', 4036669798, 10797, 20796
);

/* INSERT QUERY NO: 675 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505295, 'Trent', 'Arling', 'C2', 'N10825', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO825@gmail.com', 4036669799, 10798, 20797
);

/* INSERT QUERY NO: 676 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505296, 'Erma', 'Kermon', 'C2', 'N10826', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO826@gmail.com', 4036669800, 10799, 20798
);

/* INSERT QUERY NO: 677 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505297, 'Elmo', 'Braznell', 'C2', 'N10827', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO827@gmail.com', 4036669801, 10800, 20799
);

/* INSERT QUERY NO: 678 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505298, 'Kendrick', 'Radford', 'C2', 'N10828', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO828@gmail.com', 4036669802, 10801, 20800
);

/* INSERT QUERY NO: 679 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505299, 'Ella', 'Mountfort', 'C2', 'N10829', 'O-', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO829@gmail.com', 4036669803, 10802, 20801
);

/* INSERT QUERY NO: 680 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505300, 'Karin', 'Tather', 'C2', 'N10830', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'MEDELLIN', 'CORREO830@gmail.com', 4036669804, 10803, 20802
);

/* INSERT QUERY NO: 681 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505301, 'Aldric', 'Scade', 'C2', 'N10831', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO831@gmail.com', 4036669805, 10804, 20803
);

/* INSERT QUERY NO: 682 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505302, 'Lilian', 'Ramelot', 'C2', 'N10832', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO832@gmail.com', 4036669806, 10805, 20804
);

/* INSERT QUERY NO: 683 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505303, 'Olly', 'Deyenhardt', 'C2', 'N10833', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO833@gmail.com', 4036669807, 10806, 20805
);

/* INSERT QUERY NO: 684 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505304, 'Dorolice', 'Delafoy', 'C2', 'N10834', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO834@gmail.com', 4036669808, 10807, 20806
);

/* INSERT QUERY NO: 685 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505305, 'Amara', 'Mallison', 'C2', 'N10835', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO835@gmail.com', 4036669809, 10808, 20807
);

/* INSERT QUERY NO: 686 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505306, 'Berkley', 'Dubois', 'C2', 'N10836', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO836@gmail.com', 4036669810, 10809, 20808
);

/* INSERT QUERY NO: 687 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505307, 'Karlens', 'Marston', 'C2', 'N10837', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO837@gmail.com', 4036669811, 10810, 20809
);

/* INSERT QUERY NO: 688 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505308, 'Roanne', 'Heugh', 'C2', 'N10838', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO838@gmail.com', 4036669812, 10811, 20810
);

/* INSERT QUERY NO: 689 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505309, 'Christa', 'Pigney', 'C2', 'N10839', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO839@gmail.com', 4036669813, 10812, 20811
);

/* INSERT QUERY NO: 690 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505310, 'Allison', 'Benedetti', 'C2', 'N10840', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO840@gmail.com', 4036669814, 10813, 20812
);

/* INSERT QUERY NO: 691 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505311, 'Hugues', 'Pascall', 'C2', 'N10841', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO841@gmail.com', 4036669815, 10814, 20813
);

/* INSERT QUERY NO: 692 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505312, 'Wylie', 'Daffey', 'C2', 'N10842', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO842@gmail.com', 4036669816, 10815, 20814
);

/* INSERT QUERY NO: 693 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505313, 'Jeramie', 'Blabber', 'C2', 'N10843', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO843@gmail.com', 4036669817, 10816, 20815
);

/* INSERT QUERY NO: 694 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505314, 'Carma', 'Elliker', 'C2', 'N10844', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO844@gmail.com', 4036669818, 10817, 20816
);

/* INSERT QUERY NO: 695 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505315, 'Amabelle', 'Dreelan', 'C2', 'N10845', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO845@gmail.com', 4036669819, 10818, 20817
);

/* INSERT QUERY NO: 696 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505316, 'Irina', 'Driscoll', 'C2', 'N10846', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO846@gmail.com', 4036669820, 10819, 20818
);

/* INSERT QUERY NO: 697 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505317, 'Desi', 'Aiers', 'C2', 'N10847', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO847@gmail.com', 4036669821, 10820, 20819
);

/* INSERT QUERY NO: 698 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505318, 'Imojean', 'Bird', 'C2', 'N10848', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO848@gmail.com', 4036669822, 10821, 20820
);

/* INSERT QUERY NO: 699 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505319, 'Fedora', 'Newlands', 'C2', 'N10849', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO849@gmail.com', 4036669823, 10822, 20821
);

/* INSERT QUERY NO: 700 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505320, 'Melli', 'Stallon', 'C2', 'N10850', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO850@gmail.com', 4036669824, 10823, 20822
);

/* INSERT QUERY NO: 701 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505321, 'Billie', 'Schirak', 'C2', 'N10851', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO851@gmail.com', 4036669825, 10824, 20823
);

/* INSERT QUERY NO: 702 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505322, 'Maridel', 'Le Noire', 'C2', 'N10852', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO852@gmail.com', 4036669826, 10825, 20824
);

/* INSERT QUERY NO: 703 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505323, 'Aurlie', 'Daoust', 'C2', 'N10853', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO853@gmail.com', 4036669827, 10826, 20825
);

/* INSERT QUERY NO: 704 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505324, 'Cece', 'Pavinese', 'C2', 'N10854', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO854@gmail.com', 4036669828, 10827, 20826
);

/* INSERT QUERY NO: 705 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505325, 'Catlin', 'Cromer', 'C2', 'N10855', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO855@gmail.com', 4036669829, 10828, 20827
);

/* INSERT QUERY NO: 706 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505326, 'Gizela', 'Iori', 'C2', 'N10856', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO856@gmail.com', 4036669830, 10829, 20828
);

/* INSERT QUERY NO: 707 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505327, 'Stephannie', 'Michel', 'C2', 'N10857', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO857@gmail.com', 4036669831, 10830, 20829
);

/* INSERT QUERY NO: 708 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505328, 'Blithe', 'Phil', 'C2', 'N10858', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO858@gmail.com', 4036669832, 10831, 20830
);

/* INSERT QUERY NO: 709 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505329, 'Ianthe', 'Riggulsford', 'C2', 'N10859', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO859@gmail.com', 4036669833, 10832, 20831
);

/* INSERT QUERY NO: 710 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505330, 'Evin', 'Nibley', 'C2', 'N10860', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO860@gmail.com', 4036669834, 10833, 20832
);

/* INSERT QUERY NO: 711 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505331, 'Ulberto', 'Tull', 'C2', 'N10861', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO861@gmail.com', 4036669835, 10834, 20833
);

/* INSERT QUERY NO: 712 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505332, 'Rip', 'Tomkinson', 'C2', 'N10862', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO862@gmail.com', 4036669836, 10835, 20834
);

/* INSERT QUERY NO: 713 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505333, 'Darrin', 'Ridel', 'C2', 'N10863', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO863@gmail.com', 4036669837, 10836, 20835
);

/* INSERT QUERY NO: 714 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505334, 'Vevay', 'Vlasin', 'C2', 'N10864', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO864@gmail.com', 4036669838, 10837, 20836
);

/* INSERT QUERY NO: 715 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505335, 'Abba', 'Calyton', 'C2', 'N10865', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO865@gmail.com', 4036669839, 10838, 20837
);

/* INSERT QUERY NO: 716 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505336, 'Sullivan', 'Gue', 'C2', 'N10866', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO866@gmail.com', 4036669840, 10839, 20838
);

/* INSERT QUERY NO: 717 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505337, 'Cesya', 'Marmon', 'C2', 'N10867', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO867@gmail.com', 4036669841, 10840, 20839
);

/* INSERT QUERY NO: 718 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505338, 'Allyn', 'Sirr', 'C2', 'N10868', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO868@gmail.com', 4036669842, 10841, 20840
);

/* INSERT QUERY NO: 719 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505339, 'Carmel', 'Metschke', 'C2', 'N10869', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO869@gmail.com', 4036669843, 10842, 20841
);

/* INSERT QUERY NO: 720 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505340, 'Ally', 'Hauxwell', 'C2', 'N10870', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO870@gmail.com', 4036669844, 10843, 20842
);

/* INSERT QUERY NO: 721 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505341, 'Dew', 'Ledes', 'C2', 'N10871', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO871@gmail.com', 4036669845, 10844, 20843
);

/* INSERT QUERY NO: 722 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505342, 'Tiffani', 'Moro', 'C2', 'N10872', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO872@gmail.com', 4036669846, 10845, 20844
);

/* INSERT QUERY NO: 723 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505343, 'Adah', 'Dollard', 'C2', 'N10873', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO873@gmail.com', 4036669847, 10846, 20845
);

/* INSERT QUERY NO: 724 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505344, 'Emanuel', 'Drepp', 'C2', 'N10874', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO874@gmail.com', 4036669848, 10847, 20846
);

/* INSERT QUERY NO: 725 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505345, 'Sallyann', 'Guynemer', 'C2', 'N10875', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO875@gmail.com', 4036669849, 10848, 20847
);

/* INSERT QUERY NO: 726 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505346, 'Marcelline', 'Yukhin', 'C2', 'N10876', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO876@gmail.com', 4036669850, 10849, 20848
);

/* INSERT QUERY NO: 727 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505347, 'Martie', 'Andrejs', 'C2', 'N10877', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO877@gmail.com', 4036669851, 10850, 20849
);

/* INSERT QUERY NO: 728 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505348, 'Farrand', 'Adamthwaite', 'C2', 'N10878', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO878@gmail.com', 4036669852, 10851, 20850
);

/* INSERT QUERY NO: 729 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505349, 'Juliette', 'Harome', 'C2', 'N10879', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO879@gmail.com', 4036669853, 10852, 20851
);

/* INSERT QUERY NO: 730 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505350, 'Lucia', 'Gorbell', 'C2', 'N10880', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO880@gmail.com', 4036669854, 10853, 20852
);

/* INSERT QUERY NO: 731 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505351, 'Sarene', 'Plose', 'C2', 'N10881', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO881@gmail.com', 4036669855, 10854, 20853
);

/* INSERT QUERY NO: 732 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505352, 'Eric', 'Oleszczak', 'C2', 'N10882', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO882@gmail.com', 4036669856, 10855, 20854
);

/* INSERT QUERY NO: 733 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505353, 'Fleur', 'Salan', 'C2', 'N10883', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO883@gmail.com', 4036669857, 10856, 20855
);

/* INSERT QUERY NO: 734 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505354, 'Antony', 'Itshak', 'C2', 'N10884', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO884@gmail.com', 4036669858, 10857, 20856
);

/* INSERT QUERY NO: 735 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505355, 'Lou', 'Mussolini', 'C2', 'N10885', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO885@gmail.com', 4036669859, 10858, 20857
);

/* INSERT QUERY NO: 736 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505356, 'Rochell', 'Spare', 'C2', 'N10886', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO886@gmail.com', 4036669860, 10859, 20858
);

/* INSERT QUERY NO: 737 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505357, 'Cecilius', 'Labell', 'C2', 'N10887', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO887@gmail.com', 4036669861, 10860, 20859
);

/* INSERT QUERY NO: 738 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505358, 'Lind', 'Seavers', 'C2', 'N10888', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO888@gmail.com', 4036669862, 10861, 20860
);

/* INSERT QUERY NO: 739 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505359, 'Marya', 'Floyd', 'C2', 'N10889', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO889@gmail.com', 4036669863, 10862, 20861
);

/* INSERT QUERY NO: 740 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505360, 'Asa', 'Matyugin', 'C2', 'N10890', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO890@gmail.com', 4036669864, 10863, 20862
);

/* INSERT QUERY NO: 741 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505361, 'Rinaldo', 'Crumpton', 'C2', 'N10891', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO891@gmail.com', 4036669865, 10864, 20863
);

/* INSERT QUERY NO: 742 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505362, 'Konstantin', 'Holborn', 'C2', 'N10892', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO892@gmail.com', 4036669866, 10865, 20864
);

/* INSERT QUERY NO: 743 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505363, 'Tarrance', 'Norquoy', 'C2', 'N10893', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO893@gmail.com', 4036669867, 10866, 20865
);

/* INSERT QUERY NO: 744 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505364, 'Gabbie', 'Cadany', 'C2', 'N10894', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO894@gmail.com', 4036669868, 10867, 20866
);

/* INSERT QUERY NO: 745 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505365, 'Horatio', 'Martinson', 'C2', 'N10895', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO895@gmail.com', 4036669869, 10868, 20867
);

/* INSERT QUERY NO: 746 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505366, 'Vinnie', 'Whittlesee', 'C2', 'N10896', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO896@gmail.com', 4036669870, 10869, 20868
);

/* INSERT QUERY NO: 747 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505367, 'Sophi', 'Bortoluzzi', 'C2', 'N10897', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO897@gmail.com', 4036669871, 10870, 20869
);

/* INSERT QUERY NO: 748 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505368, 'Dottie', 'Burgoyne', 'C2', 'N10898', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO898@gmail.com', 4036669872, 10871, 20870
);

/* INSERT QUERY NO: 749 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505369, 'Freemon', 'Penchen', 'C2', 'N10899', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO899@gmail.com', 4036669873, 10872, 20871
);

/* INSERT QUERY NO: 750 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505370, 'Pearline', 'Boult', 'C2', 'N10900', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO900@gmail.com', 4036669874, 10873, 20872
);

/* INSERT QUERY NO: 751 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505371, 'Callida', 'Mullinger', 'C2', 'N10901', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO901@gmail.com', 4036669875, 10874, 20873
);

/* INSERT QUERY NO: 752 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505372, 'Leandra', 'Preston', 'C2', 'N10902', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO902@gmail.com', 4036669876, 10875, 20874
);

/* INSERT QUERY NO: 753 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505373, 'Tami', 'Heake', 'C2', 'N10903', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO903@gmail.com', 4036669877, 10876, 20875
);

/* INSERT QUERY NO: 754 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505374, 'Mavra', 'Sothcott', 'C2', 'N10904', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO904@gmail.com', 4036669878, 10877, 20876
);

/* INSERT QUERY NO: 755 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505375, 'Sean', 'Dacca', 'C2', 'N10905', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO905@gmail.com', 4036669879, 10878, 20877
);

/* INSERT QUERY NO: 756 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505376, 'Sammy', 'Ancliffe', 'C2', 'N10906', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO906@gmail.com', 4036669880, 10879, 20878
);

/* INSERT QUERY NO: 757 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505377, 'Shina', 'Liptrod', 'C2', 'N10907', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO907@gmail.com', 4036669881, 10880, 20879
);

/* INSERT QUERY NO: 758 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505378, 'Olympie', 'Orris', 'C2', 'N10908', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO908@gmail.com', 4036669882, 10881, 20880
);

/* INSERT QUERY NO: 759 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505379, 'Ernestus', 'Chesswas', 'C2', 'N10909', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO909@gmail.com', 4036669883, 10882, 20881
);

/* INSERT QUERY NO: 760 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505380, 'Erek', 'Howship', 'C2', 'N10910', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO910@gmail.com', 4036669884, 10883, 20882
);

/* INSERT QUERY NO: 761 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505381, 'Decca', 'Affron', 'C2', 'N10911', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO911@gmail.com', 4036669885, 10884, 20883
);

/* INSERT QUERY NO: 762 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505382, 'Fidelia', 'Fahrenbacher', 'C2', 'N10912', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO912@gmail.com', 4036669886, 10885, 20884
);

/* INSERT QUERY NO: 763 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505383, 'Tedi', 'Senecaux', 'C2', 'N10913', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO913@gmail.com', 4036669887, 10886, 20885
);

/* INSERT QUERY NO: 764 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505384, 'Torey', 'Nealey', 'C2', 'N10914', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO914@gmail.com', 4036669888, 10887, 20886
);

/* INSERT QUERY NO: 765 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505385, 'Cassie', 'Paoletti', 'C2', 'N10915', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO915@gmail.com', 4036669889, 10888, 20887
);

/* INSERT QUERY NO: 766 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505386, 'Kamillah', 'Ballam', 'C2', 'N10916', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO916@gmail.com', 4036669890, 10889, 20888
);

/* INSERT QUERY NO: 767 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505387, 'Gerty', 'Sealy', 'C2', 'N10917', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO917@gmail.com', 4036669891, 10890, 20889
);

/* INSERT QUERY NO: 768 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505388, 'Melisent', 'Eccles', 'C2', 'N10918', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO918@gmail.com', 4036669892, 10891, 20890
);

/* INSERT QUERY NO: 769 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505389, 'Joya', 'Selley', 'C2', 'N10919', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO919@gmail.com', 4036669893, 10892, 20891
);

/* INSERT QUERY NO: 770 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505390, 'Bee', 'Fedynski', 'C2', 'N10920', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO920@gmail.com', 4036669894, 10893, 20892
);

/* INSERT QUERY NO: 771 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505391, 'Asia', 'Dumbare', 'C2', 'N10921', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO921@gmail.com', 4036669895, 10894, 20893
);

/* INSERT QUERY NO: 772 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505392, 'Bridgette', 'Addison', 'C2', 'N10922', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO922@gmail.com', 4036669896, 10895, 20894
);

/* INSERT QUERY NO: 773 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505393, 'Andra', 'Thorneloe', 'C2', 'N10923', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO923@gmail.com', 4036669897, 10896, 20895
);

/* INSERT QUERY NO: 774 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505394, 'Carmita', 'Gornar', 'C2', 'N10924', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO924@gmail.com', 4036669898, 10897, 20896
);

/* INSERT QUERY NO: 775 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505395, 'Jodie', 'Kaser', 'C2', 'N10925', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO925@gmail.com', 4036669899, 10898, 20897
);

/* INSERT QUERY NO: 776 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505396, 'Desiri', 'Pietruschka', 'C2', 'N10926', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO926@gmail.com', 4036669900, 10899, 20898
);

/* INSERT QUERY NO: 777 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505397, 'Petronilla', 'Pounder', 'C2', 'N10927', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO927@gmail.com', 4036669901, 10900, 20899
);

/* INSERT QUERY NO: 778 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505398, 'Harald', 'Pyburn', 'C2', 'N10928', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO928@gmail.com', 4036669902, 10901, 20900
);

/* INSERT QUERY NO: 779 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505399, 'Aguistin', 'Griswood', 'C2', 'N10929', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO929@gmail.com', 4036669903, 10902, 20901
);

/* INSERT QUERY NO: 780 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505400, 'Celestine', 'Fisbey', 'C2', 'N10930', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO930@gmail.com', 4036669904, 10903, 20902
);

/* INSERT QUERY NO: 781 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505401, 'Jeri', 'Seeler', 'C2', 'N10931', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO931@gmail.com', 4036669905, 10904, 20903
);

/* INSERT QUERY NO: 782 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505402, 'Alwyn', 'Moynham', 'C2', 'N10932', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO932@gmail.com', 4036669906, 10905, 20904
);

/* INSERT QUERY NO: 783 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505403, 'Bethina', 'Tregoning', 'C2', 'N10933', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO933@gmail.com', 4036669907, 10906, 20905
);

/* INSERT QUERY NO: 784 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505404, 'Maye', 'Monteath', 'C2', 'N10934', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO934@gmail.com', 4036669908, 10907, 20906
);

/* INSERT QUERY NO: 785 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505405, 'Terri', 'Dresser', 'C2', 'N10935', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO935@gmail.com', 4036669909, 10908, 20907
);

/* INSERT QUERY NO: 786 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505406, 'Ogdan', 'Roland', 'C2', 'N10936', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO936@gmail.com', 4036669910, 10909, 20908
);

/* INSERT QUERY NO: 787 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505407, 'Jeno', 'Whetnall', 'C2', 'N10937', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO937@gmail.com', 4036669911, 10910, 20909
);

/* INSERT QUERY NO: 788 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505408, 'Gare', 'Follos', 'C2', 'N10938', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO938@gmail.com', 4036669912, 10911, 20910
);

/* INSERT QUERY NO: 789 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505409, 'Kingston', 'Elliot', 'C2', 'N10939', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO939@gmail.com', 4036669913, 10912, 20911
);

/* INSERT QUERY NO: 790 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505410, 'Katalin', 'Haylands', 'C2', 'N10940', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO940@gmail.com', 4036669914, 10913, 20912
);

/* INSERT QUERY NO: 791 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505411, 'Sybille', 'Fredy', 'C2', 'N10941', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO941@gmail.com', 4036669915, 10914, 20913
);

/* INSERT QUERY NO: 792 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505412, 'Chanda', 'Dudek', 'C2', 'N10942', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO942@gmail.com', 4036669916, 10915, 20914
);

/* INSERT QUERY NO: 793 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505413, 'Fairlie', 'Kent', 'C2', 'N10943', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO943@gmail.com', 4036669917, 10916, 20915
);

/* INSERT QUERY NO: 794 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505414, 'Devina', 'Tivers', 'C2', 'N10944', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO944@gmail.com', 4036669918, 10917, 20916
);

/* INSERT QUERY NO: 795 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505415, 'Hermia', 'Hance', 'C2', 'N10945', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO945@gmail.com', 4036669919, 10918, 20917
);

/* INSERT QUERY NO: 796 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505416, 'Cesaro', 'Prangle', 'C2', 'N10946', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO946@gmail.com', 4036669920, 10919, 20918
);

/* INSERT QUERY NO: 797 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505417, 'Gregor', 'Files', 'C2', 'N10947', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO947@gmail.com', 4036669921, 10920, 20919
);

/* INSERT QUERY NO: 798 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505418, 'Sibella', 'Willden', 'C2', 'N10948', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO948@gmail.com', 4036669922, 10921, 20920
);

/* INSERT QUERY NO: 799 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505419, 'Drucie', 'Salzberger', 'C2', 'N10949', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO949@gmail.com', 4036669923, 10922, 20921
);

/* INSERT QUERY NO: 800 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505420, 'Bell', 'Elsley', 'C2', 'N10950', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO950@gmail.com', 4036669924, 10923, 20922
);

/* INSERT QUERY NO: 801 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505421, 'Etheline', 'Truse', 'C2', 'N10951', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO951@gmail.com', 4036669925, 10924, 20923
);

/* INSERT QUERY NO: 802 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505422, 'Cam', 'Arnowicz', 'C2', 'N10952', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO952@gmail.com', 4036669926, 10925, 20924
);

/* INSERT QUERY NO: 803 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505423, 'Pacorro', 'Pugsley', 'C2', 'N10953', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO953@gmail.com', 4036669927, 10926, 20925
);

/* INSERT QUERY NO: 804 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505424, 'Emilie', 'McIlhone', 'C2', 'N10954', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO954@gmail.com', 4036669928, 10927, 20926
);

/* INSERT QUERY NO: 805 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505425, 'Ardys', 'Turbefield', 'C2', 'N10955', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO955@gmail.com', 4036669929, 10928, 20927
);

/* INSERT QUERY NO: 806 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505426, 'Ricca', 'Purves', 'C2', 'N10956', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO956@gmail.com', 4036669930, 10929, 20928
);

/* INSERT QUERY NO: 807 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505427, 'Rodolph', 'Curthoys', 'C2', 'N10957', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO957@gmail.com', 4036669931, 10930, 20929
);

/* INSERT QUERY NO: 808 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505428, 'Edan', 'Ibarra', 'C2', 'N10958', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO958@gmail.com', 4036669932, 10931, 20930
);

/* INSERT QUERY NO: 809 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505429, 'Nealy', 'Zieme', 'C2', 'N10959', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO959@gmail.com', 4036669933, 10932, 20931
);

/* INSERT QUERY NO: 810 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505430, 'Leshia', 'Brisard', 'C2', 'N10960', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO960@gmail.com', 4036669934, 10933, 20932
);

/* INSERT QUERY NO: 811 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505431, 'Tildy', 'Blyth', 'C2', 'N10961', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO961@gmail.com', 4036669935, 10934, 20933
);

/* INSERT QUERY NO: 812 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505432, 'Leena', 'Hancill', 'C2', 'N10962', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO962@gmail.com', 4036669936, 10935, 20934
);

/* INSERT QUERY NO: 813 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505433, 'Fulvia', 'Bonnaire', 'C2', 'N10963', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO963@gmail.com', 4036669937, 10936, 20935
);

/* INSERT QUERY NO: 814 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505434, 'Nadya', 'Parfitt', 'C2', 'N10964', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO964@gmail.com', 4036669938, 10937, 20936
);

/* INSERT QUERY NO: 815 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505435, 'Kelley', 'Confort', 'C2', 'N10965', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO965@gmail.com', 4036669939, 10938, 20937
);

/* INSERT QUERY NO: 816 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505436, 'Kamilah', 'Dockwray', 'C2', 'N10966', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO966@gmail.com', 4036669940, 10939, 20938
);

/* INSERT QUERY NO: 817 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505437, 'Read', 'Simeoni', 'C2', 'N10967', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO967@gmail.com', 4036669941, 10940, 20939
);

/* INSERT QUERY NO: 818 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505438, 'Enos', 'Brokenshire', 'C2', 'N10968', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO968@gmail.com', 4036669942, 10941, 20940
);

/* INSERT QUERY NO: 819 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505439, 'Sylas', 'Carik', 'C2', 'N10969', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO969@gmail.com', 4036669943, 10942, 20941
);

/* INSERT QUERY NO: 820 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505440, 'Gina', 'Chaddock', 'C2', 'N10970', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO970@gmail.com', 4036669944, 10943, 20942
);

/* INSERT QUERY NO: 821 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505441, 'Pail', 'Gudge', 'C2', 'N10971', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO971@gmail.com', 4036669945, 10944, 20943
);

/* INSERT QUERY NO: 822 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505442, 'Pall', 'Coultas', 'C2', 'N10972', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO972@gmail.com', 4036669946, 10945, 20944
);

/* INSERT QUERY NO: 823 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505443, 'Bobbee', 'Piggens', 'C2', 'N10973', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO973@gmail.com', 4036669947, 10946, 20945
);

/* INSERT QUERY NO: 824 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505444, 'Blisse', 'Critoph', 'C2', 'N10974', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO974@gmail.com', 4036669948, 10947, 20946
);

/* INSERT QUERY NO: 825 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505445, 'Kaleb', 'DAmbrosio', 'C2', 'N10975', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO975@gmail.com', 4036669949, 10948, 20947
);

/* INSERT QUERY NO: 826 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505446, 'Laughton', 'Critch', 'C2', 'N10976', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO976@gmail.com', 4036669950, 10949, 20948
);

/* INSERT QUERY NO: 827 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505447, 'Ahmad', 'Aaronson', 'C2', 'N10977', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO977@gmail.com', 4036669951, 10950, 20949
);

/* INSERT QUERY NO: 828 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505448, 'Corbie', 'Vass', 'C2', 'N10978', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO978@gmail.com', 4036669952, 10951, 20950
);

/* INSERT QUERY NO: 829 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505449, 'Giraud', 'McKleod', 'C2', 'N10979', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO979@gmail.com', 4036669953, 10952, 20951
);

/* INSERT QUERY NO: 830 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505450, 'Francine', 'Shallow', 'C2', 'N10980', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO980@gmail.com', 4036669954, 10953, 20952
);

/* INSERT QUERY NO: 831 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505451, 'Whitby', 'Everson', 'C2', 'N10981', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO981@gmail.com', 4036669955, 10954, 20953
);

/* INSERT QUERY NO: 832 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505452, 'Sephira', 'Ellen', 'C2', 'N10982', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO982@gmail.com', 4036669956, 10955, 20954
);

/* INSERT QUERY NO: 833 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505453, 'Mort', 'Recke', 'C2', 'N10983', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO983@gmail.com', 4036669957, 10956, 20955
);

/* INSERT QUERY NO: 834 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505454, 'Gareth', 'Jeacocke', 'C2', 'N10984', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO984@gmail.com', 4036669958, 10957, 20956
);

/* INSERT QUERY NO: 835 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505455, 'Ram', 'Clarkin', 'C2', 'N10985', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO985@gmail.com', 4036669959, 10958, 20957
);

/* INSERT QUERY NO: 836 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505456, 'Roselin', 'Ricard', 'C2', 'N10986', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO986@gmail.com', 4036669960, 10959, 20958
);

/* INSERT QUERY NO: 837 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505457, 'Ken', 'Aspall', 'C2', 'N10987', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO987@gmail.com', 4036669961, 10960, 20959
);

/* INSERT QUERY NO: 838 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505458, 'Holly-anne', 'MacShirie', 'C2', 'N10988', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO988@gmail.com', 4036669962, 10961, 20960
);

/* INSERT QUERY NO: 839 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505459, 'Rene', 'Sellens', 'C2', 'N10989', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO989@gmail.com', 4036669963, 10962, 20961
);

/* INSERT QUERY NO: 840 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505460, 'Fransisco', 'Pavia', 'C2', 'N10990', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO990@gmail.com', 4036669964, 10963, 20962
);

/* INSERT QUERY NO: 841 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505461, 'Sammy', 'Syvret', 'C2', 'N10991', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO991@gmail.com', 4036669965, 10964, 20963
);

/* INSERT QUERY NO: 842 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505462, 'Sigismund', 'Alchin', 'C2', 'N10992', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO992@gmail.com', 4036669966, 10965, 20964
);

/* INSERT QUERY NO: 843 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505463, 'Garvy', 'Grigorian', 'C2', 'N10993', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO993@gmail.com', 4036669967, 10966, 20965
);

/* INSERT QUERY NO: 844 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505464, 'Adelaide', 'Gindghill', 'C2', 'N10994', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO994@gmail.com', 4036669968, 10967, 20966
);

/* INSERT QUERY NO: 845 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505465, 'Bette', 'Huntingford', 'C2', 'N10995', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO995@gmail.com', 4036669969, 10968, 20967
);

/* INSERT QUERY NO: 846 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505466, 'Mic', 'Edes', 'C2', 'N10996', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO996@gmail.com', 4036669970, 10969, 20968
);

/* INSERT QUERY NO: 847 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505467, 'Stanwood', 'Lovekin', 'C2', 'N10997', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO997@gmail.com', 4036669971, 10970, 20969
);

/* INSERT QUERY NO: 848 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505468, 'Ford', 'Tuohy', 'C2', 'N10998', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO998@gmail.com', 4036669972, 10971, 20970
);

/* INSERT QUERY NO: 849 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505469, 'Vyky', 'Werrit', 'C2', 'N10999', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO999@gmail.com', 4036669973, 10972, 20971
);

/* INSERT QUERY NO: 850 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505470, 'Culver', 'Swiffin', 'C2', 'N11000', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1000@gmail.com', 4036669974, 10973, 20972
);

/* INSERT QUERY NO: 851 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505471, 'Hynda', 'Vasenin', 'C2', 'N11001', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1001@gmail.com', 4036669975, 10974, 20973
);

/* INSERT QUERY NO: 852 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505472, 'Ky', 'Baccup', 'C2', 'N11002', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1002@gmail.com', 4036669976, 10975, 20974
);

/* INSERT QUERY NO: 853 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505473, 'Enos', 'Gritland', 'C2', 'N11003', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1003@gmail.com', 4036669977, 10976, 20975
);

/* INSERT QUERY NO: 854 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505474, 'Fredek', 'Maidlow', 'C2', 'N11004', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1004@gmail.com', 4036669978, 10977, 20976
);

/* INSERT QUERY NO: 855 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505475, 'Kev', 'Hannen', 'C2', 'N11005', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1005@gmail.com', 4036669979, 10978, 20977
);

/* INSERT QUERY NO: 856 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505476, 'Westbrook', 'Crosio', 'C2', 'N11006', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1006@gmail.com', 4036669980, 10979, 20978
);

/* INSERT QUERY NO: 857 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505477, 'Eudora', 'Winsborrow', 'C2', 'N11007', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1007@gmail.com', 4036669981, 10980, 20979
);

/* INSERT QUERY NO: 858 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505478, 'Nadiya', 'Gibbens', 'C2', 'N11008', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1008@gmail.com', 4036669982, 10981, 20980
);

/* INSERT QUERY NO: 859 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505479, 'Brade', 'Beamand', 'C2', 'N11009', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1009@gmail.com', 4036669983, 10982, 20981
);

/* INSERT QUERY NO: 860 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505480, 'Kristoffer', 'Parken', 'C2', 'N11010', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1010@gmail.com', 4036669984, 10983, 20982
);

/* INSERT QUERY NO: 861 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505481, 'Husain', 'Chaff', 'C2', 'N11011', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1011@gmail.com', 4036669985, 10984, 20983
);

/* INSERT QUERY NO: 862 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505482, 'Eugine', 'Stanfield', 'C2', 'N11012', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1012@gmail.com', 4036669986, 10985, 20984
);

/* INSERT QUERY NO: 863 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505483, 'Gearard', 'Fattori', 'C2', 'N11013', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1013@gmail.com', 4036669987, 10986, 20985
);

/* INSERT QUERY NO: 864 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505484, 'Merrill', 'Hexam', 'C2', 'N11014', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1014@gmail.com', 4036669988, 10987, 20986
);

/* INSERT QUERY NO: 865 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505485, 'Clara', 'Pinnick', 'C2', 'N11015', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1015@gmail.com', 4036669989, 10988, 20987
);

/* INSERT QUERY NO: 866 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505486, 'Godart', 'Flipsen', 'C2', 'N11016', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1016@gmail.com', 4036669990, 10989, 20988
);

/* INSERT QUERY NO: 867 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505487, 'Corny', 'Poulter', 'C2', 'N11017', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1017@gmail.com', 4036669991, 10990, 20989
);

/* INSERT QUERY NO: 868 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505488, 'Elvira', 'Allbones', 'C2', 'N11018', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1018@gmail.com', 4036669992, 10991, 20990
);

/* INSERT QUERY NO: 869 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505489, 'Robin', 'Banger', 'C2', 'N11019', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1019@gmail.com', 4036669993, 10992, 20991
);

/* INSERT QUERY NO: 870 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505490, 'Mufi', 'Edmund', 'C2', 'N11020', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1020@gmail.com', 4036669994, 10993, 20992
);

/* INSERT QUERY NO: 871 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505491, 'Nicki', 'Roswarne', 'C2', 'N11021', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1021@gmail.com', 4036669995, 10994, 20993
);

/* INSERT QUERY NO: 872 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505492, 'Ralph', 'Labb', 'C2', 'N11022', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1022@gmail.com', 4036669996, 10995, 20994
);

/* INSERT QUERY NO: 873 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505493, 'Jasun', 'Germain', 'C2', 'N11023', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1023@gmail.com', 4036669997, 10996, 20995
);

/* INSERT QUERY NO: 874 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505494, 'Tallulah', 'Iannitti', 'C2', 'N11024', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1024@gmail.com', 4036669998, 10997, 20996
);

/* INSERT QUERY NO: 875 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505495, 'Rogerio', 'Crippill', 'C2', 'N11025', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1025@gmail.com', 4036669999, 10998, 20997
);

/* INSERT QUERY NO: 876 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505496, 'Johannes', 'Pinckard', 'C2', 'N11026', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1026@gmail.com', 4036670000, 10999, 20998
);

/* INSERT QUERY NO: 877 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505497, 'Stephie', 'Beton', 'C2', 'N11027', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1027@gmail.com', 4036670001, 11000, 20999
);

/* INSERT QUERY NO: 878 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505498, 'Lee', 'Haburne', 'C2', 'N11028', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1028@gmail.com', 4036670002, 11001, 21000
);

/* INSERT QUERY NO: 879 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505499, 'Pavia', 'Asbrey', 'C2', 'N11029', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1029@gmail.com', 4036670003, 11002, 21001
);

/* INSERT QUERY NO: 880 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505500, 'Corilla', 'Tombling', 'C2', 'N11030', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1030@gmail.com', 4036670004, 11003, 21002
);

/* INSERT QUERY NO: 881 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505501, 'Charlot', 'McTague', 'C2', 'N11031', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1031@gmail.com', 4036670005, 11004, 21003
);

/* INSERT QUERY NO: 882 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505502, 'Kailey', 'Neely', 'C2', 'N11032', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1032@gmail.com', 4036670006, 11005, 21004
);

/* INSERT QUERY NO: 883 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505503, 'Von', 'Fordy', 'C2', 'N11033', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1033@gmail.com', 4036670007, 11006, 21005
);

/* INSERT QUERY NO: 884 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505504, 'Isadore', 'Parkes', 'C2', 'N11034', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1034@gmail.com', 4036670008, 11007, 21006
);

/* INSERT QUERY NO: 885 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505505, 'Flin', 'Jesse', 'C2', 'N11035', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1035@gmail.com', 4036670009, 11008, 21007
);

/* INSERT QUERY NO: 886 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505506, 'Karmen', 'Maleham', 'C2', 'N11036', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1036@gmail.com', 4036670010, 11009, 21008
);

/* INSERT QUERY NO: 887 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505507, 'Jimmy', 'Grishanov', 'C2', 'N11037', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1037@gmail.com', 4036670011, 11010, 21009
);

/* INSERT QUERY NO: 888 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505508, 'Barbara', 'Maggs', 'C2', 'N11038', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1038@gmail.com', 4036670012, 11011, 21010
);

/* INSERT QUERY NO: 889 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505509, 'Gui', 'Lazer', 'C2', 'N11039', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1039@gmail.com', 4036670013, 11012, 21011
);

/* INSERT QUERY NO: 890 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505510, 'Jamaal', 'Ackenhead', 'C2', 'N11040', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1040@gmail.com', 4036670014, 11013, 21012
);

/* INSERT QUERY NO: 891 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505511, 'Myriam', 'Bromwich', 'C2', 'N11041', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1041@gmail.com', 4036670015, 11014, 21013
);

/* INSERT QUERY NO: 892 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505512, 'Quinn', 'Steeden', 'C2', 'N11042', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1042@gmail.com', 4036670016, 11015, 21014
);

/* INSERT QUERY NO: 893 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505513, 'Raynell', 'Della Scala', 'C2', 'N11043', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1043@gmail.com', 4036670017, 11016, 21015
);

/* INSERT QUERY NO: 894 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505514, 'Sharia', 'Oxe', 'C2', 'N11044', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1044@gmail.com', 4036670018, 11017, 21016
);

/* INSERT QUERY NO: 895 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505515, 'Benoit', 'Wistance', 'C2', 'N11045', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1045@gmail.com', 4036670019, 11018, 21017
);

/* INSERT QUERY NO: 896 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505516, 'Karlis', 'Rosenfeld', 'C2', 'N11046', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1046@gmail.com', 4036670020, 11019, 21018
);

/* INSERT QUERY NO: 897 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505517, 'Coleman', 'Bemand', 'C2', 'N11047', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1047@gmail.com', 4036670021, 11020, 21019
);

/* INSERT QUERY NO: 898 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505518, 'Cosetta', 'Fries', 'C2', 'N11048', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1048@gmail.com', 4036670022, 11021, 21020
);

/* INSERT QUERY NO: 899 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505519, 'Omero', 'Robertot', 'C2', 'N11049', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1049@gmail.com', 4036670023, 11022, 21021
);

/* INSERT QUERY NO: 900 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505520, 'Brewster', 'Mutch', 'C2', 'N11050', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1050@gmail.com', 4036670024, 11023, 21022
);

/* INSERT QUERY NO: 901 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505521, 'Liza', 'McRamsey', 'C2', 'N11051', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1051@gmail.com', 4036670025, 11024, 21023
);

/* INSERT QUERY NO: 902 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505522, 'Jacquette', 'De Bernardis', 'C2', 'N11052', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1052@gmail.com', 4036670026, 11025, 21024
);

/* INSERT QUERY NO: 903 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505523, 'Tabby', 'Kinsett', 'C2', 'N11053', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1053@gmail.com', 4036670027, 11026, 21025
);

/* INSERT QUERY NO: 904 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505524, 'Haven', 'Jacobi', 'C2', 'N11054', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1054@gmail.com', 4036670028, 11027, 21026
);

/* INSERT QUERY NO: 905 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505525, 'Paul', 'Jacquot', 'C2', 'N11055', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1055@gmail.com', 4036670029, 11028, 21027
);

/* INSERT QUERY NO: 906 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505526, 'Carrie', 'Sidon', 'C2', 'N11056', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1056@gmail.com', 4036670030, 11029, 21028
);

/* INSERT QUERY NO: 907 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505527, 'Clemmie', 'Ovenell', 'C2', 'N11057', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1057@gmail.com', 4036670031, 11030, 21029
);

/* INSERT QUERY NO: 908 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505528, 'Meta', 'Tetsall', 'C2', 'N11058', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1058@gmail.com', 4036670032, 11031, 21030
);

/* INSERT QUERY NO: 909 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505529, 'Marve', 'Hendrik', 'C2', 'N11059', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1059@gmail.com', 4036670033, 11032, 21031
);

/* INSERT QUERY NO: 910 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505530, 'Taffy', 'Fawssett', 'C2', 'N11060', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1060@gmail.com', 4036670034, 11033, 21032
);

/* INSERT QUERY NO: 911 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505531, 'Haze', 'Buckler', 'C2', 'N11061', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1061@gmail.com', 4036670035, 11034, 21033
);

/* INSERT QUERY NO: 912 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505532, 'Bekki', 'Marsden', 'C2', 'N11062', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1062@gmail.com', 4036670036, 11035, 21034
);

/* INSERT QUERY NO: 913 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505533, 'Britt', 'Croyden', 'C2', 'N11063', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1063@gmail.com', 4036670037, 11036, 21035
);

/* INSERT QUERY NO: 914 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505534, 'Ethelin', 'Tandey', 'C2', 'N11064', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1064@gmail.com', 4036670038, 11037, 21036
);

/* INSERT QUERY NO: 915 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505535, 'Kristofer', 'Covely', 'C2', 'N11065', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1065@gmail.com', 4036670039, 11038, 21037
);

/* INSERT QUERY NO: 916 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505536, 'Christoph', 'Allston', 'C2', 'N11066', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1066@gmail.com', 4036670040, 11039, 21038
);

/* INSERT QUERY NO: 917 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505537, 'Rickey', 'Knudsen', 'C2', 'N11067', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1067@gmail.com', 4036670041, 11040, 21039
);

/* INSERT QUERY NO: 918 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505538, 'Lura', 'Gelsthorpe', 'C2', 'N11068', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1068@gmail.com', 4036670042, 11041, 21040
);

/* INSERT QUERY NO: 919 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505539, 'Bev', 'Juniper', 'C2', 'N11069', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1069@gmail.com', 4036670043, 11042, 21041
);

/* INSERT QUERY NO: 920 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505540, 'Delmore', 'Delgado', 'C2', 'N11070', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1070@gmail.com', 4036670044, 11043, 21042
);

/* INSERT QUERY NO: 921 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505541, 'Mellicent', 'Dinsell', 'C2', 'N11071', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1071@gmail.com', 4036670045, 11044, 21043
);

/* INSERT QUERY NO: 922 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505542, 'Bartlet', 'Pickerill', 'C2', 'N11072', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1072@gmail.com', 4036670046, 11045, 21044
);

/* INSERT QUERY NO: 923 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505543, 'Joete', 'Larkby', 'C2', 'N11073', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1073@gmail.com', 4036670047, 11046, 21045
);

/* INSERT QUERY NO: 924 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505544, 'Donnie', 'Ronald', 'C2', 'N11074', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1074@gmail.com', 4036670048, 11047, 21046
);

/* INSERT QUERY NO: 925 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505545, 'Jelene', 'Broadey', 'C2', 'N11075', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1075@gmail.com', 4036670049, 11048, 21047
);

/* INSERT QUERY NO: 926 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505546, 'Stafford', 'Le Gassick', 'C2', 'N11076', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1076@gmail.com', 4036670050, 11049, 21048
);

/* INSERT QUERY NO: 927 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505547, 'Dulci', 'McMenemy', 'C2', 'N11077', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1077@gmail.com', 4036670051, 11050, 21049
);

/* INSERT QUERY NO: 928 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505548, 'Manda', 'Lightowler', 'C2', 'N11078', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1078@gmail.com', 4036670052, 11051, 21050
);

/* INSERT QUERY NO: 929 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505549, 'Doloritas', 'Cargenven', 'C2', 'N11079', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1079@gmail.com', 4036670053, 11052, 21051
);

/* INSERT QUERY NO: 930 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505550, 'Yancy', 'Carolan', 'C2', 'N11080', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1080@gmail.com', 4036670054, 11053, 21052
);

/* INSERT QUERY NO: 931 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505551, 'Devlin', 'Spencelayh', 'C2', 'N11081', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1081@gmail.com', 4036670055, 11054, 21053
);

/* INSERT QUERY NO: 932 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505552, 'Rufus', 'Meriet', 'C2', 'N11082', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1082@gmail.com', 4036670056, 11055, 21054
);

/* INSERT QUERY NO: 933 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505553, 'Adler', 'Ferri', 'C2', 'N11083', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1083@gmail.com', 4036670057, 11056, 21055
);

/* INSERT QUERY NO: 934 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505554, 'Deerdre', 'Harrie', 'C2', 'N11084', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1084@gmail.com', 4036670058, 11057, 21056
);

/* INSERT QUERY NO: 935 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505555, 'Rivi', 'Ratt', 'C2', 'N11085', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1085@gmail.com', 4036670059, 11058, 21057
);

/* INSERT QUERY NO: 936 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505556, 'Dayna', 'Guiden', 'C2', 'N11086', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1086@gmail.com', 4036670060, 11059, 21058
);

/* INSERT QUERY NO: 937 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505557, 'Carlin', 'Dunsford', 'C2', 'N11087', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1087@gmail.com', 4036670061, 11060, 21059
);

/* INSERT QUERY NO: 938 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505558, 'Cynthea', 'Foxton', 'C2', 'N11088', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1088@gmail.com', 4036670062, 11061, 21060
);

/* INSERT QUERY NO: 939 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505559, 'Liza', 'Billingham', 'C2', 'N11089', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1089@gmail.com', 4036670063, 11062, 21061
);

/* INSERT QUERY NO: 940 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505560, 'Cyndie', 'Ashburner', 'C2', 'N11090', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1090@gmail.com', 4036670064, 11063, 21062
);

/* INSERT QUERY NO: 941 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505561, 'Bess', 'Galbreath', 'C2', 'N11091', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1091@gmail.com', 4036670065, 11064, 21063
);

/* INSERT QUERY NO: 942 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505562, 'Risa', 'Ruppertz', 'C2', 'N11092', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1092@gmail.com', 4036670066, 11065, 21064
);

/* INSERT QUERY NO: 943 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505563, 'Torrey', 'Jahncke', 'C2', 'N11093', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1093@gmail.com', 4036670067, 11066, 21065
);

/* INSERT QUERY NO: 944 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505564, 'Giff', 'Tarren', 'C2', 'N11094', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1094@gmail.com', 4036670068, 11067, 21066
);

/* INSERT QUERY NO: 945 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505565, 'Odella', 'Joslin', 'C2', 'N11095', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1095@gmail.com', 4036670069, 11068, 21067
);

/* INSERT QUERY NO: 946 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505566, 'Regan', 'Camus', 'C2', 'N11096', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1096@gmail.com', 4036670070, 11069, 21068
);

/* INSERT QUERY NO: 947 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505567, 'Sidonia', 'Shier', 'C2', 'N11097', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1097@gmail.com', 4036670071, 11070, 21069
);

/* INSERT QUERY NO: 948 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505568, 'Tally', 'Paton', 'C2', 'N11098', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1098@gmail.com', 4036670072, 11071, 21070
);

/* INSERT QUERY NO: 949 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505569, 'Margot', 'Gatesman', 'C2', 'N11099', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1099@gmail.com', 4036670073, 11072, 21071
);

/* INSERT QUERY NO: 950 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505570, 'Luca', 'Rumford', 'C2', 'N11100', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1100@gmail.com', 4036670074, 11073, 21072
);

/* INSERT QUERY NO: 951 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505571, 'Jojo', 'Edmund', 'C2', 'N11101', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1101@gmail.com', 4036670075, 11074, 21073
);

/* INSERT QUERY NO: 952 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505572, 'Vivyan', 'Phillput', 'C2', 'N11102', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1102@gmail.com', 4036670076, 11075, 21074
);

/* INSERT QUERY NO: 953 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505573, 'Agata', 'Tolputt', 'C2', 'N11103', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1103@gmail.com', 4036670077, 11076, 21075
);

/* INSERT QUERY NO: 954 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505574, 'Janelle', 'Aspinwall', 'C2', 'N11104', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1104@gmail.com', 4036670078, 11077, 21076
);

/* INSERT QUERY NO: 955 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505575, 'Adore', 'Ivankovic', 'C2', 'N11105', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1105@gmail.com', 4036670079, 11078, 21077
);

/* INSERT QUERY NO: 956 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505576, 'Willette', 'Doddemeade', 'C2', 'N11106', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1106@gmail.com', 4036670080, 11079, 21078
);

/* INSERT QUERY NO: 957 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505577, 'Tannie', 'BURWIN', 'C2', 'N11107', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1107@gmail.com', 4036670081, 11080, 21079
);

/* INSERT QUERY NO: 958 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505578, 'Kathe', 'Gooderidge', 'C2', 'N11108', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1108@gmail.com', 4036670082, 11081, 21080
);

/* INSERT QUERY NO: 959 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505579, 'Sarajane', 'Draayer', 'C2', 'N11109', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1109@gmail.com', 4036670083, 11082, 21081
);

/* INSERT QUERY NO: 960 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505580, 'Wilbur', 'Avory', 'C2', 'N11110', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1110@gmail.com', 4036670084, 11083, 21082
);

/* INSERT QUERY NO: 961 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505581, 'Kerrie', 'Tibald', 'C2', 'N11111', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1111@gmail.com', 4036670085, 11084, 21083
);

/* INSERT QUERY NO: 962 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505582, 'Gerta', 'Gadeaux', 'C2', 'N11112', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1112@gmail.com', 4036670086, 11085, 21084
);

/* INSERT QUERY NO: 963 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505583, 'Barton', 'Arnli', 'C2', 'N11113', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1113@gmail.com', 4036670087, 11086, 21085
);

/* INSERT QUERY NO: 964 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505584, 'Nananne', 'Upcraft', 'C2', 'N11114', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1114@gmail.com', 4036670088, 11087, 21086
);

/* INSERT QUERY NO: 965 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505585, 'Benny', 'Jahnisch', 'C2', 'N11115', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1115@gmail.com', 4036670089, 11088, 21087
);

/* INSERT QUERY NO: 966 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505586, 'Johnna', 'Dockerty', 'C2', 'N11116', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1116@gmail.com', 4036670090, 11089, 21088
);

/* INSERT QUERY NO: 967 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505587, 'Ester', 'Loynes', 'C2', 'N11117', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1117@gmail.com', 4036670091, 11090, 21089
);

/* INSERT QUERY NO: 968 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505588, 'Eulalie', 'Kirkbride', 'C2', 'N11118', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1118@gmail.com', 4036670092, 11091, 21090
);

/* INSERT QUERY NO: 969 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505589, 'Alikee', 'Matts', 'C2', 'N11119', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1119@gmail.com', 4036670093, 11092, 21091
);

/* INSERT QUERY NO: 970 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505590, 'Aubry', 'Redler', 'C2', 'N11120', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1120@gmail.com', 4036670094, 11093, 21092
);

/* INSERT QUERY NO: 971 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505591, 'Hewett', 'Anyene', 'C2', 'N11121', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1121@gmail.com', 4036670095, 11094, 21093
);

/* INSERT QUERY NO: 972 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505592, 'Bordie', 'Sculpher', 'C2', 'N11122', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1122@gmail.com', 4036670096, 11095, 21094
);

/* INSERT QUERY NO: 973 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505593, 'Roshelle', 'Montez', 'C2', 'N11123', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1123@gmail.com', 4036670097, 11096, 21095
);

/* INSERT QUERY NO: 974 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505594, 'Guillemette', 'Paule', 'C2', 'N11124', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1124@gmail.com', 4036670098, 11097, 21096
);

/* INSERT QUERY NO: 975 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505595, 'Rochelle', 'Brownsmith', 'C2', 'N11125', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1125@gmail.com', 4036670099, 11098, 21097
);

/* INSERT QUERY NO: 976 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505596, 'Annetta', 'Gossling', 'C2', 'N11126', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1126@gmail.com', 4036670100, 11099, 21098
);

/* INSERT QUERY NO: 977 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505597, 'Hugibert', 'King', 'C2', 'N11127', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1127@gmail.com', 4036670101, 11100, 21099
);

/* INSERT QUERY NO: 978 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505598, 'Keelia', 'Brislen', 'C2', 'N11128', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1128@gmail.com', 4036670102, 11101, 21100
);

/* INSERT QUERY NO: 979 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505599, 'Filmer', 'Episcopi', 'C2', 'N11129', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1129@gmail.com', 4036670103, 11102, 21101
);

/* INSERT QUERY NO: 980 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505600, 'Shell', 'Jenkin', 'C2', 'N11130', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1130@gmail.com', 4036670104, 11103, 21102
);

/* INSERT QUERY NO: 981 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505601, 'Hadley', 'Itzkovwich', 'C2', 'N11131', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1131@gmail.com', 4036670105, 11104, 21103
);

/* INSERT QUERY NO: 982 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505602, 'Broddie', 'Iacovo', 'C2', 'N11132', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1132@gmail.com', 4036670106, 11105, 21104
);

/* INSERT QUERY NO: 983 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505603, 'Debee', 'Rouff', 'C2', 'N11133', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1133@gmail.com', 4036670107, 11106, 21105
);

/* INSERT QUERY NO: 984 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505604, 'Farlay', 'Waterfall', 'C2', 'N11134', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1134@gmail.com', 4036670108, 11107, 21106
);

/* INSERT QUERY NO: 985 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505605, 'Hermia', 'Davidowich', 'C2', 'N11135', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1135@gmail.com', 4036670109, 11108, 21107
);

/* INSERT QUERY NO: 986 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505606, 'Kasper', 'Sibille', 'C2', 'N11136', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1136@gmail.com', 4036670110, 11109, 21108
);

/* INSERT QUERY NO: 987 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505607, 'Obadias', 'MacPaden', 'C2', 'N11137', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1137@gmail.com', 4036670111, 11110, 21109
);

/* INSERT QUERY NO: 988 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505608, 'Julia', 'Merwede', 'C2', 'N11138', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1138@gmail.com', 4036670112, 11111, 21110
);

/* INSERT QUERY NO: 989 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505609, 'Fredi', 'Howsden', 'C2', 'N11139', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1139@gmail.com', 4036670113, 11112, 21111
);

/* INSERT QUERY NO: 990 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505610, 'Garvey', 'Apfel', 'C2', 'N11140', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1140@gmail.com', 4036670114, 11113, 21112
);

/* INSERT QUERY NO: 991 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505611, 'Mia', 'Cough', 'C2', 'N11141', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1141@gmail.com', 4036670115, 11114, 21113
);

/* INSERT QUERY NO: 992 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505612, 'Vonni', 'Cattach', 'C2', 'N11142', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1142@gmail.com', 4036670116, 11115, 21114
);

/* INSERT QUERY NO: 993 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505613, 'Haydon', 'Tander', 'C2', 'N11143', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1143@gmail.com', 4036670117, 11116, 21115
);

/* INSERT QUERY NO: 994 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505614, 'Jemmy', 'Shimmings', 'C2', 'N11144', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1144@gmail.com', 4036670118, 11117, 21116
);

/* INSERT QUERY NO: 995 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505615, 'Shirlene', 'Hens', 'C2', 'N11145', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1145@gmail.com', 4036670119, 11118, 21117
);

/* INSERT QUERY NO: 996 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505616, 'Dennet', 'Menichi', 'C2', 'N11146', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1146@gmail.com', 4036670120, 11119, 21118
);

/* INSERT QUERY NO: 997 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505617, 'Bess', 'Seckington', 'C2', 'N11147', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1147@gmail.com', 4036670121, 11120, 21119
);

/* INSERT QUERY NO: 998 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505618, 'Barry', 'Balham', 'C2', 'N11148', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1148@gmail.com', 4036670122, 11121, 21120
);

/* INSERT QUERY NO: 999 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505619, 'Noelani', 'Yeatman', 'C2', 'N11149', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1149@gmail.com', 4036670123, 11122, 21121
);

/* INSERT QUERY NO: 1000 */
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)
VALUES
(
52505620, 'Evey', 'Hodgins', 'C2', 'N11150', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1150@gmail.com', 4036670124, 10124, 21122
);

