/* Showing results for VEHICULO.xlsx */

/* INSERT QUERY NO: 1 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
366, 'OWX100', 'CHEVROLET', 'publico', 1, 11, 'aveo', 1920, 52504621, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 2 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
367, 'OWX101', 'CHEVROLET', 'publico', 2, 22, 'aveo', 1921, 52504622, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 3 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
368, 'OWX102', 'CHEVROLET', 'publico', 3, 33, 'aveo', 1922, 52504623, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 4 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
369, 'OWX103', 'CHEVROLET', 'publico', 4, 44, 'aveo', 1923, 52504624, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 5 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
370, 'OWX104', 'CHEVROLET', 'publico', 5, 55, 'aveo', 1924, 52504625, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 6 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
371, 'OWX105', 'CHEVROLET', 'publico', 6, 66, 'aveo', 1925, 52504626, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 7 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
372, 'OWX106', 'CHEVROLET', 'publico', 7, 77, 'aveo', 1926, 52504627, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 8 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
373, 'OWX107', 'CHEVROLET', 'publico', 8, 88, 'aveo', 1927, 52504628, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 9 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
374, 'OWX108', 'CHEVROLET', 'publico', 9, 99, 'aveo', 1928, 52504629, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 10 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
375, 'OWX109', 'CHEVROLET', 'publico', 10, 1010, 'aveo', 1929, 52504630, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 11 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
376, 'OWX110', 'CHEVROLET', 'publico', 11, 1111, 'aveo', 1930, 52504631, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 12 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
377, 'OWX111', 'CHEVROLET', 'publico', 12, 1212, 'aveo', 1931, 52504632, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 13 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
378, 'OWX112', 'CHEVROLET', 'publico', 13, 1313, 'aveo', 1932, 52504633, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 14 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
379, 'OWX113', 'CHEVROLET', 'publico', 14, 1414, 'aveo', 1933, 52504634, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 15 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
380, 'OWX114', 'CHEVROLET', 'publico', 15, 1515, 'aveo', 1934, 52504635, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 16 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
381, 'OWX115', 'CHEVROLET', 'publico', 16, 1616, 'aveo', 1935, 52504636, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 17 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
382, 'OWX116', 'CHEVROLET', 'publico', 17, 1717, 'aveo', 1936, 52504637, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 18 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
383, 'OWX117', 'CHEVROLET', 'publico', 18, 1818, 'aveo', 1937, 52504638, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 19 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
384, 'OWX118', 'CHEVROLET', 'publico', 19, 1919, 'aveo', 1938, 52504639, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 20 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
385, 'OWX119', 'CHEVROLET', 'publico', 20, 2020, 'aveo', 1939, 52504640, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 21 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
386, 'OWX120', 'CHEVROLET', 'publico', 21, 2121, 'aveo', 1940, 52504641, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 22 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
387, 'OWX121', 'CHEVROLET', 'publico', 22, 2222, 'aveo', 1941, 52504642, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 23 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
388, 'OWX122', 'CHEVROLET', 'publico', 23, 2323, 'aveo', 1942, 52504643, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 24 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
389, 'OWX123', 'CHEVROLET', 'publico', 24, 2424, 'aveo', 1943, 52504644, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 25 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
390, 'OWX124', 'CHEVROLET', 'publico', 25, 2525, 'aveo', 1944, 52504645, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 26 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
391, 'OWX125', 'CHEVROLET', 'publico', 26, 2626, 'aveo', 1945, 52504646, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 27 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
392, 'OWX126', 'CHEVROLET', 'publico', 27, 2727, 'aveo', 1946, 52504647, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 28 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
393, 'OWX127', 'CHEVROLET', 'publico', 28, 2828, 'aveo', 1947, 52504648, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 29 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
394, 'OWX128', 'CHEVROLET', 'publico', 29, 2929, 'aveo', 1948, 52504649, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 30 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
395, 'OWX129', 'CHEVROLET', 'publico', 30, 3030, 'aveo', 1949, 52504650, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 31 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
396, 'OWX130', 'CHEVROLET', 'publico', 31, 3131, 'aveo', 1950, 52504651, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 32 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
397, 'OWX131', 'CHEVROLET', 'publico', 32, 3232, 'aveo', 1951, 52504652, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 33 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
398, 'OWX132', 'CHEVROLET', 'publico', 33, 3333, 'aveo', 1952, 52504653, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 34 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
399, 'OWX133', 'CHEVROLET', 'publico', 34, 3434, 'aveo', 1953, 52504654, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 35 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
400, 'OWX134', 'CHEVROLET', 'publico', 35, 3535, 'aveo', 1954, 52504655, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 36 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
401, 'OWX135', 'CHEVROLET', 'publico', 36, 3636, 'aveo', 1955, 52504656, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 37 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
402, 'OWX136', 'CHEVROLET', 'publico', 37, 3737, 'aveo', 1956, 52504657, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 38 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
403, 'OWX137', 'CHEVROLET', 'publico', 38, 3838, 'aveo', 1957, 52504658, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 39 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
404, 'OWX138', 'CHEVROLET', 'publico', 39, 3939, 'aveo', 1958, 52504659, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 40 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
405, 'OWX139', 'CHEVROLET', 'publico', 40, 4040, 'aveo', 1959, 52504660, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 41 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
406, 'OWX140', 'CHEVROLET', 'publico', 41, 4141, 'aveo', 1960, 52504661, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 42 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
407, 'OWX141', 'CHEVROLET', 'publico', 42, 4242, 'aveo', 1961, 52504662, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 43 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
408, 'OWX142', 'CHEVROLET', 'publico', 43, 4343, 'aveo', 1962, 52504663, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 44 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
409, 'OWX143', 'CHEVROLET', 'publico', 44, 4444, 'aveo', 1963, 52504664, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 45 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
410, 'OWX144', 'CHEVROLET', 'publico', 45, 4545, 'aveo', 1964, 52504665, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 46 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
411, 'OWX145', 'CHEVROLET', 'publico', 46, 4646, 'aveo', 1965, 52504666, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 47 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
412, 'OWX146', 'CHEVROLET', 'publico', 47, 4747, 'aveo', 1966, 52504667, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 48 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
413, 'OWX147', 'CHEVROLET', 'publico', 48, 4848, 'aveo', 1967, 52504668, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 49 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
414, 'OWX148', 'CHEVROLET', 'publico', 49, 4949, 'aveo', 1968, 52504669, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 50 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
415, 'OWX149', 'CHEVROLET', 'publico', 50, 5050, 'aveo', 1969, 52504670, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 51 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
416, 'OWX150', 'CHEVROLET', 'publico', 51, 5151, 'aveo', 1970, 52504671, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 52 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
417, 'OWX151', 'CHEVROLET', 'publico', 52, 5252, 'aveo', 1971, 52504672, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 53 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
418, 'OWX152', 'CHEVROLET', 'publico', 53, 5353, 'aveo', 1972, 52504673, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 54 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
419, 'OWX153', 'CHEVROLET', 'publico', 54, 5454, 'aveo', 1973, 52504674, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 55 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
420, 'OWX154', 'CHEVROLET', 'publico', 55, 5555, 'aveo', 1974, 52504675, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 56 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
421, 'OWX155', 'CHEVROLET', 'publico', 56, 5656, 'aveo', 1975, 52504676, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 57 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
422, 'OWX156', 'CHEVROLET', 'publico', 57, 5757, 'aveo', 1976, 52504677, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 58 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
423, 'OWX157', 'CHEVROLET', 'publico', 58, 5858, 'aveo', 1977, 52504678, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 59 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
424, 'OWX158', 'CHEVROLET', 'publico', 59, 5959, 'aveo', 1978, 52504679, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 60 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
425, 'OWX159', 'CHEVROLET', 'publico', 60, 6060, 'aveo', 1979, 52504680, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 61 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
426, 'OWX160', 'CHEVROLET', 'publico', 61, 6161, 'aveo', 1980, 52504681, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 62 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
427, 'OWX161', 'CHEVROLET', 'publico', 62, 6262, 'aveo', 1981, 52504682, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 63 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
428, 'OWX162', 'CHEVROLET', 'publico', 63, 6363, 'aveo', 1982, 52504683, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 64 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
429, 'OWX163', 'CHEVROLET', 'publico', 64, 6464, 'aveo', 1983, 52504684, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 65 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
430, 'OWX164', 'CHEVROLET', 'publico', 65, 6565, 'aveo', 1984, 52504685, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 66 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
431, 'OWX165', 'CHEVROLET', 'publico', 66, 6666, 'aveo', 1985, 52504686, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 67 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
432, 'OWX166', 'CHEVROLET', 'publico', 67, 6767, 'aveo', 1986, 52504687, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 68 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
433, 'OWX167', 'CHEVROLET', 'publico', 68, 6868, 'aveo', 1987, 52504688, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 69 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
434, 'OWX168', 'CHEVROLET', 'publico', 69, 6969, 'aveo', 1988, 52504689, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 70 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
435, 'OWX169', 'CHEVROLET', 'publico', 70, 7070, 'aveo', 1989, 52504690, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 71 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
436, 'OWX170', 'CHEVROLET', 'publico', 71, 7171, 'aveo', 1990, 52504691, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 72 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
437, 'OWX171', 'CHEVROLET', 'publico', 72, 7272, 'aveo', 1991, 52504692, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 73 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
438, 'OWX172', 'CHEVROLET', 'publico', 73, 7373, 'aveo', 1992, 52504693, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 74 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
439, 'OWX173', 'CHEVROLET', 'publico', 74, 7474, 'aveo', 1993, 52504694, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 75 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
440, 'OWX174', 'CHEVROLET', 'publico', 75, 7575, 'aveo', 1994, 52504695, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 76 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
441, 'OWX175', 'CHEVROLET', 'publico', 76, 7676, 'aveo', 1995, 52504696, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 77 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
442, 'OWX176', 'CHEVROLET', 'publico', 77, 7777, 'aveo', 1996, 52504697, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 78 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
443, 'OWX177', 'CHEVROLET', 'publico', 78, 7878, 'aveo', 1997, 52504698, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 79 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
444, 'OWX178', 'CHEVROLET', 'publico', 79, 7979, 'aveo', 1998, 52504699, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 80 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
445, 'OWX179', 'CHEVROLET', 'publico', 80, 8080, 'aveo', 1999, 52504700, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 81 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
446, 'OWX180', 'CHEVROLET', 'publico', 81, 8181, 'aveo', 2000, 52504701, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 82 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
447, 'OWX181', 'CHEVROLET', 'publico', 82, 8282, 'aveo', 2001, 52504702, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 83 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
448, 'OWX182', 'CHEVROLET', 'publico', 83, 8383, 'aveo', 2002, 52504703, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 84 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
449, 'OWX183', 'CHEVROLET', 'publico', 84, 8484, 'aveo', 2003, 52504704, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 85 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
450, 'OWX184', 'CHEVROLET', 'publico', 85, 8585, 'aveo', 2004, 52504705, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 86 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
451, 'OWX185', 'CHEVROLET', 'publico', 86, 8686, 'aveo', 2005, 52504706, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 87 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
452, 'OWX186', 'CHEVROLET', 'publico', 87, 8787, 'aveo', 2006, 52504707, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 88 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
453, 'OWX187', 'CHEVROLET', 'publico', 88, 8888, 'aveo', 2007, 52504708, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 89 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
454, 'OWX188', 'CHEVROLET', 'publico', 89, 8989, 'aveo', 2008, 52504709, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 90 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
455, 'OWX189', 'CHEVROLET', 'publico', 90, 9090, 'aveo', 2009, 52504710, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 91 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
456, 'OWX190', 'CHEVROLET', 'publico', 91, 9191, 'aveo', 2010, 52504711, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 92 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
457, 'OWX191', 'CHEVROLET', 'publico', 92, 9292, 'aveo', 2011, 52504712, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 93 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
458, 'OWX192', 'CHEVROLET', 'publico', 93, 9393, 'aveo', 2012, 52504713, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 94 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
459, 'OWX193', 'CHEVROLET', 'publico', 94, 9494, 'aveo', 2013, 52504714, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 95 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
460, 'OWX194', 'CHEVROLET', 'publico', 95, 9595, 'aveo', 2014, 52504715, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 96 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
461, 'OWX195', 'CHEVROLET', 'publico', 96, 9696, 'aveo', 2015, 52504716, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 97 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
462, 'OWX196', 'CHEVROLET', 'publico', 97, 9797, 'aveo', 2016, 52504717, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 98 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
463, 'OWX197', 'CHEVROLET', 'publico', 98, 9898, 'aveo', 2017, 52504718, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 99 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
464, 'OWX198', 'CHEVROLET', 'publico', 99, 9999, 'aveo', 2018, 52504719, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 100 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
465, 'OWX199', 'CHEVROLET', 'publico', 100, 100100, 'aveo', 2019, 52504720, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 101 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
466, 'OWX200', 'CHEVROLET', 'publico', 101, 101101, 'eco-sport', 1920, 52504721, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 102 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
467, 'OWX201', 'CHEVROLET', 'publico', 102, 102102, 'eco-sport', 1921, 52504722, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 103 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
468, 'OWX202', 'CHEVROLET', 'publico', 103, 103103, 'eco-sport', 1922, 52504723, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 104 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
469, 'OWX203', 'CHEVROLET', 'publico', 104, 104104, 'eco-sport', 1923, 52504724, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 105 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
470, 'OWX204', 'CHEVROLET', 'publico', 105, 105105, 'eco-sport', 1924, 52504725, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 106 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
471, 'OWX205', 'CHEVROLET', 'publico', 106, 106106, 'eco-sport', 1925, 52504726, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 107 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
472, 'OWX206', 'CHEVROLET', 'publico', 107, 107107, 'eco-sport', 1926, 52504727, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 108 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
473, 'OWX207', 'CHEVROLET', 'publico', 108, 108108, 'eco-sport', 1927, 52504728, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 109 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
474, 'OWX208', 'CHEVROLET', 'publico', 109, 109109, 'eco-sport', 1928, 52504729, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 110 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
475, 'OWX209', 'CHEVROLET', 'publico', 110, 110110, 'eco-sport', 1929, 52504730, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 111 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
476, 'OWX210', 'CHEVROLET', 'publico', 111, 111111, 'eco-sport', 1930, 52504731, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 112 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
477, 'OWX211', 'CHEVROLET', 'publico', 112, 112112, 'eco-sport', 1931, 52504732, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 113 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
478, 'OWX212', 'CHEVROLET', 'publico', 113, 113113, 'eco-sport', 1932, 52504733, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 114 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
479, 'OWX213', 'CHEVROLET', 'publico', 114, 114114, 'eco-sport', 1933, 52504734, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 115 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
480, 'OWX214', 'CHEVROLET', 'publico', 115, 115115, 'eco-sport', 1934, 52504735, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 116 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
481, 'OWX215', 'CHEVROLET', 'publico', 116, 116116, 'eco-sport', 1935, 52504736, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 117 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
482, 'OWX216', 'CHEVROLET', 'publico', 117, 117117, 'eco-sport', 1936, 52504737, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 118 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
483, 'OWX217', 'CHEVROLET', 'publico', 118, 118118, 'eco-sport', 1937, 52504738, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 119 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
484, 'OWX218', 'CHEVROLET', 'publico', 119, 119119, 'eco-sport', 1938, 52504739, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 120 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
485, 'OWX219', 'CHEVROLET', 'publico', 120, 120120, 'eco-sport', 1939, 52504740, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 121 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
486, 'OWX220', 'CHEVROLET', 'publico', 121, 121121, 'eco-sport', 1940, 52504741, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 122 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
487, 'OWX221', 'CHEVROLET', 'publico', 122, 122122, 'eco-sport', 1941, 52504742, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 123 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
488, 'OWX222', 'CHEVROLET', 'publico', 123, 123123, 'eco-sport', 1942, 52504743, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 124 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
489, 'OWX223', 'CHEVROLET', 'publico', 124, 124124, 'eco-sport', 1943, 52504744, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 125 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
490, 'OWX224', 'CHEVROLET', 'publico', 125, 125125, 'eco-sport', 1944, 52504745, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 126 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
491, 'OWX225', 'CHEVROLET', 'publico', 126, 126126, 'eco-sport', 1945, 52504746, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 127 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
492, 'OWX226', 'CHEVROLET', 'publico', 127, 127127, 'eco-sport', 1946, 52504747, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 128 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
493, 'OWX227', 'CHEVROLET', 'publico', 128, 128128, 'eco-sport', 1947, 52504748, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 129 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
494, 'OWX228', 'CHEVROLET', 'publico', 129, 129129, 'eco-sport', 1948, 52504749, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 130 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
495, 'OWX229', 'CHEVROLET', 'publico', 130, 130130, 'eco-sport', 1949, 52504750, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 131 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
496, 'OWX230', 'CHEVROLET', 'publico', 131, 131131, 'eco-sport', 1950, 52504751, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 132 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
497, 'OWX231', 'CHEVROLET', 'publico', 132, 132132, 'eco-sport', 1951, 52504752, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 133 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
498, 'OWX232', 'CHEVROLET', 'publico', 133, 133133, 'eco-sport', 1952, 52504753, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 134 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
499, 'OWX233', 'CHEVROLET', 'publico', 134, 134134, 'eco-sport', 1953, 52504754, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 135 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
500, 'OWX234', 'CHEVROLET', 'publico', 135, 135135, 'eco-sport', 1954, 52504755, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 136 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
501, 'OWX235', 'CHEVROLET', 'publico', 136, 136136, 'eco-sport', 1955, 52504756, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 137 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
502, 'OWX236', 'CHEVROLET', 'publico', 137, 137137, 'eco-sport', 1956, 52504757, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 138 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
503, 'OWX237', 'CHEVROLET', 'publico', 138, 138138, 'eco-sport', 1957, 52504758, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 139 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
504, 'OWX238', 'CHEVROLET', 'publico', 139, 139139, 'eco-sport', 1958, 52504759, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 140 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
505, 'OWX239', 'CHEVROLET', 'publico', 140, 140140, 'eco-sport', 1959, 52504760, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 141 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
506, 'OWX240', 'CHEVROLET', 'publico', 141, 141141, 'eco-sport', 1960, 52504761, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 142 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
507, 'OWX241', 'CHEVROLET', 'publico', 142, 142142, 'eco-sport', 1961, 52504762, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 143 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
508, 'OWX242', 'CHEVROLET', 'publico', 143, 143143, 'eco-sport', 1962, 52504763, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 144 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
509, 'OWX243', 'CHEVROLET', 'publico', 144, 144144, 'eco-sport', 1963, 52504764, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 145 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
510, 'OWX244', 'CHEVROLET', 'publico', 145, 145145, 'eco-sport', 1964, 52504765, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 146 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
511, 'OWX245', 'CHEVROLET', 'publico', 146, 146146, 'eco-sport', 1965, 52504766, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 147 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
512, 'OWX246', 'CHEVROLET', 'publico', 147, 147147, 'eco-sport', 1966, 52504767, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 148 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
513, 'OWX247', 'CHEVROLET', 'publico', 148, 148148, 'eco-sport', 1967, 52504768, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 149 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
514, 'OWX248', 'CHEVROLET', 'publico', 149, 149149, 'eco-sport', 1968, 52504769, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 150 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
515, 'OWX249', 'CHEVROLET', 'publico', 150, 150150, 'eco-sport', 1969, 52504770, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 151 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
516, 'OWX250', 'CHEVROLET', 'publico', 151, 151151, 'eco-sport', 1970, 52504771, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 152 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
517, 'OWX251', 'CHEVROLET', 'publico', 152, 152152, 'eco-sport', 1971, 52504772, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 153 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
518, 'OWX252', 'CHEVROLET', 'publico', 153, 153153, 'eco-sport', 1972, 52504773, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 154 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
519, 'OWX253', 'CHEVROLET', 'publico', 154, 154154, 'eco-sport', 1973, 52504774, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 155 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
520, 'OWX254', 'CHEVROLET', 'publico', 155, 155155, 'eco-sport', 1974, 52504775, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 156 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
521, 'OWX255', 'CHEVROLET', 'publico', 156, 156156, 'eco-sport', 1975, 52504776, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 157 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
522, 'OWX256', 'CHEVROLET', 'publico', 157, 157157, 'eco-sport', 1976, 52504777, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 158 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
523, 'OWX257', 'CHEVROLET', 'publico', 158, 158158, 'eco-sport', 1977, 52504778, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 159 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
524, 'OWX258', 'CHEVROLET', 'publico', 159, 159159, 'eco-sport', 1978, 52504779, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 160 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
525, 'OWX259', 'CHEVROLET', 'publico', 160, 160160, 'eco-sport', 1979, 52504780, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 161 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
526, 'OWX260', 'CHEVROLET', 'publico', 161, 161161, 'eco-sport', 1980, 52504781, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 162 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
527, 'OWX261', 'CHEVROLET', 'publico', 162, 162162, 'eco-sport', 1981, 52504782, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 163 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
528, 'OWX262', 'CHEVROLET', 'publico', 163, 163163, 'eco-sport', 1982, 52504783, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 164 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
529, 'OWX263', 'CHEVROLET', 'publico', 164, 164164, 'eco-sport', 1983, 52504784, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 165 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
530, 'OWX264', 'CHEVROLET', 'publico', 165, 165165, 'eco-sport', 1984, 52504785, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 166 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
531, 'OWX265', 'CHEVROLET', 'publico', 166, 166166, 'eco-sport', 1985, 52504786, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 167 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
532, 'OWX266', 'CHEVROLET', 'publico', 167, 167167, 'eco-sport', 1986, 52504787, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 168 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
533, 'OWX267', 'CHEVROLET', 'publico', 168, 168168, 'eco-sport', 1987, 52504788, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 169 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
534, 'OWX268', 'CHEVROLET', 'publico', 169, 169169, 'eco-sport', 1988, 52504789, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 170 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
535, 'OWX269', 'CHEVROLET', 'publico', 170, 170170, 'eco-sport', 1989, 52504790, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 171 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
536, 'OWX270', 'CHEVROLET', 'publico', 171, 171171, 'eco-sport', 1990, 52504791, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 172 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
537, 'OWX271', 'CHEVROLET', 'publico', 172, 172172, 'eco-sport', 1991, 52504792, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 173 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
538, 'OWX272', 'CHEVROLET', 'publico', 173, 173173, 'eco-sport', 1992, 52504793, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 174 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
539, 'OWX273', 'CHEVROLET', 'publico', 174, 174174, 'eco-sport', 1993, 52504794, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 175 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
540, 'OWX274', 'CHEVROLET', 'publico', 175, 175175, 'eco-sport', 1994, 52504795, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 176 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
541, 'OWX275', 'CHEVROLET', 'publico', 176, 176176, 'eco-sport', 1995, 52504796, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 177 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
542, 'OWX276', 'CHEVROLET', 'publico', 177, 177177, 'eco-sport', 1996, 52504797, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 178 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
543, 'OWX277', 'CHEVROLET', 'publico', 178, 178178, 'eco-sport', 1997, 52504798, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 179 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
544, 'OWX278', 'CHEVROLET', 'publico', 179, 179179, 'eco-sport', 1998, 52504799, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 180 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
545, 'OWX279', 'CHEVROLET', 'publico', 180, 180180, 'eco-sport', 1999, 52504800, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 181 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
546, 'OWX280', 'CHEVROLET', 'publico', 181, 181181, 'eco-sport', 2000, 52504801, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 182 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
547, 'OWX281', 'CHEVROLET', 'publico', 182, 182182, 'eco-sport', 2001, 52504802, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 183 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
548, 'OWX282', 'CHEVROLET', 'publico', 183, 183183, 'eco-sport', 2002, 52504803, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 184 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
549, 'OWX283', 'CHEVROLET', 'publico', 184, 184184, 'eco-sport', 2003, 52504804, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 185 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
550, 'OWX284', 'CHEVROLET', 'publico', 185, 185185, 'eco-sport', 2004, 52504805, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 186 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
551, 'OWX285', 'CHEVROLET', 'publico', 186, 186186, 'eco-sport', 2005, 52504806, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 187 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
552, 'OWX286', 'CHEVROLET', 'publico', 187, 187187, 'eco-sport', 2006, 52504807, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 188 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
553, 'OWX287', 'CHEVROLET', 'publico', 188, 188188, 'eco-sport', 2007, 52504808, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 189 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
554, 'OWX288', 'CHEVROLET', 'publico', 189, 189189, 'eco-sport', 2008, 52504809, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 190 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
555, 'OWX289', 'CHEVROLET', 'publico', 190, 190190, 'eco-sport', 2009, 52504810, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 191 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
556, 'OWX290', 'CHEVROLET', 'publico', 191, 191191, 'eco-sport', 2010, 52504811, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 192 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
557, 'OWX291', 'CHEVROLET', 'publico', 192, 192192, 'eco-sport', 2011, 52504812, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 193 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
558, 'OWX292', 'CHEVROLET', 'publico', 193, 193193, 'eco-sport', 2012, 52504813, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 194 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
559, 'OWX293', 'CHEVROLET', 'publico', 194, 194194, 'eco-sport', 2013, 52504814, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 195 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
560, 'OWX294', 'CHEVROLET', 'publico', 195, 195195, 'eco-sport', 2014, 52504815, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 196 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
561, 'OWX295', 'CHEVROLET', 'publico', 196, 196196, 'eco-sport', 2015, 52504816, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 197 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
562, 'OWX296', 'CHEVROLET', 'publico', 197, 197197, 'eco-sport', 2016, 52504817, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 198 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
563, 'OWX297', 'CHEVROLET', 'publico', 198, 198198, 'eco-sport', 2017, 52504818, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 199 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
564, 'OWX298', 'CHEVROLET', 'publico', 199, 199199, 'eco-sport', 2018, 52504819, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 200 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
565, 'OWX299', 'CHEVROLET', 'publico', 200, 200200, 'escape', 2019, 52504820, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 201 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
566, 'OWX300', 'FORD', 'publico', 201, 201201, 'sail', 1920, 52504821, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 202 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
567, 'OWX301', 'FORD', 'publico', 202, 202202, 'escape', 1921, 52504822, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 203 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
568, 'OWX302', 'FORD', 'publico', 203, 203203, 'sail', 1922, 52504823, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 204 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
569, 'OWX303', 'FORD', 'publico', 204, 204204, 'escape', 1923, 52504824, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 205 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
570, 'OWX304', 'FORD', 'publico', 205, 205205, 'sail', 1924, 52504825, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 206 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
571, 'OWX305', 'FORD', 'publico', 206, 206206, 'escape', 1925, 52504826, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 207 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
572, 'OWX306', 'FORD', 'publico', 207, 207207, 'sail', 1926, 52504827, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 208 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
573, 'OWX307', 'FORD', 'publico', 208, 208208, 'escape', 1927, 52504828, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 209 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
574, 'OWX308', 'FORD', 'publico', 209, 209209, 'sail', 1928, 52504829, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 210 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
575, 'OWX309', 'FORD', 'publico', 210, 210210, 'escape', 1929, 52504830, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 211 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
576, 'OWX310', 'FORD', 'publico', 211, 211211, 'sail', 1930, 52504831, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 212 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
577, 'OWX311', 'FORD', 'publico', 212, 212212, 'escape', 1931, 52504832, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 213 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
578, 'OWX312', 'FORD', 'publico', 213, 213213, 'sail', 1932, 52504833, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 214 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
579, 'OWX313', 'FORD', 'publico', 214, 214214, 'escape', 1933, 52504834, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 215 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
580, 'OWX314', 'FORD', 'publico', 215, 215215, 'sail', 1934, 52504835, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 216 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
581, 'OWX315', 'FORD', 'publico', 216, 216216, 'escape', 1935, 52504836, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 217 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
582, 'OWX316', 'FORD', 'publico', 217, 217217, 'sail', 1936, 52504837, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 218 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
583, 'OWX317', 'FORD', 'publico', 218, 218218, 'escape', 1937, 52504838, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 219 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
584, 'OWX318', 'FORD', 'publico', 219, 219219, 'sail', 1938, 52504839, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 220 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
585, 'OWX319', 'FORD', 'publico', 220, 220220, 'escape', 1939, 52504840, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 221 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
586, 'OWX320', 'FORD', 'publico', 221, 221221, 'sail', 1940, 52504841, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 222 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
587, 'OWX321', 'FORD', 'publico', 222, 222222, 'escape', 1941, 52504842, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 223 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
588, 'OWX322', 'FORD', 'publico', 223, 223223, 'sail', 1942, 52504843, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 224 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
589, 'OWX323', 'FORD', 'publico', 224, 224224, 'escape', 1943, 52504844, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 225 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
590, 'OWX324', 'FORD', 'publico', 225, 225225, 'sail', 1944, 52504845, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 226 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
591, 'OWX325', 'FORD', 'publico', 226, 226226, 'escape', 1945, 52504846, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 227 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
592, 'OWX326', 'FORD', 'publico', 227, 227227, 'sail', 1946, 52504847, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 228 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
593, 'OWX327', 'FORD', 'publico', 228, 228228, 'escape', 1947, 52504848, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 229 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
594, 'OWX328', 'FORD', 'publico', 229, 229229, 'sail', 1948, 52504849, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 230 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
595, 'OWX329', 'FORD', 'publico', 230, 230230, 'escape', 1949, 52504850, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 231 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
596, 'OWX330', 'FORD', 'publico', 231, 231231, 'sail', 1950, 52504851, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 232 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
597, 'OWX331', 'FORD', 'publico', 232, 232232, 'escape', 1951, 52504852, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 233 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
598, 'OWX332', 'FORD', 'publico', 233, 233233, 'sail', 1952, 52504853, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 234 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
599, 'OWX333', 'FORD', 'publico', 234, 234234, 'escape', 1953, 52504854, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 235 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
600, 'OWX334', 'FORD', 'publico', 235, 235235, 'sail', 1954, 52504855, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 236 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
601, 'OWX335', 'FORD', 'publico', 236, 236236, 'escape', 1955, 52504856, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 237 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
602, 'OWX336', 'FORD', 'publico', 237, 237237, 'sail', 1956, 52504857, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 238 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
603, 'OWX337', 'FORD', 'publico', 238, 238238, 'escape', 1957, 52504858, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 239 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
604, 'OWX338', 'FORD', 'publico', 239, 239239, 'sail', 1958, 52504859, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 240 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
605, 'OWX339', 'FORD', 'publico', 240, 240240, 'escape', 1959, 52504860, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 241 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
606, 'OWX340', 'FORD', 'publico', 241, 241241, 'sail', 1960, 52504861, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 242 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
607, 'OWX341', 'FORD', 'publico', 242, 242242, 'escape', 1961, 52504862, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 243 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
608, 'OWX342', 'FORD', 'publico', 243, 243243, 'sail', 1962, 52504863, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 244 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
609, 'OWX343', 'FORD', 'publico', 244, 244244, 'escape', 1963, 52504864, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 245 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
610, 'OWX344', 'FORD', 'publico', 245, 245245, 'sail', 1964, 52504865, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 246 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
611, 'OWX345', 'FORD', 'publico', 246, 246246, 'escape', 1965, 52504866, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 247 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
612, 'OWX346', 'FORD', 'publico', 247, 247247, 'sail', 1966, 52504867, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 248 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
613, 'OWX347', 'FORD', 'publico', 248, 248248, 'escape', 1967, 52504868, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 249 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
614, 'OWX348', 'FORD', 'publico', 249, 249249, 'sail', 1968, 52504869, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 250 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
615, 'OWX349', 'FORD', 'publico', 250, 250250, 'escape', 1969, 52504870, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 251 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
616, 'OWX350', 'FORD', 'publico', 251, 251251, 'sail', 1970, 52504871, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 252 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
617, 'OWX351', 'FORD', 'publico', 252, 252252, 'escape', 1971, 52504872, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 253 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
618, 'OWX352', 'FORD', 'publico', 253, 253253, 'sail', 1972, 52504873, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 254 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
619, 'OWX353', 'FORD', 'publico', 254, 254254, 'escape', 1973, 52504874, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 255 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
620, 'OWX354', 'FORD', 'publico', 255, 255255, 'sail', 1974, 52504875, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 256 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
621, 'OWX355', 'FORD', 'publico', 256, 256256, 'escape', 1975, 52504876, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 257 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
622, 'OWX356', 'FORD', 'publico', 257, 257257, 'sail', 1976, 52504877, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 258 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
623, 'OWX357', 'FORD', 'publico', 258, 258258, 'escape', 1977, 52504878, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 259 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
624, 'OWX358', 'FORD', 'publico', 259, 259259, 'sail', 1978, 52504879, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 260 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
625, 'OWX359', 'FORD', 'publico', 260, 260260, 'escape', 1979, 52504880, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 261 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
626, 'OWX360', 'FORD', 'publico', 261, 261261, 'sail', 1980, 52504881, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 262 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
627, 'OWX361', 'FORD', 'publico', 262, 262262, 'escape', 1981, 52504882, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 263 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
628, 'OWX362', 'FORD', 'publico', 263, 263263, 'sail', 1982, 52504883, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 264 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
629, 'OWX363', 'FORD', 'publico', 264, 264264, 'escape', 1983, 52504884, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 265 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
630, 'OWX364', 'FORD', 'publico', 265, 265265, 'sail', 1984, 52504885, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 266 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
631, 'OWX365', 'FORD', 'publico', 266, 266266, 'escape', 1985, 52504886, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 267 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
632, 'OWX366', 'FORD', 'publico', 267, 267267, 'sail', 1986, 52504887, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 268 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
633, 'OWX367', 'FORD', 'publico', 268, 268268, 'escape', 1987, 52504888, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 269 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
634, 'OWX368', 'FORD', 'publico', 269, 269269, 'sail', 1988, 52504889, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 270 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
635, 'OWX369', 'FORD', 'publico', 270, 270270, 'escape', 1989, 52504890, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 271 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
636, 'OWX370', 'FORD', 'publico', 271, 271271, 'sail', 1990, 52504891, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 272 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
637, 'OWX371', 'FORD', 'publico', 272, 272272, 'escape', 1991, 52504892, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 273 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
638, 'OWX372', 'FORD', 'publico', 273, 273273, 'sail', 1992, 52504893, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 274 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
639, 'OWX373', 'FORD', 'publico', 274, 274274, 'escape', 1993, 52504894, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 275 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
640, 'OWX374', 'FORD', 'publico', 275, 275275, 'sail', 1994, 52504895, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 276 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
641, 'OWX375', 'FORD', 'publico', 276, 276276, 'escape', 1995, 52504896, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 277 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
642, 'OWX376', 'FORD', 'publico', 277, 277277, 'sail', 1996, 52504897, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 278 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
643, 'OWX377', 'FORD', 'publico', 278, 278278, 'escape', 1997, 52504898, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 279 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
644, 'OWX378', 'FORD', 'publico', 279, 279279, 'sail', 1998, 52504899, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 280 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
645, 'OWX379', 'FORD', 'publico', 280, 280280, 'escape', 1999, 52504900, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 281 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
646, 'OWX380', 'FORD', 'publico', 281, 281281, 'sail', 2000, 52504901, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 282 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
647, 'OWX381', 'FORD', 'publico', 282, 282282, 'escape', 2001, 52504902, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 283 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
648, 'OWX382', 'FORD', 'publico', 283, 283283, 'sail', 2002, 52504903, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 284 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
649, 'OWX383', 'FORD', 'publico', 284, 284284, 'escape', 2003, 52504904, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 285 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
650, 'OWX384', 'FORD', 'publico', 285, 285285, 'sail', 2004, 52504905, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 286 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
651, 'OWX385', 'FORD', 'publico', 286, 286286, 'escape', 2005, 52504906, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 287 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
652, 'OWX386', 'FORD', 'publico', 287, 287287, 'sail', 2006, 52504907, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 288 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
653, 'OWX387', 'FORD', 'publico', 288, 288288, 'escape', 2007, 52504908, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 289 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
654, 'OWX388', 'FORD', 'publico', 289, 289289, 'sail', 2008, 52504909, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 290 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
655, 'OWX389', 'FORD', 'publico', 290, 290290, 'escape', 2009, 52504910, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 291 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
656, 'OWX390', 'FORD', 'publico', 291, 291291, 'sail', 2010, 52504911, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 292 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
657, 'OWX391', 'FORD', 'publico', 292, 292292, 'escape', 2011, 52504912, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 293 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
658, 'OWX392', 'FORD', 'publico', 293, 293293, 'sail', 2012, 52504913, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 294 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
659, 'OWX393', 'FORD', 'publico', 294, 294294, 'escape', 2013, 52504914, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 295 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
660, 'OWX394', 'FORD', 'publico', 295, 295295, 'sail', 2014, 52504915, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 296 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
661, 'OWX395', 'FORD', 'publico', 296, 296296, 'escape', 2015, 52504916, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 297 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
662, 'OWX396', 'FORD', 'publico', 297, 297297, 'sail', 2016, 52504917, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 298 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
663, 'OWX397', 'FORD', 'publico', 298, 298298, 'escape', 2017, 52504918, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 299 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
664, 'OWX398', 'FORD', 'publico', 299, 299299, 'sail', 2018, 52504919, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 300 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
665, 'OWX399', 'FORD', 'publico', 300, 300300, 'sandero', 1920, 52504920, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 301 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
666, 'OWX400', 'FORD', 'publico', 301, 301301, 'sandero', 1921, 52504921, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 302 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
667, 'OWX401', 'FORD', 'publico', 302, 302302, 'sandero', 1922, 52504922, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 303 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
668, 'OWX402', 'FORD', 'publico', 303, 303303, 'sandero', 1923, 52504923, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 304 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
669, 'OWX403', 'FORD', 'publico', 304, 304304, 'sandero', 1924, 52504924, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 305 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
670, 'OWX404', 'FORD', 'publico', 305, 305305, 'sandero', 1925, 52504925, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 306 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
671, 'OWX405', 'FORD', 'publico', 306, 306306, 'sandero', 1926, 52504926, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 307 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
672, 'OWX406', 'FORD', 'publico', 307, 307307, 'sandero', 1927, 52504927, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 308 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
673, 'OWX407', 'FORD', 'publico', 308, 308308, 'sandero', 1928, 52504928, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 309 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
674, 'OWX408', 'FORD', 'publico', 309, 309309, 'sandero', 1929, 52504929, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 310 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
675, 'OWX409', 'FORD', 'publico', 310, 310310, 'sandero', 1930, 52504930, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 311 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
676, 'OWX410', 'FORD', 'publico', 311, 311311, 'sandero', 1931, 52504931, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 312 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
677, 'OWX411', 'FORD', 'publico', 312, 312312, 'sandero', 1932, 52504932, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 313 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
678, 'OWX412', 'FORD', 'publico', 313, 313313, 'sandero', 1933, 52504933, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 314 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
679, 'OWX413', 'FORD', 'publico', 314, 314314, 'sandero', 1934, 52504934, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 315 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
680, 'OWX414', 'FORD', 'publico', 315, 315315, 'sandero', 1935, 52504935, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 316 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
681, 'OWX415', 'FORD', 'publico', 316, 316316, 'sandero', 1936, 52504936, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 317 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
682, 'OWX416', 'FORD', 'publico', 317, 317317, 'sandero', 1937, 52504937, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 318 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
683, 'OWX417', 'FORD', 'publico', 318, 318318, 'sandero', 1938, 52504938, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 319 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
684, 'OWX418', 'FORD', 'publico', 319, 319319, 'sandero', 1939, 52504939, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 320 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
685, 'OWX419', 'FORD', 'publico', 320, 320320, 'sandero', 1940, 52504940, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 321 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
686, 'OWX420', 'FORD', 'publico', 321, 321321, 'sandero', 1941, 52504941, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 322 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
687, 'OWX421', 'FORD', 'publico', 322, 322322, 'sandero', 1942, 52504942, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 323 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
688, 'OWX422', 'FORD', 'publico', 323, 323323, 'sandero', 1943, 52504943, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 324 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
689, 'OWX423', 'FORD', 'publico', 324, 324324, 'sandero', 1944, 52504944, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 325 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
690, 'OWX424', 'FORD', 'publico', 325, 325325, 'sandero', 1945, 52504945, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 326 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
691, 'OWX425', 'FORD', 'publico', 326, 326326, 'sandero', 1946, 52504946, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 327 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
692, 'OWX426', 'FORD', 'publico', 327, 327327, 'sandero', 1947, 52504947, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 328 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
693, 'OWX427', 'FORD', 'publico', 328, 328328, 'sandero', 1948, 52504948, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 329 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
694, 'OWX428', 'FORD', 'publico', 329, 329329, 'sandero', 1949, 52504949, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 330 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
695, 'OWX429', 'FORD', 'publico', 330, 330330, 'sandero', 1950, 52504950, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 331 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
696, 'OWX430', 'FORD', 'publico', 331, 331331, 'sandero', 1951, 52504951, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 332 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
697, 'OWX431', 'FORD', 'publico', 332, 332332, 'sandero', 1952, 52504952, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 333 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
698, 'OWX432', 'FORD', 'publico', 333, 333333, 'sandero', 1953, 52504953, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 334 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
699, 'OWX433', 'FORD', 'publico', 334, 334334, 'sandero', 1954, 52504954, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 335 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
700, 'OWX434', 'FORD', 'publico', 335, 335335, 'sandero', 1955, 52504955, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 336 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
701, 'OWX435', 'FORD', 'publico', 336, 336336, 'sandero', 1956, 52504956, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 337 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
702, 'OWX436', 'FORD', 'publico', 337, 337337, 'sandero', 1957, 52504957, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 338 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
703, 'OWX437', 'FORD', 'publico', 338, 338338, 'sandero', 1958, 52504958, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 339 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
704, 'OWX438', 'FORD', 'publico', 339, 339339, 'sandero', 1959, 52504959, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 340 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
705, 'OWX439', 'FORD', 'publico', 340, 340340, 'sandero', 1960, 52504960, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 341 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
706, 'OWX440', 'FORD', 'particular', 341, 341341, 'sandero', 1961, 52504961, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 342 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
707, 'OWX441', 'FORD', 'particular', 342, 342342, 'sandero', 1962, 52504962, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 343 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
708, 'OWX442', 'FORD', 'particular', 343, 343343, 'sandero', 1963, 52504963, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 344 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
709, 'OWX443', 'FORD', 'particular', 344, 344344, 'sandero', 1964, 52504964, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 345 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
710, 'OWX444', 'FORD', 'particular', 345, 345345, 'sandero', 1965, 52504965, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 346 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
711, 'OWX445', 'FORD', 'particular', 346, 346346, 'sandero', 1966, 52504966, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 347 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
712, 'OWX446', 'FORD', 'particular', 347, 347347, 'sandero', 1967, 52504967, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 348 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
713, 'OWX447', 'FORD', 'particular', 348, 348348, 'sandero', 1968, 52504968, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 349 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
714, 'OWX448', 'FORD', 'particular', 349, 349349, 'sandero', 1969, 52504969, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 350 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
715, 'OWX449', 'FORD', 'particular', 350, 350350, 'sandero', 1970, 52504970, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 351 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
716, 'OWX450', 'FORD', 'particular', 351, 351351, 'sandero', 1971, 52504971, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 352 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
717, 'OWX451', 'FORD', 'particular', 352, 352352, 'sandero', 1972, 52504972, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 353 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
718, 'OWX452', 'FORD', 'particular', 353, 353353, 'sandero', 1973, 52504973, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 354 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
719, 'OWX453', 'FORD', 'particular', 354, 354354, 'sandero', 1974, 52504974, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 355 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
720, 'OWX454', 'FORD', 'particular', 355, 355355, 'sandero', 1975, 52504975, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 356 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
721, 'OWX455', 'FORD', 'particular', 356, 356356, 'sandero', 1976, 52504976, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 357 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
722, 'OWX456', 'FORD', 'particular', 357, 357357, 'sandero', 1977, 52504977, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 358 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
723, 'OWX457', 'FORD', 'particular', 358, 358358, 'sandero', 1978, 52504978, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 359 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
724, 'OWX458', 'FORD', 'particular', 359, 359359, 'sandero', 1979, 52504979, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 360 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
725, 'OWX459', 'FORD', 'particular', 360, 360360, 'sandero', 1980, 52504980, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 361 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
726, 'OWX460', 'FORD', 'particular', 361, 361361, 'sandero', 1981, 52504981, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 362 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
727, 'OWX461', 'FORD', 'particular', 362, 362362, 'sandero', 1982, 52504982, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 363 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
728, 'OWX462', 'FORD', 'particular', 363, 363363, 'sandero', 1983, 52504983, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 364 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
729, 'OWX463', 'FORD', 'particular', 364, 364364, 'sandero', 1984, 52504984, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 365 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
730, 'OWX464', 'FORD', 'particular', 365, 365365, 'sandero', 1985, 52504985, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 366 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
731, 'OWX465', 'FORD', 'particular', 366, 366366, 'sandero', 1986, 52504986, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 367 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
732, 'OWX466', 'FORD', 'particular', 367, 367367, 'sandero', 1987, 52504987, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 368 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
733, 'OWX467', 'FORD', 'particular', 368, 368368, 'sandero', 1988, 52504988, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 369 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
734, 'OWX468', 'FORD', 'particular', 369, 369369, 'sandero', 1989, 52504989, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 370 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
735, 'OWX469', 'FORD', 'particular', 370, 370370, 'sandero', 1990, 52504990, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 371 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
736, 'OWX470', 'FORD', 'particular', 371, 371371, 'sandero', 1991, 52504991, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 372 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
737, 'OWX471', 'FORD', 'particular', 372, 372372, 'sandero', 1992, 52504992, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 373 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
738, 'OWX472', 'FORD', 'particular', 373, 373373, 'sandero', 1993, 52504993, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 374 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
739, 'OWX473', 'FORD', 'particular', 374, 374374, 'sandero', 1994, 52504994, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 375 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
740, 'OWX474', 'FORD', 'particular', 375, 375375, 'sandero', 1995, 52504995, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 376 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
741, 'OWX475', 'FORD', 'particular', 376, 376376, 'sandero', 1996, 52504996, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 377 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
742, 'OWX476', 'FORD', 'particular', 377, 377377, 'sandero', 1997, 52504997, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 378 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
743, 'OWX477', 'FORD', 'particular', 378, 378378, 'sandero', 1998, 52504998, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 379 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
744, 'OWX478', 'FORD', 'particular', 379, 379379, 'sandero', 1999, 52504999, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 380 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
745, 'OWX479', 'FORD', 'particular', 380, 380380, 'sandero', 2000, 52505000, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 381 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
746, 'OWX480', 'FORD', 'particular', 381, 381381, 'sandero', 2001, 52505001, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 382 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
747, 'OWX481', 'FORD', 'particular', 382, 382382, 'sandero', 2002, 52505002, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 383 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
748, 'OWX482', 'FORD', 'particular', 383, 383383, 'sandero', 2003, 52505003, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 384 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
749, 'OWX483', 'FORD', 'particular', 384, 384384, 'sandero', 2004, 52505004, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 385 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
750, 'OWX484', 'FORD', 'particular', 385, 385385, 'sandero', 2005, 52505005, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 386 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
751, 'OWX485', 'FORD', 'particular', 386, 386386, 'sandero', 2006, 52505006, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 387 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
752, 'OWX486', 'FORD', 'particular', 387, 387387, 'sandero', 2007, 52505007, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 388 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
753, 'OWX487', 'FORD', 'particular', 388, 388388, 'sandero', 2008, 52505008, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 389 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
754, 'OWX488', 'FORD', 'particular', 389, 389389, 'sandero', 2009, 52505009, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 390 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
755, 'OWX489', 'FORD', 'particular', 390, 390390, 'sandero', 2010, 52505010, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 391 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
756, 'OWX490', 'FORD', 'particular', 391, 391391, 'sandero', 2011, 52505011, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 392 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
757, 'OWX491', 'FORD', 'particular', 392, 392392, 'sandero', 2012, 52505012, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 393 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
758, 'OWX492', 'FORD', 'particular', 393, 393393, 'sandero', 2013, 52505013, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 394 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
759, 'OWX493', 'FORD', 'particular', 394, 394394, 'sandero', 2014, 52505014, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 395 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
760, 'OWX494', 'FORD', 'particular', 395, 395395, 'sandero', 2015, 52505015, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 396 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
761, 'OWX495', 'FORD', 'particular', 396, 396396, 'sandero', 2016, 52505016, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 397 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
762, 'OWX496', 'FORD', 'particular', 397, 397397, 'sandero', 2017, 52505017, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 398 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
763, 'OWX497', 'FORD', 'particular', 398, 398398, 'sandero', 2018, 52505018, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 399 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
764, 'OWX498', 'FORD', 'particular', 399, 399399, 'sandero', 2019, 52505019, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 400 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
765, 'OWX499', 'FORD', 'particular', 400, 400400, 'jetta', 1920, 52505020, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 401 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
766, 'OWX500', 'NISSAN', 'particular', 401, 401401, 'jetta', 1921, 52505021, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 402 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
767, 'OWX501', 'NISSAN', 'particular', 402, 402402, 'jetta', 1922, 52505022, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 403 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
768, 'OWX502', 'NISSAN', 'particular', 403, 403403, 'jetta', 1923, 52505023, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 404 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
769, 'OWX503', 'NISSAN', 'particular', 404, 404404, 'jetta', 1924, 52505024, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 405 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
770, 'OWX504', 'NISSAN', 'particular', 405, 405405, 'jetta', 1925, 52505025, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 406 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
771, 'OWX505', 'NISSAN', 'particular', 406, 406406, 'jetta', 1926, 52505026, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 407 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
772, 'OWX506', 'NISSAN', 'particular', 407, 407407, 'jetta', 1927, 52505027, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 408 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
773, 'OWX507', 'NISSAN', 'particular', 408, 408408, 'jetta', 1928, 52505028, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 409 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
774, 'OWX508', 'NISSAN', 'particular', 409, 409409, 'jetta', 1929, 52505029, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 410 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
775, 'OWX509', 'NISSAN', 'particular', 410, 410410, 'jetta', 1930, 52505030, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 411 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
776, 'OWX510', 'NISSAN', 'particular', 411, 411411, 'jetta', 1931, 52505031, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 412 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
777, 'OWX511', 'NISSAN', 'particular', 412, 412412, 'jetta', 1932, 52505032, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 413 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
778, 'OWX512', 'NISSAN', 'particular', 413, 413413, 'jetta', 1933, 52505033, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 414 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
779, 'OWX513', 'NISSAN', 'particular', 414, 414414, 'jetta', 1934, 52505034, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 415 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
780, 'OWX514', 'NISSAN', 'particular', 415, 415415, 'jetta', 1935, 52505035, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 416 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
781, 'OWX515', 'NISSAN', 'particular', 416, 416416, 'jetta', 1936, 52505036, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 417 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
782, 'OWX516', 'NISSAN', 'particular', 417, 417417, 'jetta', 1937, 52505037, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 418 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
783, 'OWX517', 'NISSAN', 'particular', 418, 418418, 'jetta', 1938, 52505038, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 419 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
784, 'OWX518', 'NISSAN', 'particular', 419, 419419, 'jetta', 1939, 52505039, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 420 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
785, 'OWX519', 'NISSAN', 'particular', 420, 420420, 'jetta', 1940, 52505040, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 421 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
786, 'OWX520', 'NISSAN', 'particular', 421, 421421, 'jetta', 1941, 52505041, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 422 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
787, 'OWX521', 'NISSAN', 'particular', 422, 422422, 'jetta', 1942, 52505042, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 423 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
788, 'OWX522', 'NISSAN', 'particular', 423, 423423, 'jetta', 1943, 52505043, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 424 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
789, 'OWX523', 'NISSAN', 'particular', 424, 424424, 'jetta', 1944, 52505044, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 425 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
790, 'OWX524', 'NISSAN', 'particular', 425, 425425, 'jetta', 1945, 52505045, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 426 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
791, 'OWX525', 'NISSAN', 'particular', 426, 426426, 'jetta', 1946, 52505046, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 427 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
792, 'OWX526', 'NISSAN', 'particular', 427, 427427, 'jetta', 1947, 52505047, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 428 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
793, 'OWX527', 'NISSAN', 'particular', 428, 428428, 'jetta', 1948, 52505048, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 429 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
794, 'OWX528', 'NISSAN', 'particular', 429, 429429, 'jetta', 1949, 52505049, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 430 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
795, 'OWX529', 'NISSAN', 'particular', 430, 430430, 'jetta', 1950, 52505050, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 431 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
796, 'OWX530', 'NISSAN', 'particular', 431, 431431, 'jetta', 1951, 52505051, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 432 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
797, 'OWX531', 'NISSAN', 'particular', 432, 432432, 'jetta', 1952, 52505052, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 433 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
798, 'OWX532', 'NISSAN', 'particular', 433, 433433, 'jetta', 1953, 52505053, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 434 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
799, 'OWX533', 'NISSAN', 'particular', 434, 434434, 'jetta', 1954, 52505054, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 435 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
800, 'OWX534', 'NISSAN', 'particular', 435, 435435, 'jetta', 1955, 52505055, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 436 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
801, 'OWX535', 'NISSAN', 'particular', 436, 436436, 'jetta', 1956, 52505056, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 437 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
802, 'OWX536', 'NISSAN', 'particular', 437, 437437, 'jetta', 1957, 52505057, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 438 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
803, 'OWX537', 'NISSAN', 'particular', 438, 438438, 'jetta', 1958, 52505058, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 439 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
804, 'OWX538', 'NISSAN', 'particular', 439, 439439, 'jetta', 1959, 52505059, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 440 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
805, 'OWX539', 'NISSAN', 'particular', 440, 440440, 'jetta', 1960, 52505060, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 441 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
806, 'OWX540', 'NISSAN', 'particular', 441, 441441, 'jetta', 1961, 52505061, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 442 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
807, 'OWX541', 'NISSAN', 'particular', 442, 442442, 'jetta', 1962, 52505062, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 443 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
808, 'OWX542', 'NISSAN', 'particular', 443, 443443, 'jetta', 1963, 52505063, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 444 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
809, 'OWX543', 'NISSAN', 'particular', 444, 444444, 'jetta', 1964, 52505064, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 445 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
810, 'OWX544', 'NISSAN', 'particular', 445, 445445, 'jetta', 1965, 52505065, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 446 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
811, 'OWX545', 'NISSAN', 'particular', 446, 446446, 'jetta', 1966, 52505066, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 447 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
812, 'OWX546', 'NISSAN', 'particular', 447, 447447, 'jetta', 1967, 52505067, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 448 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
813, 'OWX547', 'NISSAN', 'particular', 448, 448448, 'jetta', 1968, 52505068, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 449 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
814, 'OWX548', 'NISSAN', 'particular', 449, 449449, 'jetta', 1969, 52505069, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 450 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
815, 'OWX549', 'NISSAN', 'particular', 450, 450450, 'jetta', 1970, 52505070, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 451 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
816, 'OWX550', 'NISSAN', 'particular', 451, 451451, 'jetta', 1971, 52505071, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 452 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
817, 'OWX551', 'NISSAN', 'particular', 452, 452452, 'jetta', 1972, 52505072, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 453 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
818, 'OWX552', 'NISSAN', 'particular', 453, 453453, 'jetta', 1973, 52505073, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 454 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
819, 'OWX553', 'NISSAN', 'particular', 454, 454454, 'jetta', 1974, 52505074, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 455 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
820, 'OWX554', 'NISSAN', 'particular', 455, 455455, 'jetta', 1975, 52505075, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 456 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
821, 'OWX555', 'NISSAN', 'particular', 456, 456456, 'jetta', 1976, 52505076, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 457 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
822, 'OWX556', 'NISSAN', 'particular', 457, 457457, 'jetta', 1977, 52505077, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 458 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
823, 'OWX557', 'NISSAN', 'particular', 458, 458458, 'jetta', 1978, 52505078, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 459 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
824, 'OWX558', 'NISSAN', 'particular', 459, 459459, 'jetta', 1979, 52505079, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 460 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
825, 'OWX559', 'NISSAN', 'particular', 460, 460460, 'jetta', 1980, 52505080, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 461 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
826, 'OWX560', 'NISSAN', 'particular', 461, 461461, 'jetta', 1981, 52505081, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 462 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
827, 'OWX561', 'NISSAN', 'particular', 462, 462462, 'jetta', 1982, 52505082, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 463 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
828, 'OWX562', 'NISSAN', 'particular', 463, 463463, 'jetta', 1983, 52505083, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 464 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
829, 'OWX563', 'NISSAN', 'particular', 464, 464464, 'jetta', 1984, 52505084, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 465 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
830, 'OWX564', 'NISSAN', 'particular', 465, 465465, 'jetta', 1985, 52505085, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 466 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
831, 'OWX565', 'NISSAN', 'particular', 466, 466466, 'jetta', 1986, 52505086, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 467 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
832, 'OWX566', 'NISSAN', 'particular', 467, 467467, 'jetta', 1987, 52505087, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 468 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
833, 'OWX567', 'NISSAN', 'particular', 468, 468468, 'jetta', 1988, 52505088, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 469 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
834, 'OWX568', 'NISSAN', 'particular', 469, 469469, 'jetta', 1989, 52505089, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 470 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
835, 'OWX569', 'NISSAN', 'particular', 470, 470470, 'jetta', 1990, 52505090, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 471 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
836, 'OWX570', 'NISSAN', 'particular', 471, 471471, 'jetta', 1991, 52505091, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 472 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
837, 'OWX571', 'NISSAN', 'particular', 472, 472472, 'jetta', 1992, 52505092, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 473 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
838, 'OWX572', 'NISSAN', 'particular', 473, 473473, 'jetta', 1993, 52505093, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 474 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
839, 'OWX573', 'NISSAN', 'particular', 474, 474474, 'jetta', 1994, 52505094, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 475 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
840, 'OWX574', 'NISSAN', 'particular', 475, 475475, 'jetta', 1995, 52505095, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 476 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
841, 'OWX575', 'NISSAN', 'particular', 476, 476476, 'jetta', 1996, 52505096, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 477 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
842, 'OWX576', 'NISSAN', 'particular', 477, 477477, 'jetta', 1997, 52505097, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 478 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
843, 'OWX577', 'NISSAN', 'particular', 478, 478478, 'jetta', 1998, 52505098, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 479 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
844, 'OWX578', 'NISSAN', 'particular', 479, 479479, 'jetta', 1999, 52505099, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 480 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
845, 'OWX579', 'NISSAN', 'particular', 480, 480480, 'jetta', 2000, 52505100, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 481 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
846, 'OWX580', 'NISSAN', 'particular', 481, 481481, 'jetta', 2001, 52505101, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 482 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
847, 'OWX581', 'NISSAN', 'particular', 482, 482482, 'jetta', 2002, 52505102, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 483 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
848, 'OWX582', 'NISSAN', 'particular', 483, 483483, 'jetta', 2003, 52505103, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 484 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
849, 'OWX583', 'NISSAN', 'particular', 484, 484484, 'jetta', 2004, 52505104, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 485 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
850, 'OWX584', 'NISSAN', 'particular', 485, 485485, 'jetta', 2005, 52505105, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 486 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
851, 'OWX585', 'NISSAN', 'particular', 486, 486486, 'jetta', 2006, 52505106, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 487 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
852, 'OWX586', 'NISSAN', 'particular', 487, 487487, 'jetta', 2007, 52505107, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 488 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
853, 'OWX587', 'NISSAN', 'particular', 488, 488488, 'jetta', 2008, 52505108, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 489 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
854, 'OWX588', 'NISSAN', 'particular', 489, 489489, 'jetta', 2009, 52505109, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 490 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
855, 'OWX589', 'NISSAN', 'particular', 490, 490490, 'jetta', 2010, 52505110, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 491 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
856, 'OWX590', 'NISSAN', 'particular', 491, 491491, 'jetta', 2011, 52505111, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 492 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
857, 'OWX591', 'NISSAN', 'particular', 492, 492492, 'jetta', 2012, 52505112, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 493 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
858, 'OWX592', 'NISSAN', 'particular', 493, 493493, 'jetta', 2013, 52505113, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 494 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
859, 'OWX593', 'NISSAN', 'particular', 494, 494494, 'jetta', 2014, 52505114, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 495 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
860, 'OWX594', 'NISSAN', 'particular', 495, 495495, 'jetta', 2015, 52505115, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 496 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
861, 'OWX595', 'NISSAN', 'particular', 496, 496496, 'jetta', 2016, 52505116, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 497 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
862, 'OWX596', 'NISSAN', 'particular', 497, 497497, 'jetta', 2017, 52505117, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 498 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
863, 'OWX597', 'NISSAN', 'particular', 498, 498498, 'jetta', 2018, 52505118, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 499 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
864, 'OWX598', 'NISSAN', 'particular', 499, 499499, 'jetta', 2019, 52505119, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 500 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
865, 'OWX599', 'NISSAN', 'particular', 500, 500500, 'corolla', 1920, 52505120, 4, 1000, 'GASOLINA'
);

/* INSERT QUERY NO: 501 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
866, 'OWX600', 'NISSAN', 'particular', 501, 501501, 'corolla', 1921, 52505121, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 502 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
867, 'OWX601', 'NISSAN', 'particular', 502, 502502, 'corolla', 1922, 52505122, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 503 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
868, 'OWX602', 'NISSAN', 'particular', 503, 503503, 'corolla', 1923, 52505123, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 504 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
869, 'OWX603', 'NISSAN', 'particular', 504, 504504, 'corolla', 1924, 52505124, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 505 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
870, 'OWX604', 'NISSAN', 'particular', 505, 505505, 'corolla', 1925, 52505125, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 506 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
871, 'OWX605', 'NISSAN', 'particular', 506, 506506, 'corolla', 1926, 52505126, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 507 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
872, 'OWX606', 'NISSAN', 'particular', 507, 507507, 'corolla', 1927, 52505127, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 508 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
873, 'OWX607', 'NISSAN', 'particular', 508, 508508, 'corolla', 1928, 52505128, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 509 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
874, 'OWX608', 'NISSAN', 'particular', 509, 509509, 'corolla', 1929, 52505129, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 510 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
875, 'OWX609', 'NISSAN', 'particular', 510, 510510, 'corolla', 1930, 52505130, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 511 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
876, 'OWX610', 'NISSAN', 'particular', 511, 511511, 'corolla', 1931, 52505131, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 512 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
877, 'OWX611', 'NISSAN', 'particular', 512, 512512, 'corolla', 1932, 52505132, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 513 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
878, 'OWX612', 'NISSAN', 'particular', 513, 513513, 'corolla', 1933, 52505133, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 514 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
879, 'OWX613', 'NISSAN', 'particular', 514, 514514, 'corolla', 1934, 52505134, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 515 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
880, 'OWX614', 'NISSAN', 'particular', 515, 515515, 'corolla', 1935, 52505135, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 516 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
881, 'OWX615', 'NISSAN', 'particular', 516, 516516, 'corolla', 1936, 52505136, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 517 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
882, 'OWX616', 'NISSAN', 'particular', 517, 517517, 'corolla', 1937, 52505137, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 518 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
883, 'OWX617', 'NISSAN', 'particular', 518, 518518, 'corolla', 1938, 52505138, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 519 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
884, 'OWX618', 'NISSAN', 'particular', 519, 519519, 'corolla', 1939, 52505139, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 520 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
885, 'OWX619', 'NISSAN', 'particular', 520, 520520, 'corolla', 1940, 52505140, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 521 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
886, 'OWX620', 'NISSAN', 'particular', 521, 521521, 'corolla', 1941, 52505141, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 522 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
887, 'OWX621', 'NISSAN', 'particular', 522, 522522, 'corolla', 1942, 52505142, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 523 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
888, 'OWX622', 'NISSAN', 'particular', 523, 523523, 'corolla', 1943, 52505143, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 524 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
889, 'OWX623', 'NISSAN', 'particular', 524, 524524, 'corolla', 1944, 52505144, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 525 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
890, 'OWX624', 'NISSAN', 'particular', 525, 525525, 'corolla', 1945, 52505145, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 526 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
891, 'OWX625', 'NISSAN', 'particular', 526, 526526, 'corolla', 1946, 52505146, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 527 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
892, 'OWX626', 'NISSAN', 'particular', 527, 527527, 'corolla', 1947, 52505147, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 528 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
893, 'OWX627', 'NISSAN', 'particular', 528, 528528, 'corolla', 1948, 52505148, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 529 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
894, 'OWX628', 'NISSAN', 'particular', 529, 529529, 'corolla', 1949, 52505149, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 530 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
895, 'OWX629', 'NISSAN', 'particular', 530, 530530, 'corolla', 1950, 52505150, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 531 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
896, 'OWX630', 'NISSAN', 'particular', 531, 531531, 'corolla', 1951, 52505151, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 532 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
897, 'OWX631', 'NISSAN', 'particular', 532, 532532, 'corolla', 1952, 52505152, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 533 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
898, 'OWX632', 'NISSAN', 'particular', 533, 533533, 'corolla', 1953, 52505153, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 534 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
899, 'OWX633', 'NISSAN', 'particular', 534, 534534, 'corolla', 1954, 52505154, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 535 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
900, 'OWX634', 'NISSAN', 'particular', 535, 535535, 'corolla', 1955, 52505155, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 536 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
901, 'OWX635', 'NISSAN', 'particular', 536, 536536, 'corolla', 1956, 52505156, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 537 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
902, 'OWX636', 'NISSAN', 'particular', 537, 537537, 'corolla', 1957, 52505157, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 538 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
903, 'OWX637', 'NISSAN', 'particular', 538, 538538, 'corolla', 1958, 52505158, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 539 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
904, 'OWX638', 'NISSAN', 'particular', 539, 539539, 'corolla', 1959, 52505159, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 540 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
905, 'OWX639', 'NISSAN', 'particular', 540, 540540, 'corolla', 1960, 52505160, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 541 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
906, 'OWX640', 'NISSAN', 'particular', 541, 541541, 'corolla', 1961, 52505161, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 542 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
907, 'OWX641', 'NISSAN', 'particular', 542, 542542, 'corolla', 1962, 52505162, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 543 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
908, 'OWX642', 'NISSAN', 'particular', 543, 543543, 'corolla', 1963, 52505163, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 544 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
909, 'OWX643', 'NISSAN', 'particular', 544, 544544, 'corolla', 1964, 52505164, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 545 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
910, 'OWX644', 'NISSAN', 'particular', 545, 545545, 'corolla', 1965, 52505165, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 546 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
911, 'OWX645', 'NISSAN', 'particular', 546, 546546, 'corolla', 1966, 52505166, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 547 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
912, 'OWX646', 'NISSAN', 'particular', 547, 547547, 'corolla', 1967, 52505167, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 548 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
913, 'OWX647', 'NISSAN', 'particular', 548, 548548, 'corolla', 1968, 52505168, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 549 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
914, 'OWX648', 'NISSAN', 'particular', 549, 549549, 'corolla', 1969, 52505169, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 550 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
915, 'OWX649', 'NISSAN', 'particular', 550, 550550, 'corolla', 1970, 52505170, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 551 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
916, 'OWX650', 'NISSAN', 'particular', 551, 551551, 'corolla', 1971, 52505171, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 552 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
917, 'OWX651', 'NISSAN', 'particular', 552, 552552, 'corolla', 1972, 52505172, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 553 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
918, 'OWX652', 'NISSAN', 'particular', 553, 553553, 'corolla', 1973, 52505173, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 554 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
919, 'OWX653', 'NISSAN', 'particular', 554, 554554, 'corolla', 1974, 52505174, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 555 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
920, 'OWX654', 'NISSAN', 'particular', 555, 555555, 'corolla', 1975, 52505175, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 556 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
921, 'OWX655', 'NISSAN', 'particular', 556, 556556, 'corolla', 1976, 52505176, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 557 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
922, 'OWX656', 'NISSAN', 'particular', 557, 557557, 'corolla', 1977, 52505177, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 558 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
923, 'OWX657', 'NISSAN', 'particular', 558, 558558, 'corolla', 1978, 52505178, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 559 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
924, 'OWX658', 'NISSAN', 'particular', 559, 559559, 'corolla', 1979, 52505179, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 560 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
925, 'OWX659', 'NISSAN', 'particular', 560, 560560, 'corolla', 1980, 52505180, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 561 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
926, 'OWX660', 'NISSAN', 'particular', 561, 561561, 'corolla', 1981, 52505181, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 562 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
927, 'OWX661', 'NISSAN', 'particular', 562, 562562, 'corolla', 1982, 52505182, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 563 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
928, 'OWX662', 'NISSAN', 'particular', 563, 563563, 'corolla', 1983, 52505183, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 564 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
929, 'OWX663', 'NISSAN', 'particular', 564, 564564, 'corolla', 1984, 52505184, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 565 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
930, 'OWX664', 'NISSAN', 'particular', 565, 565565, 'corolla', 1985, 52505185, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 566 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
931, 'OWX665', 'NISSAN', 'particular', 566, 566566, 'corolla', 1986, 52505186, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 567 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
932, 'OWX666', 'NISSAN', 'particular', 567, 567567, 'corolla', 1987, 52505187, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 568 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
933, 'OWX667', 'NISSAN', 'particular', 568, 568568, 'corolla', 1988, 52505188, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 569 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
934, 'OWX668', 'NISSAN', 'particular', 569, 569569, 'corolla', 1989, 52505189, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 570 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
935, 'OWX669', 'NISSAN', 'particular', 570, 570570, 'corolla', 1990, 52505190, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 571 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
936, 'OWX670', 'NISSAN', 'particular', 571, 571571, 'corolla', 1991, 52505191, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 572 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
937, 'OWX671', 'NISSAN', 'particular', 572, 572572, 'corolla', 1992, 52505192, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 573 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
938, 'OWX672', 'NISSAN', 'particular', 573, 573573, 'corolla', 1993, 52505193, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 574 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
939, 'OWX673', 'NISSAN', 'particular', 574, 574574, 'corolla', 1994, 52505194, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 575 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
940, 'OWX674', 'NISSAN', 'particular', 575, 575575, 'corolla', 1995, 52505195, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 576 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
941, 'OWX675', 'NISSAN', 'particular', 576, 576576, 'corolla', 1996, 52505196, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 577 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
942, 'OWX676', 'NISSAN', 'particular', 577, 577577, 'corolla', 1997, 52505197, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 578 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
943, 'OWX677', 'NISSAN', 'particular', 578, 578578, 'corolla', 1998, 52505198, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 579 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
944, 'OWX678', 'NISSAN', 'particular', 579, 579579, 'corolla', 1999, 52505199, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 580 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
945, 'OWX679', 'NISSAN', 'particular', 580, 580580, 'corolla', 2000, 52505200, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 581 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
946, 'OWX680', 'NISSAN', 'particular', 581, 581581, 'corolla', 2001, 52505201, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 582 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
947, 'OWX681', 'NISSAN', 'particular', 582, 582582, 'corolla', 2002, 52505202, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 583 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
948, 'OWX682', 'NISSAN', 'particular', 583, 583583, 'corolla', 2003, 52505203, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 584 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
949, 'OWX683', 'NISSAN', 'particular', 584, 584584, 'corolla', 2004, 52505204, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 585 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
950, 'OWX684', 'NISSAN', 'particular', 585, 585585, 'corolla', 2005, 52505205, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 586 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
951, 'OWX685', 'NISSAN', 'particular', 586, 586586, 'corolla', 2006, 52505206, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 587 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
952, 'OWX686', 'NISSAN', 'particular', 587, 587587, 'corolla', 2007, 52505207, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 588 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
953, 'OWX687', 'NISSAN', 'particular', 588, 588588, 'corolla', 2008, 52505208, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 589 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
954, 'OWX688', 'NISSAN', 'particular', 589, 589589, 'corolla', 2009, 52505209, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 590 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
955, 'OWX689', 'NISSAN', 'particular', 590, 590590, 'corolla', 2010, 52505210, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 591 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
956, 'OWX690', 'NISSAN', 'particular', 591, 591591, 'corolla', 2011, 52505211, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 592 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
957, 'OWX691', 'NISSAN', 'particular', 592, 592592, 'corolla', 2012, 52505212, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 593 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
958, 'OWX692', 'NISSAN', 'particular', 593, 593593, 'corolla', 2013, 52505213, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 594 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
959, 'OWX693', 'NISSAN', 'particular', 594, 594594, 'corolla', 2014, 52505214, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 595 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
960, 'OWX694', 'NISSAN', 'particular', 595, 595595, 'corolla', 2015, 52505215, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 596 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
961, 'OWX695', 'NISSAN', 'particular', 596, 596596, 'corolla', 2016, 52505216, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 597 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
962, 'OWX696', 'NISSAN', 'particular', 597, 597597, 'corolla', 2017, 52505217, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 598 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
963, 'OWX697', 'NISSAN', 'particular', 598, 598598, 'corolla', 2018, 52505218, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 599 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
964, 'OWX698', 'NISSAN', 'particular', 599, 599599, 'corolla', 2019, 52505219, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 600 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
965, 'OWX699', 'NISSAN', 'particular', 600, 600600, 'fusion', 1920, 52505220, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 601 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
966, 'OWX700', 'KIA', 'particular', 601, 601601, 'fusion', 1921, 52505221, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 602 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
967, 'OWX701', 'KIA', 'particular', 602, 602602, 'fusion', 1922, 52505222, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 603 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
968, 'OWX702', 'KIA', 'particular', 603, 603603, 'fusion', 1923, 52505223, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 604 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
969, 'OWX703', 'KIA', 'particular', 604, 604604, 'fusion', 1924, 52505224, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 605 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
970, 'OWX704', 'KIA', 'particular', 605, 605605, 'fusion', 1925, 52505225, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 606 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
971, 'OWX705', 'KIA', 'particular', 606, 606606, 'fusion', 1926, 52505226, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 607 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
972, 'OWX706', 'KIA', 'particular', 607, 607607, 'fusion', 1927, 52505227, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 608 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
973, 'OWX707', 'KIA', 'particular', 608, 608608, 'fusion', 1928, 52505228, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 609 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
974, 'OWX708', 'KIA', 'particular', 609, 609609, 'fusion', 1929, 52505229, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 610 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
975, 'OWX709', 'KIA', 'particular', 610, 610610, 'fusion', 1930, 52505230, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 611 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
976, 'OWX710', 'KIA', 'particular', 611, 611611, 'fusion', 1931, 52505231, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 612 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
977, 'OWX711', 'KIA', 'particular', 612, 612612, 'fusion', 1932, 52505232, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 613 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
978, 'OWX712', 'KIA', 'particular', 613, 613613, 'fusion', 1933, 52505233, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 614 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
979, 'OWX713', 'KIA', 'particular', 614, 614614, 'fusion', 1934, 52505234, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 615 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
980, 'OWX714', 'KIA', 'particular', 615, 615615, 'fusion', 1935, 52505235, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 616 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
981, 'OWX715', 'KIA', 'particular', 616, 616616, 'fusion', 1936, 52505236, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 617 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
982, 'OWX716', 'KIA', 'particular', 617, 617617, 'fusion', 1937, 52505237, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 618 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
983, 'OWX717', 'KIA', 'particular', 618, 618618, 'fusion', 1938, 52505238, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 619 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
984, 'OWX718', 'KIA', 'particular', 619, 619619, 'fusion', 1939, 52505239, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 620 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
985, 'OWX719', 'KIA', 'particular', 620, 620620, 'fusion', 1940, 52505240, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 621 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
986, 'OWX720', 'KIA', 'particular', 621, 621621, 'fusion', 1941, 52505241, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 622 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
987, 'OWX721', 'KIA', 'particular', 622, 622622, 'fusion', 1942, 52505242, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 623 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
988, 'OWX722', 'KIA', 'particular', 623, 623623, 'fusion', 1943, 52505243, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 624 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
989, 'OWX723', 'KIA', 'particular', 624, 624624, 'fusion', 1944, 52505244, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 625 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
990, 'OWX724', 'KIA', 'particular', 625, 625625, 'fusion', 1945, 52505245, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 626 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
991, 'OWX725', 'KIA', 'particular', 626, 626626, 'fusion', 1946, 52505246, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 627 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
992, 'OWX726', 'KIA', 'particular', 627, 627627, 'fusion', 1947, 52505247, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 628 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
993, 'OWX727', 'KIA', 'particular', 628, 628628, 'fusion', 1948, 52505248, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 629 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
994, 'OWX728', 'KIA', 'particular', 629, 629629, 'fusion', 1949, 52505249, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 630 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
995, 'OWX729', 'KIA', 'particular', 630, 630630, 'fusion', 1950, 52505250, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 631 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
996, 'OWX730', 'KIA', 'particular', 631, 631631, 'fusion', 1951, 52505251, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 632 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
997, 'OWX731', 'KIA', 'particular', 632, 632632, 'fusion', 1952, 52505252, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 633 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
998, 'OWX732', 'KIA', 'particular', 633, 633633, 'fusion', 1953, 52505253, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 634 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
999, 'OWX733', 'KIA', 'particular', 634, 634634, 'fusion', 1954, 52505254, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 635 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1000, 'OWX734', 'KIA', 'particular', 635, 635635, 'fusion', 1955, 52505255, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 636 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1001, 'OWX735', 'KIA', 'particular', 636, 636636, 'fusion', 1956, 52505256, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 637 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1002, 'OWX736', 'KIA', 'particular', 637, 637637, 'fusion', 1957, 52505257, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 638 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1003, 'OWX737', 'KIA', 'particular', 638, 638638, 'fusion', 1958, 52505258, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 639 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1004, 'OWX738', 'KIA', 'particular', 639, 639639, 'fusion', 1959, 52505259, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 640 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1005, 'OWX739', 'KIA', 'particular', 640, 640640, 'fusion', 1960, 52505260, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 641 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1006, 'OWX740', 'KIA', 'particular', 641, 641641, 'fusion', 1961, 52505261, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 642 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1007, 'OWX741', 'KIA', 'particular', 642, 642642, 'fusion', 1962, 52505262, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 643 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1008, 'OWX742', 'KIA', 'particular', 643, 643643, 'fusion', 1963, 52505263, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 644 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1009, 'OWX743', 'KIA', 'particular', 644, 644644, 'fusion', 1964, 52505264, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 645 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1010, 'OWX744', 'KIA', 'particular', 645, 645645, 'fusion', 1965, 52505265, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 646 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1011, 'OWX745', 'KIA', 'particular', 646, 646646, 'fusion', 1966, 52505266, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 647 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1012, 'OWX746', 'KIA', 'particular', 647, 647647, 'fusion', 1967, 52505267, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 648 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1013, 'OWX747', 'KIA', 'particular', 648, 648648, 'fusion', 1968, 52505268, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 649 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1014, 'OWX748', 'KIA', 'particular', 649, 649649, 'fusion', 1969, 52505269, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 650 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1015, 'OWX749', 'KIA', 'particular', 650, 650650, 'fusion', 1970, 52505270, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 651 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1016, 'OWX750', 'KIA', 'particular', 651, 651651, 'fusion', 1971, 52505271, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 652 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1017, 'OWX751', 'KIA', 'particular', 652, 652652, 'fusion', 1972, 52505272, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 653 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1018, 'OWX752', 'KIA', 'particular', 653, 653653, 'fusion', 1973, 52505273, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 654 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1019, 'OWX753', 'KIA', 'particular', 654, 654654, 'fusion', 1974, 52505274, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 655 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1020, 'OWX754', 'KIA', 'particular', 655, 655655, 'fusion', 1975, 52505275, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 656 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1021, 'OWX755', 'KIA', 'particular', 656, 656656, 'fusion', 1976, 52505276, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 657 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1022, 'OWX756', 'KIA', 'particular', 657, 657657, 'fusion', 1977, 52505277, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 658 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1023, 'OWX757', 'KIA', 'particular', 658, 658658, 'fusion', 1978, 52505278, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 659 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1024, 'OWX758', 'KIA', 'particular', 659, 659659, 'fusion', 1979, 52505279, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 660 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1025, 'OWX759', 'KIA', 'particular', 660, 660660, 'fusion', 1980, 52505280, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 661 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1026, 'OWX760', 'KIA', 'particular', 661, 661661, 'fusion', 1981, 52505281, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 662 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1027, 'OWX761', 'KIA', 'particular', 662, 662662, 'fusion', 1982, 52505282, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 663 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1028, 'OWX762', 'KIA', 'particular', 663, 663663, 'fusion', 1983, 52505283, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 664 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1029, 'OWX763', 'KIA', 'particular', 664, 664664, 'fusion', 1984, 52505284, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 665 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1030, 'OWX764', 'KIA', 'particular', 665, 665665, 'fusion', 1985, 52505285, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 666 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1031, 'OWX765', 'KIA', 'particular', 666, 666666, 'fusion', 1986, 52505286, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 667 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1032, 'OWX766', 'KIA', 'particular', 667, 667667, 'fusion', 1987, 52505287, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 668 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1033, 'OWX767', 'KIA', 'particular', 668, 668668, 'fusion', 1988, 52505288, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 669 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1034, 'OWX768', 'KIA', 'particular', 669, 669669, 'fusion', 1989, 52505289, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 670 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1035, 'OWX769', 'KIA', 'particular', 670, 670670, 'fusion', 1990, 52505290, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 671 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1036, 'OWX770', 'KIA', 'particular', 671, 671671, 'fusion', 1991, 52505291, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 672 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1037, 'OWX771', 'KIA', 'particular', 672, 672672, 'fusion', 1992, 52505292, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 673 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1038, 'OWX772', 'KIA', 'particular', 673, 673673, 'fusion', 1993, 52505293, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 674 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1039, 'OWX773', 'KIA', 'particular', 674, 674674, 'fusion', 1994, 52505294, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 675 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1040, 'OWX774', 'KIA', 'particular', 675, 675675, 'fusion', 1995, 52505295, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 676 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1041, 'OWX775', 'KIA', 'particular', 676, 676676, 'fusion', 1996, 52505296, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 677 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1042, 'OWX776', 'KIA', 'particular', 677, 677677, 'fusion', 1997, 52505297, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 678 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1043, 'OWX777', 'KIA', 'particular', 678, 678678, 'fusion', 1998, 52505298, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 679 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1044, 'OWX778', 'KIA', 'particular', 679, 679679, 'fusion', 1999, 52505299, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 680 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1045, 'OWX779', 'KIA', 'particular', 680, 680680, 'fusion', 2000, 52505300, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 681 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1046, 'OWX780', 'KIA', 'diplomaticos', 681, 681681, 'fusion', 2001, 52505301, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 682 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1047, 'OWX781', 'KIA', 'diplomaticos', 682, 682682, 'fusion', 2002, 52505302, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 683 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1048, 'OWX782', 'KIA', 'diplomaticos', 683, 683683, 'fusion', 2003, 52505303, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 684 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1049, 'OWX783', 'KIA', 'diplomaticos', 684, 684684, 'fusion', 2004, 52505304, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 685 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1050, 'OWX784', 'KIA', 'diplomaticos', 685, 685685, 'fusion', 2005, 52505305, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 686 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1051, 'OWX785', 'KIA', 'diplomaticos', 686, 686686, 'fusion', 2006, 52505306, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 687 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1052, 'OWX786', 'KIA', 'diplomaticos', 687, 687687, 'fusion', 2007, 52505307, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 688 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1053, 'OWX787', 'KIA', 'diplomaticos', 688, 688688, 'fusion', 2008, 52505308, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 689 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1054, 'OWX788', 'KIA', 'diplomaticos', 689, 689689, 'fusion', 2009, 52505309, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 690 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1055, 'OWX789', 'KIA', 'diplomaticos', 690, 690690, 'fusion', 2010, 52505310, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 691 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1056, 'OWX790', 'KIA', 'diplomaticos', 691, 691691, 'fusion', 2011, 52505311, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 692 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1057, 'OWX791', 'KIA', 'diplomaticos', 692, 692692, 'fusion', 2012, 52505312, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 693 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1058, 'OWX792', 'KIA', 'diplomaticos', 693, 693693, 'fusion', 2013, 52505313, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 694 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1059, 'OWX793', 'KIA', 'diplomaticos', 694, 694694, 'fusion', 2014, 52505314, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 695 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1060, 'OWX794', 'KIA', 'diplomaticos', 695, 695695, 'fusion', 2015, 52505315, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 696 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1061, 'OWX795', 'KIA', 'diplomaticos', 696, 696696, 'fusion', 2016, 52505316, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 697 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1062, 'OWX796', 'KIA', 'diplomaticos', 697, 697697, 'fusion', 2017, 52505317, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 698 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1063, 'OWX797', 'KIA', 'diplomaticos', 698, 698698, 'fusion', 2018, 52505318, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 699 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1064, 'OWX798', 'KIA', 'diplomaticos', 699, 699699, 'fusion', 2019, 52505319, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 700 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1065, 'OWX799', 'KIA', 'diplomaticos', 700, 700700, 'fiesta', 1920, 52505320, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 701 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1066, 'OWX800', 'KIA', 'diplomaticos', 701, 701701, 'fiesta', 1921, 52505321, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 702 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1067, 'OWX801', 'KIA', 'diplomaticos', 702, 702702, 'fiesta', 1922, 52505322, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 703 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1068, 'OWX802', 'KIA', 'diplomaticos', 703, 703703, 'fiesta', 1923, 52505323, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 704 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1069, 'OWX803', 'KIA', 'diplomaticos', 704, 704704, 'fiesta', 1924, 52505324, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 705 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1070, 'OWX804', 'KIA', 'diplomaticos', 705, 705705, 'fiesta', 1925, 52505325, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 706 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1071, 'OWX805', 'KIA', 'diplomaticos', 706, 706706, 'fiesta', 1926, 52505326, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 707 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1072, 'OWX806', 'KIA', 'diplomaticos', 707, 707707, 'fiesta', 1927, 52505327, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 708 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1073, 'OWX807', 'KIA', 'diplomaticos', 708, 708708, 'fiesta', 1928, 52505328, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 709 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1074, 'OWX808', 'KIA', 'diplomaticos', 709, 709709, 'fiesta', 1929, 52505329, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 710 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1075, 'OWX809', 'KIA', 'diplomaticos', 710, 710710, 'fiesta', 1930, 52505330, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 711 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1076, 'OWX810', 'KIA', 'diplomaticos', 711, 711711, 'fiesta', 1931, 52505331, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 712 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1077, 'OWX811', 'KIA', 'diplomaticos', 712, 712712, 'fiesta', 1932, 52505332, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 713 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1078, 'OWX812', 'KIA', 'diplomaticos', 713, 713713, 'fiesta', 1933, 52505333, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 714 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1079, 'OWX813', 'KIA', 'diplomaticos', 714, 714714, 'fiesta', 1934, 52505334, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 715 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1080, 'OWX814', 'KIA', 'diplomaticos', 715, 715715, 'fiesta', 1935, 52505335, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 716 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1081, 'OWX815', 'KIA', 'diplomaticos', 716, 716716, 'fiesta', 1936, 52505336, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 717 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1082, 'OWX816', 'KIA', 'diplomaticos', 717, 717717, 'fiesta', 1937, 52505337, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 718 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1083, 'OWX817', 'KIA', 'diplomaticos', 718, 718718, 'fiesta', 1938, 52505338, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 719 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1084, 'OWX818', 'KIA', 'diplomaticos', 719, 719719, 'fiesta', 1939, 52505339, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 720 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1085, 'OWX819', 'KIA', 'diplomaticos', 720, 720720, 'fiesta', 1940, 52505340, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 721 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1086, 'OWX820', 'KIA', 'diplomaticos', 721, 721721, 'fiesta', 1941, 52505341, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 722 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1087, 'OWX821', 'KIA', 'diplomaticos', 722, 722722, 'fiesta', 1942, 52505342, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 723 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1088, 'OWX822', 'KIA', 'diplomaticos', 723, 723723, 'fiesta', 1943, 52505343, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 724 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1089, 'OWX823', 'KIA', 'diplomaticos', 724, 724724, 'fiesta', 1944, 52505344, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 725 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1090, 'OWX824', 'KIA', 'diplomaticos', 725, 725725, 'fiesta', 1945, 52505345, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 726 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1091, 'OWX825', 'KIA', 'diplomaticos', 726, 726726, 'fiesta', 1946, 52505346, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 727 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1092, 'OWX826', 'KIA', 'diplomaticos', 727, 727727, 'fiesta', 1947, 52505347, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 728 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1093, 'OWX827', 'KIA', 'diplomaticos', 728, 728728, 'fiesta', 1948, 52505348, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 729 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1094, 'OWX828', 'KIA', 'diplomaticos', 729, 729729, 'fiesta', 1949, 52505349, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 730 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1095, 'OWX829', 'KIA', 'diplomaticos', 730, 730730, 'fiesta', 1950, 52505350, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 731 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1096, 'OWX830', 'KIA', 'diplomaticos', 731, 731731, 'fiesta', 1951, 52505351, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 732 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1097, 'OWX831', 'KIA', 'diplomaticos', 732, 732732, 'fiesta', 1952, 52505352, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 733 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1098, 'OWX832', 'KIA', 'diplomaticos', 733, 733733, 'fiesta', 1953, 52505353, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 734 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1099, 'OWX833', 'KIA', 'diplomaticos', 734, 734734, 'fiesta', 1954, 52505354, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 735 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1100, 'OWX834', 'KIA', 'diplomaticos', 735, 735735, 'fiesta', 1955, 52505355, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 736 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1101, 'OWX835', 'KIA', 'diplomaticos', 736, 736736, 'fiesta', 1956, 52505356, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 737 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1102, 'OWX836', 'KIA', 'diplomaticos', 737, 737737, 'fiesta', 1957, 52505357, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 738 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1103, 'OWX837', 'KIA', 'diplomaticos', 738, 738738, 'fiesta', 1958, 52505358, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 739 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1104, 'OWX838', 'KIA', 'diplomaticos', 739, 739739, 'fiesta', 1959, 52505359, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 740 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1105, 'OWX839', 'KIA', 'diplomaticos', 740, 740740, 'fiesta', 1960, 52505360, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 741 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1106, 'OWX840', 'KIA', 'diplomaticos', 741, 741741, 'fiesta', 1961, 52505361, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 742 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1107, 'OWX841', 'KIA', 'diplomaticos', 742, 742742, 'fiesta', 1962, 52505362, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 743 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1108, 'OWX842', 'KIA', 'diplomaticos', 743, 743743, 'fiesta', 1963, 52505363, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 744 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1109, 'OWX843', 'KIA', 'diplomaticos', 744, 744744, 'fiesta', 1964, 52505364, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 745 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1110, 'OWX844', 'KIA', 'diplomaticos', 745, 745745, 'fiesta', 1965, 52505365, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 746 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1111, 'OWX845', 'KIA', 'diplomaticos', 746, 746746, 'fiesta', 1966, 52505366, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 747 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1112, 'OWX846', 'KIA', 'diplomaticos', 747, 747747, 'fiesta', 1967, 52505367, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 748 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1113, 'OWX847', 'KIA', 'diplomaticos', 748, 748748, 'fiesta', 1968, 52505368, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 749 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1114, 'OWX848', 'KIA', 'diplomaticos', 749, 749749, 'fiesta', 1969, 52505369, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 750 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1115, 'OWX849', 'KIA', 'diplomaticos', 750, 750750, 'fiesta', 1970, 52505370, 6, 1500, 'GASOLINA'
);

/* INSERT QUERY NO: 751 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1116, 'OWX850', 'KIA', 'diplomaticos', 751, 751751, 'fiesta', 1971, 52505371, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 752 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1117, 'OWX851', 'KIA', 'diplomaticos', 752, 752752, 'fiesta', 1972, 52505372, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 753 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1118, 'OWX852', 'KIA', 'diplomaticos', 753, 753753, 'fiesta', 1973, 52505373, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 754 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1119, 'OWX853', 'KIA', 'diplomaticos', 754, 754754, 'fiesta', 1974, 52505374, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 755 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1120, 'OWX854', 'KIA', 'diplomaticos', 755, 755755, 'fiesta', 1975, 52505375, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 756 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1121, 'OWX855', 'KIA', 'diplomaticos', 756, 756756, 'fiesta', 1976, 52505376, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 757 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1122, 'OWX856', 'KIA', 'diplomaticos', 757, 757757, 'fiesta', 1977, 52505377, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 758 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1123, 'OWX857', 'KIA', 'diplomaticos', 758, 758758, 'fiesta', 1978, 52505378, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 759 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1124, 'OWX858', 'KIA', 'diplomaticos', 759, 759759, 'fiesta', 1979, 52505379, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 760 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1125, 'OWX859', 'KIA', 'diplomaticos', 760, 760760, 'fiesta', 1980, 52505380, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 761 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1126, 'OWX860', 'KIA', 'diplomaticos', 761, 761761, 'fiesta', 1981, 52505381, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 762 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1127, 'OWX861', 'KIA', 'diplomaticos', 762, 762762, 'fiesta', 1982, 52505382, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 763 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1128, 'OWX862', 'KIA', 'diplomaticos', 763, 763763, 'fiesta', 1983, 52505383, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 764 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1129, 'OWX863', 'KIA', 'diplomaticos', 764, 764764, 'fiesta', 1984, 52505384, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 765 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1130, 'OWX864', 'KIA', 'diplomaticos', 765, 765765, 'fiesta', 1985, 52505385, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 766 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1131, 'OWX865', 'KIA', 'diplomaticos', 766, 766766, 'fiesta', 1986, 52505386, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 767 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1132, 'OWX866', 'KIA', 'diplomaticos', 767, 767767, 'fiesta', 1987, 52505387, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 768 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1133, 'OWX867', 'KIA', 'diplomaticos', 768, 768768, 'fiesta', 1988, 52505388, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 769 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1134, 'OWX868', 'KIA', 'diplomaticos', 769, 769769, 'fiesta', 1989, 52505389, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 770 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1135, 'OWX869', 'KIA', 'diplomaticos', 770, 770770, 'fiesta', 1990, 52505390, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 771 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1136, 'OWX870', 'KIA', 'diplomaticos', 771, 771771, 'fiesta', 1991, 52505391, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 772 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1137, 'OWX871', 'KIA', 'diplomaticos', 772, 772772, 'fiesta', 1992, 52505392, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 773 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1138, 'OWX872', 'KIA', 'diplomaticos', 773, 773773, 'fiesta', 1993, 52505393, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 774 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1139, 'OWX873', 'KIA', 'diplomaticos', 774, 774774, 'fiesta', 1994, 52505394, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 775 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1140, 'OWX874', 'KIA', 'diplomaticos', 775, 775775, 'fiesta', 1995, 52505395, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 776 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1141, 'OWX875', 'KIA', 'diplomaticos', 776, 776776, 'fiesta', 1996, 52505396, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 777 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1142, 'OWX876', 'KIA', 'diplomaticos', 777, 777777, 'fiesta', 1997, 52505397, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 778 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1143, 'OWX877', 'KIA', 'diplomaticos', 778, 778778, 'fiesta', 1998, 52505398, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 779 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1144, 'OWX878', 'KIA', 'diplomaticos', 779, 779779, 'fiesta', 1999, 52505399, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 780 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1145, 'OWX879', 'KIA', 'diplomaticos', 780, 780780, 'fiesta', 2000, 52505400, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 781 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1146, 'OWX880', 'KIA', 'diplomaticos', 781, 781781, 'fiesta', 2001, 52505401, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 782 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1147, 'OWX881', 'KIA', 'diplomaticos', 782, 782782, 'fiesta', 2002, 52505402, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 783 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1148, 'OWX882', 'KIA', 'diplomaticos', 783, 783783, 'fiesta', 2003, 52505403, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 784 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1149, 'OWX883', 'KIA', 'diplomaticos', 784, 784784, 'fiesta', 2004, 52505404, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 785 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1150, 'OWX884', 'KIA', 'diplomaticos', 785, 785785, 'fiesta', 2005, 52505405, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 786 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1151, 'OWX885', 'KIA', 'diplomaticos', 786, 786786, 'fiesta', 2006, 52505406, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 787 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1152, 'OWX886', 'KIA', 'diplomaticos', 787, 787787, 'fiesta', 2007, 52505407, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 788 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1153, 'OWX887', 'KIA', 'diplomaticos', 788, 788788, 'fiesta', 2008, 52505408, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 789 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1154, 'OWX888', 'KIA', 'diplomaticos', 789, 789789, 'fiesta', 2009, 52505409, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 790 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1155, 'OWX889', 'KIA', 'diplomaticos', 790, 790790, 'fiesta', 2010, 52505410, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 791 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1156, 'OWX890', 'KIA', 'diplomaticos', 791, 791791, 'fiesta', 2011, 52505411, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 792 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1157, 'OWX891', 'KIA', 'diplomaticos', 792, 792792, 'fiesta', 2012, 52505412, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 793 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1158, 'OWX892', 'KIA', 'diplomaticos', 793, 793793, 'fiesta', 2013, 52505413, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 794 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1159, 'OWX893', 'KIA', 'diplomaticos', 794, 794794, 'fiesta', 2014, 52505414, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 795 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1160, 'OWX894', 'KIA', 'diplomaticos', 795, 795795, 'fiesta', 2015, 52505415, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 796 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1161, 'OWX895', 'KIA', 'diplomaticos', 796, 796796, 'fiesta', 2016, 52505416, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 797 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1162, 'OWX896', 'KIA', 'diplomaticos', 797, 797797, 'fiesta', 2017, 52505417, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 798 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1163, 'OWX897', 'KIA', 'diplomaticos', 798, 798798, 'fiesta', 2018, 52505418, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 799 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1164, 'OWX898', 'KIA', 'diplomaticos', 799, 799799, 'fiesta', 2019, 52505419, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 800 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1165, 'OWX899', 'KIA', 'diplomaticos', 800, 800800, 'I-10', 1920, 52505420, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 801 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1166, 'OWX900', 'MAZDA', 'diplomaticos', 801, 801801, 'I-10', 1921, 52505421, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 802 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1167, 'OWX901', 'MAZDA', 'diplomaticos', 802, 802802, 'I-10', 1922, 52505422, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 803 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1168, 'OWX902', 'MAZDA', 'diplomaticos', 803, 803803, 'I-10', 1923, 52505423, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 804 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1169, 'OWX903', 'MAZDA', 'diplomaticos', 804, 804804, 'I-10', 1924, 52505424, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 805 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1170, 'OWX904', 'MAZDA', 'diplomaticos', 805, 805805, 'I-10', 1925, 52505425, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 806 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1171, 'OWX905', 'MAZDA', 'diplomaticos', 806, 806806, 'I-10', 1926, 52505426, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 807 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1172, 'OWX906', 'MAZDA', 'diplomaticos', 807, 807807, 'I-10', 1927, 52505427, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 808 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1173, 'OWX907', 'MAZDA', 'diplomaticos', 808, 808808, 'I-10', 1928, 52505428, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 809 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1174, 'OWX908', 'MAZDA', 'diplomaticos', 809, 809809, 'I-10', 1929, 52505429, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 810 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1175, 'OWX909', 'MAZDA', 'diplomaticos', 810, 810810, 'I-10', 1930, 52505430, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 811 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1176, 'OWX910', 'MAZDA', 'diplomaticos', 811, 811811, 'I-10', 1931, 52505431, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 812 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1177, 'OWX911', 'MAZDA', 'diplomaticos', 812, 812812, 'I-10', 1932, 52505432, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 813 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1178, 'OWX912', 'MAZDA', 'diplomaticos', 813, 813813, 'I-10', 1933, 52505433, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 814 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1179, 'OWX913', 'MAZDA', 'diplomaticos', 814, 814814, 'I-10', 1934, 52505434, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 815 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1180, 'OWX914', 'MAZDA', 'diplomaticos', 815, 815815, 'I-10', 1935, 52505435, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 816 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1181, 'OWX915', 'MAZDA', 'diplomaticos', 816, 816816, 'I-10', 1936, 52505436, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 817 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1182, 'OWX916', 'MAZDA', 'diplomaticos', 817, 817817, 'I-10', 1937, 52505437, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 818 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1183, 'OWX917', 'MAZDA', 'diplomaticos', 818, 818818, 'I-10', 1938, 52505438, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 819 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1184, 'OWX918', 'MAZDA', 'diplomaticos', 819, 819819, 'I-10', 1939, 52505439, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 820 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1185, 'OWX919', 'MAZDA', 'diplomaticos', 820, 820820, 'I-10', 1940, 52505440, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 821 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1186, 'OWX920', 'MAZDA', 'diplomaticos', 821, 821821, 'I-10', 1941, 52505441, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 822 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1187, 'OWX921', 'MAZDA', 'diplomaticos', 822, 822822, 'I-10', 1942, 52505442, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 823 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1188, 'OWX922', 'MAZDA', 'diplomaticos', 823, 823823, 'I-10', 1943, 52505443, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 824 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1189, 'OWX923', 'MAZDA', 'diplomaticos', 824, 824824, 'I-10', 1944, 52505444, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 825 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1190, 'OWX924', 'MAZDA', 'diplomaticos', 825, 825825, 'I-10', 1945, 52505445, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 826 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1191, 'OWX925', 'MAZDA', 'diplomaticos', 826, 826826, 'I-10', 1946, 52505446, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 827 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1192, 'OWX926', 'MAZDA', 'diplomaticos', 827, 827827, 'I-10', 1947, 52505447, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 828 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1193, 'OWX927', 'MAZDA', 'diplomaticos', 828, 828828, 'I-10', 1948, 52505448, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 829 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1194, 'OWX928', 'MAZDA', 'diplomaticos', 829, 829829, 'I-10', 1949, 52505449, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 830 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1195, 'OWX929', 'MAZDA', 'diplomaticos', 830, 830830, 'I-10', 1950, 52505450, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 831 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1196, 'OWX930', 'MAZDA', 'diplomaticos', 831, 831831, 'I-10', 1951, 52505451, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 832 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1197, 'OWX931', 'MAZDA', 'diplomaticos', 832, 832832, 'I-10', 1952, 52505452, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 833 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1198, 'OWX932', 'MAZDA', 'diplomaticos', 833, 833833, 'I-10', 1953, 52505453, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 834 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1199, 'OWX933', 'MAZDA', 'diplomaticos', 834, 834834, 'I-10', 1954, 52505454, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 835 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1200, 'OWX934', 'MAZDA', 'diplomaticos', 835, 835835, 'I-10', 1955, 52505455, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 836 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1201, 'OWX935', 'MAZDA', 'diplomaticos', 836, 836836, 'I-10', 1956, 52505456, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 837 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1202, 'OWX936', 'MAZDA', 'diplomaticos', 837, 837837, 'I-10', 1957, 52505457, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 838 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1203, 'OWX937', 'MAZDA', 'diplomaticos', 838, 838838, 'I-10', 1958, 52505458, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 839 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1204, 'OWX938', 'MAZDA', 'diplomaticos', 839, 839839, 'I-10', 1959, 52505459, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 840 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1205, 'OWX939', 'MAZDA', 'diplomaticos', 840, 840840, 'I-10', 1960, 52505460, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 841 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1206, 'OWX940', 'MAZDA', 'diplomaticos', 841, 841841, 'I-10', 1961, 52505461, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 842 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1207, 'OWX941', 'MAZDA', 'diplomaticos', 842, 842842, 'I-10', 1962, 52505462, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 843 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1208, 'OWX942', 'MAZDA', 'diplomaticos', 843, 843843, 'I-10', 1963, 52505463, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 844 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1209, 'OWX943', 'MAZDA', 'diplomaticos', 844, 844844, 'I-10', 1964, 52505464, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 845 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1210, 'OWX944', 'MAZDA', 'diplomaticos', 845, 845845, 'I-10', 1965, 52505465, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 846 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1211, 'OWX945', 'MAZDA', 'diplomaticos', 846, 846846, 'I-10', 1966, 52505466, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 847 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1212, 'OWX946', 'MAZDA', 'diplomaticos', 847, 847847, 'I-10', 1967, 52505467, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 848 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1213, 'OWX947', 'MAZDA', 'diplomaticos', 848, 848848, 'I-10', 1968, 52505468, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 849 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1214, 'OWX948', 'MAZDA', 'diplomaticos', 849, 849849, 'I-10', 1969, 52505469, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 850 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1215, 'OWX949', 'MAZDA', 'diplomaticos', 850, 850850, 'I-10', 1970, 52505470, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 851 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1216, 'OWX950', 'MAZDA', 'diplomaticos', 851, 851851, 'I-10', 1971, 52505471, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 852 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1217, 'OWX951', 'MAZDA', 'diplomaticos', 852, 852852, 'I-10', 1972, 52505472, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 853 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1218, 'OWX952', 'MAZDA', 'diplomaticos', 853, 853853, 'I-10', 1973, 52505473, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 854 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1219, 'OWX953', 'MAZDA', 'diplomaticos', 854, 854854, 'I-10', 1974, 52505474, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 855 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1220, 'OWX954', 'MAZDA', 'diplomaticos', 855, 855855, 'I-10', 1975, 52505475, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 856 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1221, 'OWX955', 'MAZDA', 'diplomaticos', 856, 856856, 'I-10', 1976, 52505476, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 857 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1222, 'OWX956', 'MAZDA', 'diplomaticos', 857, 857857, 'I-10', 1977, 52505477, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 858 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1223, 'OWX957', 'MAZDA', 'diplomaticos', 858, 858858, 'I-10', 1978, 52505478, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 859 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1224, 'OWX958', 'MAZDA', 'diplomaticos', 859, 859859, 'I-10', 1979, 52505479, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 860 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1225, 'OWX959', 'MAZDA', 'diplomaticos', 860, 860860, 'I-10', 1980, 52505480, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 861 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1226, 'OWX960', 'MAZDA', 'diplomaticos', 861, 861861, 'I-10', 1981, 52505481, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 862 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1227, 'OWX961', 'MAZDA', 'diplomaticos', 862, 862862, 'I-10', 1982, 52505482, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 863 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1228, 'OWX962', 'MAZDA', 'diplomaticos', 863, 863863, 'I-10', 1983, 52505483, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 864 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1229, 'OWX963', 'MAZDA', 'diplomaticos', 864, 864864, 'I-10', 1984, 52505484, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 865 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1230, 'OWX964', 'MAZDA', 'diplomaticos', 865, 865865, 'I-10', 1985, 52505485, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 866 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1231, 'OWX965', 'MAZDA', 'diplomaticos', 866, 866866, 'I-10', 1986, 52505486, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 867 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1232, 'OWX966', 'MAZDA', 'diplomaticos', 867, 867867, 'I-10', 1987, 52505487, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 868 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1233, 'OWX967', 'MAZDA', 'diplomaticos', 868, 868868, 'I-10', 1988, 52505488, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 869 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1234, 'OWX968', 'MAZDA', 'diplomaticos', 869, 869869, 'I-10', 1989, 52505489, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 870 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1235, 'OWX969', 'MAZDA', 'diplomaticos', 870, 870870, 'I-10', 1990, 52505490, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 871 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1236, 'OWX970', 'MAZDA', 'diplomaticos', 871, 871871, 'I-10', 1991, 52505491, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 872 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1237, 'OWX971', 'MAZDA', 'diplomaticos', 872, 872872, 'I-10', 1992, 52505492, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 873 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1238, 'OWX972', 'MAZDA', 'diplomaticos', 873, 873873, 'I-10', 1993, 52505493, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 874 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1239, 'OWX973', 'MAZDA', 'diplomaticos', 874, 874874, 'I-10', 1994, 52505494, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 875 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1240, 'OWX974', 'MAZDA', 'diplomaticos', 875, 875875, 'I-10', 1995, 52505495, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 876 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1241, 'OWX975', 'MAZDA', 'diplomaticos', 876, 876876, 'I-10', 1996, 52505496, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 877 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1242, 'OWX976', 'MAZDA', 'diplomaticos', 877, 877877, 'I-10', 1997, 52505497, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 878 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1243, 'OWX977', 'MAZDA', 'diplomaticos', 878, 878878, 'I-10', 1998, 52505498, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 879 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1244, 'OWX978', 'MAZDA', 'diplomaticos', 879, 879879, 'I-10', 1999, 52505499, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 880 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1245, 'OWX979', 'MAZDA', 'diplomaticos', 880, 880880, 'I-10', 2000, 52505500, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 881 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1246, 'OWX980', 'MAZDA', 'diplomaticos', 881, 881881, 'I-10', 2001, 52505501, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 882 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1247, 'OWX981', 'MAZDA', 'diplomaticos', 882, 882882, 'I-10', 2002, 52505502, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 883 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1248, 'OWX982', 'MAZDA', 'diplomaticos', 883, 883883, 'I-10', 2003, 52505503, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 884 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1249, 'OWX983', 'MAZDA', 'diplomaticos', 884, 884884, 'I-10', 2004, 52505504, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 885 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1250, 'OWX984', 'MAZDA', 'diplomaticos', 885, 885885, 'I-10', 2005, 52505505, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 886 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1251, 'OWX985', 'MAZDA', 'diplomaticos', 886, 886886, 'I-10', 2006, 52505506, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 887 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1252, 'OWX986', 'MAZDA', 'diplomaticos', 887, 887887, 'I-10', 2007, 52505507, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 888 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1253, 'OWX987', 'MAZDA', 'diplomaticos', 888, 888888, 'I-10', 2008, 52505508, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 889 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1254, 'OWX988', 'MAZDA', 'diplomaticos', 889, 889889, 'I-10', 2009, 52505509, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 890 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1255, 'OWX989', 'MAZDA', 'diplomaticos', 890, 890890, 'I-10', 2010, 52505510, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 891 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1256, 'OWX990', 'MAZDA', 'diplomaticos', 891, 891891, 'I-10', 2011, 52505511, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 892 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1257, 'OWX991', 'MAZDA', 'diplomaticos', 892, 892892, 'I-10', 2012, 52505512, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 893 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1258, 'OWX992', 'MAZDA', 'diplomaticos', 893, 893893, 'I-10', 2013, 52505513, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 894 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1259, 'OWX993', 'MAZDA', 'diplomaticos', 894, 894894, 'I-10', 2014, 52505514, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 895 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1260, 'OWX994', 'MAZDA', 'diplomaticos', 895, 895895, 'I-10', 2015, 52505515, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 896 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1261, 'OWX995', 'MAZDA', 'diplomaticos', 896, 896896, 'I-10', 2016, 52505516, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 897 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1262, 'OWX996', 'MAZDA', 'diplomaticos', 897, 897897, 'I-10', 2017, 52505517, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 898 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1263, 'OWX997', 'MAZDA', 'diplomaticos', 898, 898898, 'I-10', 2018, 52505518, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 899 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1264, 'OWX998', 'MAZDA', 'diplomaticos', 899, 899899, 'I-10', 2019, 52505519, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 900 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1265, 'OWX999', 'MAZDA', 'diplomaticos', 900, 900900, 'Tracker', 1920, 52505520, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 901 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1266, 'MBD492', 'MAZDA', 'diplomaticos', 901, 901901, 'Tracker', 1921, 52505521, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 902 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1267, 'MBD493', 'MAZDA', 'diplomaticos', 902, 902902, 'Tracker', 1922, 52505522, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 903 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1268, 'MBD494', 'MAZDA', 'diplomaticos', 903, 903903, 'Tracker', 1923, 52505523, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 904 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1269, 'MBD495', 'MAZDA', 'diplomaticos', 904, 904904, 'Tracker', 1924, 52505524, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 905 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1270, 'MBD496', 'MAZDA', 'diplomaticos', 905, 905905, 'Tracker', 1925, 52505525, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 906 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1271, 'MBD497', 'MAZDA', 'diplomaticos', 906, 906906, 'Tracker', 1926, 52505526, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 907 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1272, 'MBD498', 'MAZDA', 'diplomaticos', 907, 907907, 'Tracker', 1927, 52505527, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 908 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1273, 'MBD499', 'MAZDA', 'diplomaticos', 908, 908908, 'Tracker', 1928, 52505528, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 909 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1274, 'MBD500', 'MAZDA', 'diplomaticos', 909, 909909, 'Tracker', 1929, 52505529, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 910 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1275, 'MBD501', 'MAZDA', 'diplomaticos', 910, 910910, 'Tracker', 1930, 52505530, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 911 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1276, 'MBD502', 'MAZDA', 'diplomaticos', 911, 911911, 'Tracker', 1931, 52505531, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 912 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1277, 'MBD503', 'MAZDA', 'diplomaticos', 912, 912912, 'Tracker', 1932, 52505532, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 913 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1278, 'MBD504', 'MAZDA', 'diplomaticos', 913, 913913, 'Tracker', 1933, 52505533, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 914 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1279, 'MBD505', 'MAZDA', 'diplomaticos', 914, 914914, 'Tracker', 1934, 52505534, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 915 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1280, 'MBD506', 'MAZDA', 'diplomaticos', 915, 915915, 'Tracker', 1935, 52505535, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 916 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1281, 'MBD507', 'MAZDA', 'diplomaticos', 916, 916916, 'Tracker', 1936, 52505536, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 917 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1282, 'MBD508', 'MAZDA', 'diplomaticos', 917, 917917, 'Tracker', 1937, 52505537, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 918 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1283, 'MBD509', 'MAZDA', 'diplomaticos', 918, 918918, 'Tracker', 1938, 52505538, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 919 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1284, 'MBD510', 'MAZDA', 'diplomaticos', 919, 919919, 'Tracker', 1939, 52505539, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 920 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1285, 'MBD511', 'MAZDA', 'diplomaticos', 920, 920920, 'Tracker', 1940, 52505540, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 921 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1286, 'MBD512', 'MAZDA', 'diplomaticos', 921, 921921, 'Tracker', 1941, 52505541, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 922 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1287, 'MBD513', 'MAZDA', 'diplomaticos', 922, 922922, 'Tracker', 1942, 52505542, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 923 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1288, 'MBD514', 'MAZDA', 'diplomaticos', 923, 923923, 'Tracker', 1943, 52505543, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 924 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1289, 'MBD515', 'MAZDA', 'diplomaticos', 924, 924924, 'Tracker', 1944, 52505544, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 925 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1290, 'MBD516', 'MAZDA', 'diplomaticos', 925, 925925, 'Tracker', 1945, 52505545, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 926 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1291, 'MBD517', 'MAZDA', 'diplomaticos', 926, 926926, 'Tracker', 1946, 52505546, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 927 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1292, 'MBD518', 'MAZDA', 'diplomaticos', 927, 927927, 'Tracker', 1947, 52505547, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 928 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1293, 'MBD519', 'MAZDA', 'diplomaticos', 928, 928928, 'Tracker', 1948, 52505548, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 929 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1294, 'MBD520', 'MAZDA', 'diplomaticos', 929, 929929, 'Tracker', 1949, 52505549, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 930 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1295, 'MBD521', 'MAZDA', 'diplomaticos', 930, 930930, 'Tracker', 1950, 52505550, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 931 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1296, 'MBD522', 'MAZDA', 'diplomaticos', 931, 931931, 'Tracker', 1951, 52505551, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 932 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1297, 'MBD523', 'MAZDA', 'diplomaticos', 932, 932932, 'Tracker', 1952, 52505552, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 933 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1298, 'MBD524', 'MAZDA', 'diplomaticos', 933, 933933, 'Tracker', 1953, 52505553, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 934 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1299, 'MBD525', 'MAZDA', 'diplomaticos', 934, 934934, 'Tracker', 1954, 52505554, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 935 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1300, 'MBD526', 'MAZDA', 'diplomaticos', 935, 935935, 'Tracker', 1955, 52505555, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 936 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1301, 'MBD527', 'MAZDA', 'diplomaticos', 936, 936936, 'Tracker', 1956, 52505556, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 937 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1302, 'MBD528', 'MAZDA', 'diplomaticos', 937, 937937, 'Tracker', 1957, 52505557, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 938 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1303, 'MBD529', 'MAZDA', 'diplomaticos', 938, 938938, 'Tracker', 1958, 52505558, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 939 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1304, 'MBD530', 'MAZDA', 'diplomaticos', 939, 939939, 'Tracker', 1959, 52505559, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 940 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1305, 'MBD531', 'MAZDA', 'diplomaticos', 940, 940940, 'Tracker', 1960, 52505560, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 941 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1306, 'MBD532', 'MAZDA', 'diplomaticos', 941, 941941, 'Tracker', 1961, 52505561, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 942 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1307, 'MBD533', 'MAZDA', 'diplomaticos', 942, 942942, 'Tracker', 1962, 52505562, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 943 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1308, 'MBD534', 'MAZDA', 'diplomaticos', 943, 943943, 'Tracker', 1963, 52505563, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 944 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1309, 'MBD535', 'MAZDA', 'diplomaticos', 944, 944944, 'Tracker', 1964, 52505564, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 945 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1310, 'MBD536', 'MAZDA', 'diplomaticos', 945, 945945, 'Tracker', 1965, 52505565, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 946 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1311, 'MBD537', 'MAZDA', 'diplomaticos', 946, 946946, 'Tracker', 1966, 52505566, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 947 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1312, 'MBD538', 'MAZDA', 'diplomaticos', 947, 947947, 'Tracker', 1967, 52505567, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 948 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1313, 'MBD539', 'MAZDA', 'diplomaticos', 948, 948948, 'Tracker', 1968, 52505568, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 949 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1314, 'MBD540', 'MAZDA', 'diplomaticos', 949, 949949, 'Tracker', 1969, 52505569, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 950 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1315, 'MBD541', 'MAZDA', 'diplomaticos', 950, 950950, 'Tracker', 1970, 52505570, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 951 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1316, 'MBD542', 'MAZDA', 'diplomaticos', 951, 951951, 'Tracker', 1971, 52505571, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 952 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1317, 'MBD543', 'MAZDA', 'diplomaticos', 952, 952952, 'Tracker', 1972, 52505572, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 953 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1318, 'MBD544', 'MAZDA', 'diplomaticos', 953, 953953, 'Tracker', 1973, 52505573, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 954 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1319, 'MBD545', 'MAZDA', 'diplomaticos', 954, 954954, 'Tracker', 1974, 52505574, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 955 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1320, 'MBD546', 'MAZDA', 'diplomaticos', 955, 955955, 'Tracker', 1975, 52505575, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 956 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1321, 'MBD547', 'MAZDA', 'diplomaticos', 956, 956956, 'Tracker', 1976, 52505576, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 957 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1322, 'MBD548', 'MAZDA', 'diplomaticos', 957, 957957, 'Tracker', 1977, 52505577, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 958 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1323, 'MBD549', 'MAZDA', 'diplomaticos', 958, 958958, 'Tracker', 1978, 52505578, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 959 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1324, 'MBD550', 'MAZDA', 'diplomaticos', 959, 959959, 'Tracker', 1979, 52505579, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 960 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1325, 'MBD551', 'MAZDA', 'diplomaticos', 960, 960960, 'Tracker', 1980, 52505580, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 961 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1326, 'MBD552', 'MAZDA', 'diplomaticos', 961, 961961, 'Tracker', 1981, 52505581, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 962 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1327, 'MBD553', 'MAZDA', 'diplomaticos', 962, 962962, 'Tracker', 1982, 52505582, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 963 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1328, 'MBD554', 'MAZDA', 'diplomaticos', 963, 963963, 'Tracker', 1983, 52505583, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 964 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1329, 'MBD555', 'MAZDA', 'diplomaticos', 964, 964964, 'Tracker', 1984, 52505584, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 965 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1330, 'MBD556', 'MAZDA', 'diplomaticos', 965, 965965, 'Tracker', 1985, 52505585, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 966 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1331, 'MBD557', 'MAZDA', 'diplomaticos', 966, 966966, 'Tracker', 1986, 52505586, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 967 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1332, 'MBD558', 'MAZDA', 'diplomaticos', 967, 967967, 'Tracker', 1987, 52505587, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 968 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1333, 'MBD559', 'MAZDA', 'diplomaticos', 968, 968968, 'Tracker', 1988, 52505588, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 969 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1334, 'MBD560', 'MAZDA', 'diplomaticos', 969, 969969, 'Tracker', 1989, 52505589, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 970 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1335, 'MBD561', 'MAZDA', 'diplomaticos', 970, 970970, 'Tracker', 1990, 52505590, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 971 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1336, 'MBD562', 'MAZDA', 'diplomaticos', 971, 971971, 'Tracker', 1991, 52505591, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 972 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1337, 'MBD563', 'MAZDA', 'diplomaticos', 972, 972972, 'Tracker', 1992, 52505592, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 973 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1338, 'MBD564', 'MAZDA', 'diplomaticos', 973, 973973, 'Tracker', 1993, 52505593, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 974 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1339, 'MBD565', 'MAZDA', 'diplomaticos', 974, 974974, 'Tracker', 1994, 52505594, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 975 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1340, 'MBD566', 'MAZDA', 'diplomaticos', 975, 975975, 'Tracker', 1995, 52505595, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 976 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1341, 'MBD567', 'MAZDA', 'diplomaticos', 976, 976976, 'Tracker', 1996, 52505596, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 977 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1342, 'MBD568', 'MAZDA', 'diplomaticos', 977, 977977, 'Tracker', 1997, 52505597, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 978 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1343, 'MBD569', 'MAZDA', 'diplomaticos', 978, 978978, 'Tracker', 1998, 52505598, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 979 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1344, 'MBD570', 'MAZDA', 'diplomaticos', 979, 979979, 'Tracker', 1999, 52505599, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 980 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1345, 'MBD571', 'MAZDA', 'diplomaticos', 980, 980980, 'Tracker', 2000, 52505600, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 981 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1346, 'MBD572', 'MAZDA', 'diplomaticos', 981, 981981, 'Tracker', 2001, 52505601, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 982 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1347, 'MBD573', 'MAZDA', 'diplomaticos', 982, 982982, 'Tracker', 2002, 52505602, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 983 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1348, 'MBD574', 'MAZDA', 'diplomaticos', 983, 983983, 'Tracker', 2003, 52505603, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 984 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1349, 'MBD575', 'MAZDA', 'diplomaticos', 984, 984984, 'Tracker', 2004, 52505604, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 985 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1350, 'MBD576', 'MAZDA', 'diplomaticos', 985, 985985, 'Tracker', 2005, 52505605, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 986 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1351, 'MBD577', 'MAZDA', 'diplomaticos', 986, 986986, 'Tracker', 2006, 52505606, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 987 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1352, 'MBD578', 'MAZDA', 'diplomaticos', 987, 987987, 'Tracker', 2007, 52505607, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 988 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1353, 'MBD579', 'MAZDA', 'diplomaticos', 988, 988988, 'Tracker', 2008, 52505608, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 989 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1354, 'MBD580', 'MAZDA', 'diplomaticos', 989, 989989, 'Tracker', 2009, 52505609, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 990 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1355, 'MBD581', 'MAZDA', 'diplomaticos', 990, 990990, 'Tracker', 2010, 52505610, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 991 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1356, 'MBD582', 'MAZDA', 'diplomaticos', 991, 991991, 'Tracker', 2011, 52505611, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 992 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1357, 'MBD583', 'MAZDA', 'diplomaticos', 992, 992992, 'Tracker', 2012, 52505612, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 993 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1358, 'MBD584', 'MAZDA', 'diplomaticos', 993, 993993, 'Tracker', 2013, 52505613, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 994 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1359, 'MBD585', 'MAZDA', 'diplomaticos', 994, 994994, 'Tracker', 2014, 52505614, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 995 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1360, 'MBD586', 'MAZDA', 'diplomaticos', 995, 995995, 'Tracker', 2015, 52505615, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 996 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1361, 'MBD587', 'MAZDA', 'diplomaticos', 996, 996996, 'Tracker', 2016, 52505616, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 997 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1362, 'MBD588', 'MAZDA', 'diplomaticos', 997, 997997, 'Tracker', 2017, 52505617, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 998 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1363, 'MBD589', 'MAZDA', 'diplomaticos', 998, 998998, 'Tracker', 2018, 52505618, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 999 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1364, 'MBD590', 'MAZDA', 'diplomaticos', 999, 999999, 'Tracker', 2019, 52505619, 6, 2000, 'GASOLINA'
);

/* INSERT QUERY NO: 1000 */
INSERT INTO Vehiculos(NoMotor, Placa, Marca, TiServicio, CodiInicio, CodiFin, Linea, MoCarro, CeConductor, Capacidad, Cilindraje, Combustible)
VALUES
(
1365, 'MBD591', 'MAZDA', 'diplomaticos', 1000, 10001000, 'Spark', 2019, 52505620, 6, 2000, 'GASOLINA'
);

