
--------------------------------------------Polizass------------------------------------------------------------------------------------------------

/* INSERT QUERY NO: 1 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
1, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 366, 0
);

/* INSERT QUERY NO: 2 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
2, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 367, 1
);

/* INSERT QUERY NO: 3 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
3, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 368, 2
);

/* INSERT QUERY NO: 4 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
4, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 369, 3
);

/* INSERT QUERY NO: 5 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
5, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 370, 4
);

/* INSERT QUERY NO: 6 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
6, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 371, 5
);

/* INSERT QUERY NO: 7 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
7, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 372, 6
);

/* INSERT QUERY NO: 8 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
8, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 373, 7
);

/* INSERT QUERY NO: 9 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
9, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 374, 8
);

/* INSERT QUERY NO: 10 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
10, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 375, 9
);

/* INSERT QUERY NO: 11 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
11, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 376, 10
);

/* INSERT QUERY NO: 12 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
12, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 377, 11
);

/* INSERT QUERY NO: 13 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
13, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 378, 12
);

/* INSERT QUERY NO: 14 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
14, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 379, 13
);

/* INSERT QUERY NO: 15 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
15, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 380, 14
);

/* INSERT QUERY NO: 16 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
16, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 381, 15
);

/* INSERT QUERY NO: 17 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
17, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 382, 16
);

/* INSERT QUERY NO: 18 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
18, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 383, 17
);

/* INSERT QUERY NO: 19 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
19, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 384, 18
);

/* INSERT QUERY NO: 20 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
20, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 385, 19
);

/* INSERT QUERY NO: 21 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
21, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 386, 20
);

/* INSERT QUERY NO: 22 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
22, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 387, 21
);

/* INSERT QUERY NO: 23 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
23, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 388, 22
);

/* INSERT QUERY NO: 24 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
24, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 389, 23
);

/* INSERT QUERY NO: 25 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
25, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 390, 24
);

/* INSERT QUERY NO: 26 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
26, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 391, 25
);

/* INSERT QUERY NO: 27 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
27, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 392, 26
);

/* INSERT QUERY NO: 28 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
28, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 393, 27
);

/* INSERT QUERY NO: 29 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
29, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 394, 28
);

/* INSERT QUERY NO: 30 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
30, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 395, 29
);

/* INSERT QUERY NO: 31 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
31, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 396, 30
);

/* INSERT QUERY NO: 32 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
32, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 397, 31
);

/* INSERT QUERY NO: 33 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
33, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 398, 32
);

/* INSERT QUERY NO: 34 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
34, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 399, 33
);

/* INSERT QUERY NO: 35 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
35, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 400, 34
);

/* INSERT QUERY NO: 36 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
36, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 401, 35
);

/* INSERT QUERY NO: 37 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
37, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 402, 36
);

/* INSERT QUERY NO: 38 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
38, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 403, 37
);

/* INSERT QUERY NO: 39 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
39, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 404, 38
);

/* INSERT QUERY NO: 40 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
40, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 405, 39
);

/* INSERT QUERY NO: 41 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
41, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 406, 40
);

/* INSERT QUERY NO: 42 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
42, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 407, 41
);

/* INSERT QUERY NO: 43 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
43, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 408, 42
);

/* INSERT QUERY NO: 44 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
44, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 409, 43
);

/* INSERT QUERY NO: 45 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
45, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 410, 44
);

/* INSERT QUERY NO: 46 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
46, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 411, 45
);

/* INSERT QUERY NO: 47 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
47, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 412, 46
);

/* INSERT QUERY NO: 48 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
48, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 413, 47
);

/* INSERT QUERY NO: 49 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
49, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 414, 48
);

/* INSERT QUERY NO: 50 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
50, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 415, 49
);

/* INSERT QUERY NO: 51 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
51, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 416, 50
);

/* INSERT QUERY NO: 52 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
52, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 417, 51
);

/* INSERT QUERY NO: 53 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
53, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 418, 52
);

/* INSERT QUERY NO: 54 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
54, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 419, 53
);

/* INSERT QUERY NO: 55 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
55, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 420, 54
);

/* INSERT QUERY NO: 56 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
56, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 421, 55
);

/* INSERT QUERY NO: 57 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
57, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 422, 56
);

/* INSERT QUERY NO: 58 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
58, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 423, 57
);

/* INSERT QUERY NO: 59 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
59, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 424, 58
);

/* INSERT QUERY NO: 60 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
60, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 425, 59
);

/* INSERT QUERY NO: 61 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
61, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 426, 60
);

/* INSERT QUERY NO: 62 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
62, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 427, 61
);

/* INSERT QUERY NO: 63 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
63, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 428, 62
);

/* INSERT QUERY NO: 64 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
64, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 429, 63
);

/* INSERT QUERY NO: 65 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
65, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 430, 64
);

/* INSERT QUERY NO: 66 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
66, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 431, 65
);

/* INSERT QUERY NO: 67 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
67, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 432, 66
);

/* INSERT QUERY NO: 68 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
68, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 433, 67
);

/* INSERT QUERY NO: 69 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
69, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 434, 68
);

/* INSERT QUERY NO: 70 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
70, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 435, 69
);

/* INSERT QUERY NO: 71 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
71, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 436, 70
);

/* INSERT QUERY NO: 72 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
72, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 437, 71
);

/* INSERT QUERY NO: 73 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
73, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 438, 72
);

/* INSERT QUERY NO: 74 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
74, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 439, 73
);

/* INSERT QUERY NO: 75 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
75, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 440, 74
);

/* INSERT QUERY NO: 76 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
76, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 441, 75
);

/* INSERT QUERY NO: 77 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
77, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 442, 76
);

/* INSERT QUERY NO: 78 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
78, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 443, 77
);

/* INSERT QUERY NO: 79 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
79, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 444, 78
);

/* INSERT QUERY NO: 80 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
80, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 445, 79
);

/* INSERT QUERY NO: 81 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
81, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 446, 80
);

/* INSERT QUERY NO: 82 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
82, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 447, 81
);

/* INSERT QUERY NO: 83 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
83, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 448, 82
);

/* INSERT QUERY NO: 84 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
84, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 449, 83
);

/* INSERT QUERY NO: 85 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
85, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 450, 84
);

/* INSERT QUERY NO: 86 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
86, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 451, 85
);

/* INSERT QUERY NO: 87 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
87, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 452, 86
);

/* INSERT QUERY NO: 88 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
88, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 453, 87
);

/* INSERT QUERY NO: 89 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
89, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 454, 88
);

/* INSERT QUERY NO: 90 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
90, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 455, 89
);

/* INSERT QUERY NO: 91 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
91, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 456, 90
);

/* INSERT QUERY NO: 92 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
92, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 457, 91
);

/* INSERT QUERY NO: 93 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
93, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 458, 92
);

/* INSERT QUERY NO: 94 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
94, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 459, 93
);

/* INSERT QUERY NO: 95 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
95, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 460, 94
);

/* INSERT QUERY NO: 96 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
96, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 461, 95
);

/* INSERT QUERY NO: 97 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
97, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 462, 96
);

/* INSERT QUERY NO: 98 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
98, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 463, 97
);

/* INSERT QUERY NO: 99 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
99, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 464, 98
);

/* INSERT QUERY NO: 100 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
100, TO_DATE('13/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 465, 99
);

/* INSERT QUERY NO: 101 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
101, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 466, 100
);

/* INSERT QUERY NO: 102 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
102, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 467, 101
);

/* INSERT QUERY NO: 103 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
103, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 468, 102
);

/* INSERT QUERY NO: 104 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
104, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 469, 103
);

/* INSERT QUERY NO: 105 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
105, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 470, 104
);

/* INSERT QUERY NO: 106 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
106, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 471, 105
);

/* INSERT QUERY NO: 107 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
107, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 472, 106
);

/* INSERT QUERY NO: 108 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
108, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 473, 107
);

/* INSERT QUERY NO: 109 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
109, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 474, 108
);

/* INSERT QUERY NO: 110 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
110, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 475, 109
);

/* INSERT QUERY NO: 111 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
111, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 476, 110
);

/* INSERT QUERY NO: 112 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
112, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 477, 111
);

/* INSERT QUERY NO: 113 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
113, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 478, 112
);

/* INSERT QUERY NO: 114 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
114, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 479, 113
);

/* INSERT QUERY NO: 115 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
115, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 480, 114
);

/* INSERT QUERY NO: 116 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
116, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 481, 115
);

/* INSERT QUERY NO: 117 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
117, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 482, 116
);

/* INSERT QUERY NO: 118 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
118, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 483, 117
);

/* INSERT QUERY NO: 119 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
119, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 484, 118
);

/* INSERT QUERY NO: 120 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
120, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 485, 119
);

/* INSERT QUERY NO: 121 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
121, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 486, 120
);

/* INSERT QUERY NO: 122 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
122, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 487, 121
);

/* INSERT QUERY NO: 123 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
123, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 488, 122
);

/* INSERT QUERY NO: 124 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
124, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 489, 123
);

/* INSERT QUERY NO: 125 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
125, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 490, 124
);

/* INSERT QUERY NO: 126 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
126, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 491, 125
);

/* INSERT QUERY NO: 127 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
127, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 492, 126
);

/* INSERT QUERY NO: 128 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
128, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 493, 127
);

/* INSERT QUERY NO: 129 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
129, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 494, 128
);

/* INSERT QUERY NO: 130 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
130, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 495, 129
);

/* INSERT QUERY NO: 131 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
131, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 496, 130
);

/* INSERT QUERY NO: 132 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
132, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 497, 131
);

/* INSERT QUERY NO: 133 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
133, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 498, 132
);

/* INSERT QUERY NO: 134 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
134, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 499, 133
);

/* INSERT QUERY NO: 135 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
135, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 500, 134
);

/* INSERT QUERY NO: 136 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
136, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 501, 135
);

/* INSERT QUERY NO: 137 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
137, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 502, 136
);

/* INSERT QUERY NO: 138 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
138, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 503, 137
);

/* INSERT QUERY NO: 139 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
139, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 504, 138
);

/* INSERT QUERY NO: 140 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
140, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 505, 139
);

/* INSERT QUERY NO: 141 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
141, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 506, 140
);

/* INSERT QUERY NO: 142 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
142, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 507, 141
);

/* INSERT QUERY NO: 143 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
143, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 508, 142
);

/* INSERT QUERY NO: 144 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
144, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 509, 143
);

/* INSERT QUERY NO: 145 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
145, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 510, 144
);

/* INSERT QUERY NO: 146 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
146, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 511, 145
);

/* INSERT QUERY NO: 147 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
147, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 512, 146
);

/* INSERT QUERY NO: 148 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
148, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 513, 147
);

/* INSERT QUERY NO: 149 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
149, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 514, 148
);

/* INSERT QUERY NO: 150 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
150, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 515, 149
);

/* INSERT QUERY NO: 151 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
151, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 516, 150
);

/* INSERT QUERY NO: 152 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
152, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 517, 151
);

/* INSERT QUERY NO: 153 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
153, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 518, 152
);

/* INSERT QUERY NO: 154 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
154, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 519, 153
);

/* INSERT QUERY NO: 155 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
155, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 520, 154
);

/* INSERT QUERY NO: 156 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
156, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 521, 155
);

/* INSERT QUERY NO: 157 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
157, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 522, 156
);

/* INSERT QUERY NO: 158 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
158, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 523, 157
);

/* INSERT QUERY NO: 159 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
159, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 524, 158
);

/* INSERT QUERY NO: 160 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
160, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 525, 159
);

/* INSERT QUERY NO: 161 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
161, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 526, 160
);

/* INSERT QUERY NO: 162 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
162, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 527, 161
);

/* INSERT QUERY NO: 163 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
163, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 528, 162
);

/* INSERT QUERY NO: 164 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
164, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 529, 163
);

/* INSERT QUERY NO: 165 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
165, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 530, 164
);

/* INSERT QUERY NO: 166 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
166, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 531, 165
);

/* INSERT QUERY NO: 167 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
167, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 532, 166
);

/* INSERT QUERY NO: 168 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
168, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 533, 167
);

/* INSERT QUERY NO: 169 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
169, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 534, 168
);

/* INSERT QUERY NO: 170 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
170, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 535, 169
);

/* INSERT QUERY NO: 171 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
171, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 536, 170
);

/* INSERT QUERY NO: 172 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
172, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 537, 171
);

/* INSERT QUERY NO: 173 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
173, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 538, 172
);

/* INSERT QUERY NO: 174 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
174, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 539, 173
);

/* INSERT QUERY NO: 175 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
175, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 540, 174
);

/* INSERT QUERY NO: 176 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
176, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 541, 175
);

/* INSERT QUERY NO: 177 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
177, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 542, 176
);

/* INSERT QUERY NO: 178 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
178, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 543, 177
);

/* INSERT QUERY NO: 179 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
179, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 544, 178
);

/* INSERT QUERY NO: 180 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
180, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 545, 179
);

/* INSERT QUERY NO: 181 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
181, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 546, 180
);

/* INSERT QUERY NO: 182 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
182, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 547, 181
);

/* INSERT QUERY NO: 183 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
183, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 548, 182
);

/* INSERT QUERY NO: 184 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
184, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 549, 183
);

/* INSERT QUERY NO: 185 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
185, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 550, 184
);

/* INSERT QUERY NO: 186 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
186, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 551, 185
);

/* INSERT QUERY NO: 187 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
187, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 552, 186
);

/* INSERT QUERY NO: 188 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
188, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 553, 187
);

/* INSERT QUERY NO: 189 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
189, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 554, 188
);

/* INSERT QUERY NO: 190 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
190, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 555, 189
);

/* INSERT QUERY NO: 191 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
191, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 556, 190
);

/* INSERT QUERY NO: 192 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
192, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 557, 191
);

/* INSERT QUERY NO: 193 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
193, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 558, 192
);

/* INSERT QUERY NO: 194 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
194, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 559, 193
);

/* INSERT QUERY NO: 195 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
195, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 560, 194
);

/* INSERT QUERY NO: 196 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
196, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 561, 195
);

/* INSERT QUERY NO: 197 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
197, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 562, 196
);

/* INSERT QUERY NO: 198 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
198, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 563, 197
);

/* INSERT QUERY NO: 199 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
199, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 564, 198
);

/* INSERT QUERY NO: 200 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
200, TO_DATE('14/11/2015','DD/MM/YYYY'), TO_DATE('13/11/2018','DD/MM/YYYY'), 565, 199
);

/* INSERT QUERY NO: 201 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
201, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 566, 200
);

/* INSERT QUERY NO: 202 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
202, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 567, 201
);

/* INSERT QUERY NO: 203 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
203, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 568, 202
);

/* INSERT QUERY NO: 204 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
204, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 569, 203
);

/* INSERT QUERY NO: 205 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
205, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 570, 204
);

/* INSERT QUERY NO: 206 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
206, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 571, 205
);

/* INSERT QUERY NO: 207 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
207, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 572, 206
);

/* INSERT QUERY NO: 208 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
208, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 573, 207
);

/* INSERT QUERY NO: 209 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
209, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 574, 208
);

/* INSERT QUERY NO: 210 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
210, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 575, 209
);

/* INSERT QUERY NO: 211 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
211, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 576, 210
);

/* INSERT QUERY NO: 212 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
212, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 577, 211
);

/* INSERT QUERY NO: 213 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
213, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 578, 212
);

/* INSERT QUERY NO: 214 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
214, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 579, 213
);

/* INSERT QUERY NO: 215 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
215, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 580, 214
);

/* INSERT QUERY NO: 216 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
216, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 581, 215
);

/* INSERT QUERY NO: 217 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
217, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 582, 216
);

/* INSERT QUERY NO: 218 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
218, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 583, 217
);

/* INSERT QUERY NO: 219 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
219, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 584, 218
);

/* INSERT QUERY NO: 220 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
220, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 585, 219
);

/* INSERT QUERY NO: 221 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
221, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 586, 220
);

/* INSERT QUERY NO: 222 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
222, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 587, 221
);

/* INSERT QUERY NO: 223 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
223, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 588, 222
);

/* INSERT QUERY NO: 224 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
224, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 589, 223
);

/* INSERT QUERY NO: 225 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
225, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 590, 224
);

/* INSERT QUERY NO: 226 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
226, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 591, 225
);

/* INSERT QUERY NO: 227 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
227, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 592, 226
);

/* INSERT QUERY NO: 228 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
228, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 593, 227
);

/* INSERT QUERY NO: 229 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
229, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 594, 228
);

/* INSERT QUERY NO: 230 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
230, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 595, 229
);


/* INSERT QUERY NO: 232 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
232, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 597, 231
);

/* INSERT QUERY NO: 233 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
233, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 598, 232
);

/* INSERT QUERY NO: 234 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
234, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 599, 233
);

/* INSERT QUERY NO: 235 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
235, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 600, 234
);

/* INSERT QUERY NO: 236 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
236, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 601, 235
);

/* INSERT QUERY NO: 237 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
237, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 602, 236
);

/* INSERT QUERY NO: 238 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
238, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 603, 237
);

/* INSERT QUERY NO: 239 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
239, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 604, 238
);

/* INSERT QUERY NO: 240 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
240, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 605, 239
);

/* INSERT QUERY NO: 241 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
241, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 606, 240
);

/* INSERT QUERY NO: 242 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
242, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 607, 241
);

/* INSERT QUERY NO: 243 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
243, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 608, 242
);

/* INSERT QUERY NO: 244 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
244, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 609, 243
);

/* INSERT QUERY NO: 245 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
245, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 610, 244
);

/* INSERT QUERY NO: 246 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
246, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 611, 245
);

/* INSERT QUERY NO: 247 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
247, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 612, 246
);

/* INSERT QUERY NO: 248 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
248, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 613, 247
);

/* INSERT QUERY NO: 249 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
249, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 614, 248
);

/* INSERT QUERY NO: 250 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
250, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 615, 249
);

/* INSERT QUERY NO: 251 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
251, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 616, 250
);

/* INSERT QUERY NO: 252 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
252, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 617, 251
);

/* INSERT QUERY NO: 253 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
253, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 618, 252
);

/* INSERT QUERY NO: 254 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
254, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 619, 253
);

/* INSERT QUERY NO: 255 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
255, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 620, 254
);

/* INSERT QUERY NO: 256 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
256, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 621, 255
);

/* INSERT QUERY NO: 257 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
257, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 622, 256
);

/* INSERT QUERY NO: 258 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
258, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 623, 257
);

/* INSERT QUERY NO: 259 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
259, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 624, 258
);

/* INSERT QUERY NO: 260 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
260, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 625, 259
);

/* INSERT QUERY NO: 261 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
261, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 626, 260
);

/* INSERT QUERY NO: 262 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
262, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 627, 261
);

/* INSERT QUERY NO: 263 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
263, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 628, 262
);

/* INSERT QUERY NO: 264 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
264, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 629, 263
);

/* INSERT QUERY NO: 265 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
265, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 630, 264
);

/* INSERT QUERY NO: 266 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
266, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 631, 265
);

/* INSERT QUERY NO: 267 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
267, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 632, 266
);

/* INSERT QUERY NO: 268 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
268, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 633, 267
);

/* INSERT QUERY NO: 269 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
269, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 634, 268
);

/* INSERT QUERY NO: 270 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
270, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 635, 269
);

/* INSERT QUERY NO: 271 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
271, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 636, 270
);

/* INSERT QUERY NO: 272 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
272, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 637, 271
);

/* INSERT QUERY NO: 273 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
273, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 638, 272
);

/* INSERT QUERY NO: 274 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
274, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 639, 273
);

/* INSERT QUERY NO: 275 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
275, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 640, 274
);

/* INSERT QUERY NO: 276 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
276, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 641, 275
);

/* INSERT QUERY NO: 277 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
277, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 642, 276
);

/* INSERT QUERY NO: 278 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
278, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 643, 277
);

/* INSERT QUERY NO: 279 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
279, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 644, 278
);

/* INSERT QUERY NO: 280 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
280, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 645, 279
);

/* INSERT QUERY NO: 281 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
281, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 646, 280
);

/* INSERT QUERY NO: 282 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
282, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 647, 281
);

/* INSERT QUERY NO: 283 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
283, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 648, 282
);

/* INSERT QUERY NO: 284 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
284, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 649, 283
);

/* INSERT QUERY NO: 285 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
285, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 650, 284
);

/* INSERT QUERY NO: 286 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
286, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 651, 285
);

/* INSERT QUERY NO: 287 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
287, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 652, 286
);

/* INSERT QUERY NO: 288 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
288, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 653, 287
);

/* INSERT QUERY NO: 289 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
289, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 654, 288
);

/* INSERT QUERY NO: 290 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
290, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 655, 289
);

/* INSERT QUERY NO: 291 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
291, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 656, 290
);

/* INSERT QUERY NO: 292 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
292, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 657, 291
);

/* INSERT QUERY NO: 293 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
293, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 658, 292
);

/* INSERT QUERY NO: 294 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
294, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 659, 293
);

/* INSERT QUERY NO: 295 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
295, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 660, 294
);

/* INSERT QUERY NO: 296 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
296, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 661, 295
);

/* INSERT QUERY NO: 297 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
297, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 662, 296
);

/* INSERT QUERY NO: 298 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
298, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 663, 297
);

/* INSERT QUERY NO: 299 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
299, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 664, 298
);

/* INSERT QUERY NO: 300 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
300, TO_DATE('15/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 665, 299
);

/* INSERT QUERY NO: 301 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
301, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 666, 300
);

/* INSERT QUERY NO: 302 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
302, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 667, 301
);

/* INSERT QUERY NO: 303 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
303, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 668, 302
);

/* INSERT QUERY NO: 304 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
304, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 669, 303
);

/* INSERT QUERY NO: 305 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
305, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 670, 304
);

/* INSERT QUERY NO: 306 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
306, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 671, 305
);

/* INSERT QUERY NO: 307 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
307, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 672, 306
);

/* INSERT QUERY NO: 308 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
308, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 673, 307
);

/* INSERT QUERY NO: 309 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
309, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 674, 308
);

/* INSERT QUERY NO: 310 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
310, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 675, 309
);

/* INSERT QUERY NO: 311 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
311, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 676, 310
);

/* INSERT QUERY NO: 312 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
312, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 677, 311
);

/* INSERT QUERY NO: 313 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
313, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 678, 312
);

/* INSERT QUERY NO: 314 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
314, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 679, 313
);

/* INSERT QUERY NO: 315 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
315, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 680, 314
);

/* INSERT QUERY NO: 316 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
316, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 681, 315
);

/* INSERT QUERY NO: 317 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
317, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 682, 316
);

/* INSERT QUERY NO: 318 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
318, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 683, 317
);

/* INSERT QUERY NO: 319 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
319, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 684, 318
);

/* INSERT QUERY NO: 320 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
320, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 685, 319
);

/* INSERT QUERY NO: 321 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
321, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 686, 320
);

/* INSERT QUERY NO: 322 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
322, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 687, 321
);

/* INSERT QUERY NO: 323 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
323, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 688, 322
);

/* INSERT QUERY NO: 324 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
324, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 689, 323
);

/* INSERT QUERY NO: 325 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
325, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 690, 324
);

/* INSERT QUERY NO: 326 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
326, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 691, 325
);

/* INSERT QUERY NO: 327 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
327, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 692, 326
);

/* INSERT QUERY NO: 328 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
328, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 693, 327
);

/* INSERT QUERY NO: 329 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
329, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 694, 328
);

/* INSERT QUERY NO: 330 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
330, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 695, 329
);

/* INSERT QUERY NO: 331 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
331, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 696, 330
);

/* INSERT QUERY NO: 332 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
332, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 697, 331
);

/* INSERT QUERY NO: 333 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
333, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 698, 332
);

/* INSERT QUERY NO: 334 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
334, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 699, 333
);

/* INSERT QUERY NO: 335 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
335, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 700, 334
);

/* INSERT QUERY NO: 336 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
336, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 701, 335
);

/* INSERT QUERY NO: 337 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
337, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 702, 336
);

/* INSERT QUERY NO: 338 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
338, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 703, 337
);

/* INSERT QUERY NO: 339 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
339, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 704, 338
);

/* INSERT QUERY NO: 340 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
340, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 705, 339
);

/* INSERT QUERY NO: 341 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
341, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 706, 340
);

/* INSERT QUERY NO: 342 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
342, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 707, 341
);

/* INSERT QUERY NO: 343 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
343, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 708, 342
);

/* INSERT QUERY NO: 344 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
344, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 709, 343
);

/* INSERT QUERY NO: 345 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
345, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 710, 344
);

/* INSERT QUERY NO: 346 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
346, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 711, 345
);

/* INSERT QUERY NO: 347 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
347, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 712, 346
);

/* INSERT QUERY NO: 348 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
348, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 713, 347
);

/* INSERT QUERY NO: 349 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
349, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 714, 348
);

/* INSERT QUERY NO: 350 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
350, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 715, 349
);

/* INSERT QUERY NO: 351 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
351, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 716, 350
);

/* INSERT QUERY NO: 352 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
352, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 717, 351
);

/* INSERT QUERY NO: 353 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
353, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 718, 352
);

/* INSERT QUERY NO: 354 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
354, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 719, 353
);

/* INSERT QUERY NO: 355 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
355, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 720, 354
);

/* INSERT QUERY NO: 356 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
356, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 721, 355
);

/* INSERT QUERY NO: 357 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
357, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 722, 356
);

/* INSERT QUERY NO: 358 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
358, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 723, 357
);

/* INSERT QUERY NO: 359 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
359, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 724, 358
);

/* INSERT QUERY NO: 360 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
360, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 725, 359
);

/* INSERT QUERY NO: 361 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
361, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 726, 360
);

/* INSERT QUERY NO: 362 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
362, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 727, 361
);

/* INSERT QUERY NO: 363 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
363, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 728, 362
);

/* INSERT QUERY NO: 364 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
364, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 729, 363
);

/* INSERT QUERY NO: 365 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
365, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 730, 364
);

/* INSERT QUERY NO: 366 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
366, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 731, 365
);

/* INSERT QUERY NO: 367 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
367, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 732, 366
);

/* INSERT QUERY NO: 368 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
368, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 733, 367
);

/* INSERT QUERY NO: 369 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
369, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 734, 368
);

/* INSERT QUERY NO: 370 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
370, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 735, 369
);

/* INSERT QUERY NO: 371 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
371, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 736, 370
);

/* INSERT QUERY NO: 372 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
372, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 737, 371
);

/* INSERT QUERY NO: 373 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
373, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 738, 372
);

/* INSERT QUERY NO: 374 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
374, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 739, 373
);

/* INSERT QUERY NO: 375 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
375, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 740, 374
);

/* INSERT QUERY NO: 376 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
376, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 741, 375
);

/* INSERT QUERY NO: 377 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
377, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 742, 376
);

/* INSERT QUERY NO: 378 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
378, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 743, 377
);

/* INSERT QUERY NO: 379 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
379, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 744, 378
);

/* INSERT QUERY NO: 380 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
380, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 745, 379
);

/* INSERT QUERY NO: 381 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
381, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 746, 380
);

/* INSERT QUERY NO: 382 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
382, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 747, 381
);

/* INSERT QUERY NO: 383 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
383, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 748, 382
);

/* INSERT QUERY NO: 384 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
384, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 749, 383
);

/* INSERT QUERY NO: 385 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
385, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 750, 384
);

/* INSERT QUERY NO: 386 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
386, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 751, 385
);

/* INSERT QUERY NO: 387 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
387, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 752, 386
);

/* INSERT QUERY NO: 388 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
388, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 753, 387
);

/* INSERT QUERY NO: 389 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
389, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 754, 388
);

/* INSERT QUERY NO: 390 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
390, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 755, 389
);

/* INSERT QUERY NO: 391 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
391, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 756, 390
);

/* INSERT QUERY NO: 392 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
392, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 757, 391
);

/* INSERT QUERY NO: 393 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
393, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 758, 392
);

/* INSERT QUERY NO: 394 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
394, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 759, 393
);

/* INSERT QUERY NO: 395 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
395, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 760, 394
);

/* INSERT QUERY NO: 396 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
396, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 761, 395
);

/* INSERT QUERY NO: 397 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
397, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 762, 396
);

/* INSERT QUERY NO: 398 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
398, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 763, 397
);

/* INSERT QUERY NO: 399 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
399, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 764, 398
);

/* INSERT QUERY NO: 400 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
400, TO_DATE('16/11/2015','DD/MM/YYYY'), TO_DATE('14/11/2018','DD/MM/YYYY'), 765, 399
);

/* INSERT QUERY NO: 401 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
401, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 766, 400
);

/* INSERT QUERY NO: 402 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
402, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 767, 401
);

/* INSERT QUERY NO: 403 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
403, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 768, 402
);

/* INSERT QUERY NO: 404 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
404, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 769, 403
);

/* INSERT QUERY NO: 405 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
405, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 770, 404
);

/* INSERT QUERY NO: 406 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
406, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 771, 405
);

/* INSERT QUERY NO: 407 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
407, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 772, 406
);

/* INSERT QUERY NO: 408 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
408, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 773, 407
);

/* INSERT QUERY NO: 409 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
409, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 774, 408
);

/* INSERT QUERY NO: 410 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
410, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 775, 409
);

/* INSERT QUERY NO: 411 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
411, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 776, 410
);

/* INSERT QUERY NO: 412 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
412, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 777, 411
);

/* INSERT QUERY NO: 413 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
413, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 778, 412
);

/* INSERT QUERY NO: 414 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
414, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 779, 413
);

/* INSERT QUERY NO: 415 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
415, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 780, 414
);

/* INSERT QUERY NO: 416 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
416, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 781, 415
);

/* INSERT QUERY NO: 417 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
417, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 782, 416
);

/* INSERT QUERY NO: 418 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
418, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 783, 417
);

/* INSERT QUERY NO: 419 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
419, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 784, 418
);

/* INSERT QUERY NO: 420 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
420, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 785, 419
);

/* INSERT QUERY NO: 421 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
421, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 786, 420
);

/* INSERT QUERY NO: 422 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
422, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 787, 421
);

/* INSERT QUERY NO: 423 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
423, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 788, 422
);

/* INSERT QUERY NO: 424 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
424, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 789, 423
);

/* INSERT QUERY NO: 425 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
425, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 790, 424
);

/* INSERT QUERY NO: 426 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
426, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 791, 425
);

/* INSERT QUERY NO: 427 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
427, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 792, 426
);

/* INSERT QUERY NO: 428 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
428, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 793, 427
);

/* INSERT QUERY NO: 429 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
429, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 794, 428
);

/* INSERT QUERY NO: 430 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
430, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 795, 429
);

/* INSERT QUERY NO: 431 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
431, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 796, 430
);

/* INSERT QUERY NO: 432 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
432, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 797, 431
);

/* INSERT QUERY NO: 433 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
433, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 798, 432
);

/* INSERT QUERY NO: 434 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
434, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 799, 433
);

/* INSERT QUERY NO: 435 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
435, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 800, 434
);

/* INSERT QUERY NO: 436 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
436, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 801, 435
);

/* INSERT QUERY NO: 437 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
437, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 802, 436
);

/* INSERT QUERY NO: 438 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
438, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 803, 437
);

/* INSERT QUERY NO: 439 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
439, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 804, 438
);

/* INSERT QUERY NO: 440 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
440, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 805, 439
);

/* INSERT QUERY NO: 441 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
441, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 806, 440
);

/* INSERT QUERY NO: 442 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
442, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 807, 441
);

/* INSERT QUERY NO: 443 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
443, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 808, 442
);

/* INSERT QUERY NO: 444 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
444, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 809, 443
);

/* INSERT QUERY NO: 445 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
445, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 810, 444
);

/* INSERT QUERY NO: 446 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
446, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 811, 445
);

/* INSERT QUERY NO: 447 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
447, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 812, 446
);

/* INSERT QUERY NO: 448 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
448, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 813, 447
);

/* INSERT QUERY NO: 449 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
449, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 814, 448
);

/* INSERT QUERY NO: 450 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
450, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 815, 449
);

/* INSERT QUERY NO: 451 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
451, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 816, 450
);

/* INSERT QUERY NO: 452 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
452, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 817, 451
);

/* INSERT QUERY NO: 453 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
453, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 818, 452
);

/* INSERT QUERY NO: 454 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
454, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 819, 453
);

/* INSERT QUERY NO: 455 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
455, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 820, 454
);

/* INSERT QUERY NO: 456 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
456, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 821, 455
);

/* INSERT QUERY NO: 457 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
457, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 822, 456
);

/* INSERT QUERY NO: 458 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
458, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 823, 457
);

/* INSERT QUERY NO: 459 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
459, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 824, 458
);

/* INSERT QUERY NO: 460 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
460, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 825, 459
);

/* INSERT QUERY NO: 461 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
461, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 826, 460
);

/* INSERT QUERY NO: 462 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
462, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 827, 461
);

/* INSERT QUERY NO: 463 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
463, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 828, 462
);

/* INSERT QUERY NO: 464 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
464, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 829, 463
);

/* INSERT QUERY NO: 465 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
465, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 830, 464
);

/* INSERT QUERY NO: 466 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
466, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 831, 465
);

/* INSERT QUERY NO: 467 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
467, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 832, 466
);

/* INSERT QUERY NO: 468 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
468, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 833, 467
);

/* INSERT QUERY NO: 469 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
469, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 834, 468
);

/* INSERT QUERY NO: 470 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
470, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 835, 469
);

/* INSERT QUERY NO: 471 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
471, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 836, 470
);

/* INSERT QUERY NO: 472 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
472, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 837, 471
);

/* INSERT QUERY NO: 473 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
473, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 838, 472
);

/* INSERT QUERY NO: 474 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
474, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 839, 473
);

/* INSERT QUERY NO: 475 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
475, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 840, 474
);

/* INSERT QUERY NO: 476 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
476, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 841, 475
);

/* INSERT QUERY NO: 477 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
477, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 842, 476
);

/* INSERT QUERY NO: 478 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
478, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 843, 477
);

/* INSERT QUERY NO: 479 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
479, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 844, 478
);

/* INSERT QUERY NO: 480 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
480, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 845, 479
);

/* INSERT QUERY NO: 481 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
481, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 846, 480
);

/* INSERT QUERY NO: 482 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
482, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 847, 481
);

/* INSERT QUERY NO: 483 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
483, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 848, 482
);

/* INSERT QUERY NO: 484 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
484, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 849, 483
);

/* INSERT QUERY NO: 485 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
485, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 850, 484
);

/* INSERT QUERY NO: 486 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
486, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 851, 485
);

/* INSERT QUERY NO: 487 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
487, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 852, 486
);

/* INSERT QUERY NO: 488 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
488, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 853, 487
);

/* INSERT QUERY NO: 489 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
489, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 854, 488
);

/* INSERT QUERY NO: 490 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
490, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 855, 489
);

/* INSERT QUERY NO: 491 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
491, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 856, 490
);

/* INSERT QUERY NO: 492 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
492, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 857, 491
);

/* INSERT QUERY NO: 493 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
493, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 858, 492
);

/* INSERT QUERY NO: 494 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
494, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 859, 493
);

/* INSERT QUERY NO: 495 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
495, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 860, 494
);

/* INSERT QUERY NO: 496 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
496, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 861, 495
);

/* INSERT QUERY NO: 497 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
497, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 862, 496
);

/* INSERT QUERY NO: 498 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
498, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 863, 497
);

/* INSERT QUERY NO: 499 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
499, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 864, 498
);

/* INSERT QUERY NO: 500 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
500, TO_DATE('17/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 865, 499
);

/* INSERT QUERY NO: 501 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
501, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 866, 500
);

/* INSERT QUERY NO: 502 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
502, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 867, 501
);

/* INSERT QUERY NO: 503 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
503, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 868, 502
);

/* INSERT QUERY NO: 504 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
504, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 869, 503
);

/* INSERT QUERY NO: 505 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
505, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 870, 504
);

/* INSERT QUERY NO: 506 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
506, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 871, 505
);

/* INSERT QUERY NO: 507 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
507, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 872, 506
);

/* INSERT QUERY NO: 508 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
508, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 873, 507
);

/* INSERT QUERY NO: 509 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
509, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 874, 508
);

/* INSERT QUERY NO: 510 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
510, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 875, 509
);

/* INSERT QUERY NO: 511 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
511, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 876, 510
);

/* INSERT QUERY NO: 512 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
512, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 877, 511
);

/* INSERT QUERY NO: 513 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
513, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 878, 512
);

/* INSERT QUERY NO: 514 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
514, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 879, 513
);

/* INSERT QUERY NO: 515 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
515, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 880, 514
);

/* INSERT QUERY NO: 516 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
516, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 881, 515
);

/* INSERT QUERY NO: 517 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
517, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 882, 516
);

/* INSERT QUERY NO: 518 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
518, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 883, 517
);

/* INSERT QUERY NO: 519 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
519, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 884, 518
);

/* INSERT QUERY NO: 520 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
520, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 885, 519
);

/* INSERT QUERY NO: 521 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
521, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 886, 520
);

/* INSERT QUERY NO: 522 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
522, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 887, 521
);

/* INSERT QUERY NO: 523 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
523, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 888, 522
);

/* INSERT QUERY NO: 524 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
524, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 889, 523
);

/* INSERT QUERY NO: 525 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
525, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 890, 524
);

/* INSERT QUERY NO: 526 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
526, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 891, 525
);

/* INSERT QUERY NO: 527 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
527, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 892, 526
);

/* INSERT QUERY NO: 528 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
528, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 893, 527
);

/* INSERT QUERY NO: 529 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
529, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 894, 528
);

/* INSERT QUERY NO: 530 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
530, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 895, 529
);

/* INSERT QUERY NO: 531 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
531, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 896, 530
);

/* INSERT QUERY NO: 532 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
532, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 897, 531
);

/* INSERT QUERY NO: 533 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
533, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 898, 532
);

/* INSERT QUERY NO: 534 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
534, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 899, 533
);

/* INSERT QUERY NO: 535 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
535, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 900, 534
);

/* INSERT QUERY NO: 536 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
536, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 901, 535
);

/* INSERT QUERY NO: 537 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
537, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 902, 536
);

/* INSERT QUERY NO: 538 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
538, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 903, 537
);

/* INSERT QUERY NO: 539 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
539, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 904, 538
);

/* INSERT QUERY NO: 540 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
540, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 905, 539
);

/* INSERT QUERY NO: 541 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
541, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 906, 540
);

/* INSERT QUERY NO: 542 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
542, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 907, 541
);

/* INSERT QUERY NO: 543 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
543, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 908, 542
);

/* INSERT QUERY NO: 544 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
544, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 909, 543
);

/* INSERT QUERY NO: 545 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
545, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 910, 544
);

/* INSERT QUERY NO: 546 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
546, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 911, 545
);

/* INSERT QUERY NO: 547 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
547, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 912, 546
);

/* INSERT QUERY NO: 548 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
548, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 913, 547
);

/* INSERT QUERY NO: 549 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
549, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 914, 548
);

/* INSERT QUERY NO: 550 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
550, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 915, 549
);

/* INSERT QUERY NO: 551 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
551, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 916, 550
);

/* INSERT QUERY NO: 552 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
552, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 917, 551
);

/* INSERT QUERY NO: 553 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
553, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 918, 552
);

/* INSERT QUERY NO: 554 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
554, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 919, 553
);

/* INSERT QUERY NO: 555 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
555, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 920, 554
);

/* INSERT QUERY NO: 556 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
556, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 921, 555
);

/* INSERT QUERY NO: 557 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
557, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 922, 556
);

/* INSERT QUERY NO: 558 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
558, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 923, 557
);

/* INSERT QUERY NO: 559 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
559, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 924, 558
);

/* INSERT QUERY NO: 560 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
560, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 925, 559
);

/* INSERT QUERY NO: 561 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
561, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 926, 560
);

/* INSERT QUERY NO: 562 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
562, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 927, 561
);

/* INSERT QUERY NO: 563 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
563, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 928, 562
);

/* INSERT QUERY NO: 564 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
564, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 929, 563
);

/* INSERT QUERY NO: 565 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
565, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 930, 564
);

/* INSERT QUERY NO: 566 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
566, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 931, 565
);

/* INSERT QUERY NO: 567 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
567, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 932, 566
);

/* INSERT QUERY NO: 568 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
568, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 933, 567
);

/* INSERT QUERY NO: 569 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
569, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 934, 568
);

/* INSERT QUERY NO: 570 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
570, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 935, 569
);

/* INSERT QUERY NO: 571 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
571, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 936, 570
);

/* INSERT QUERY NO: 572 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
572, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 937, 571
);

/* INSERT QUERY NO: 573 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
573, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 938, 572
);

/* INSERT QUERY NO: 574 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
574, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 939, 573
);

/* INSERT QUERY NO: 575 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
575, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 940, 574
);

/* INSERT QUERY NO: 576 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
576, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 941, 575
);

/* INSERT QUERY NO: 577 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
577, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 942, 576
);

/* INSERT QUERY NO: 578 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
578, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 943, 577
);

/* INSERT QUERY NO: 579 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
579, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 944, 578
);

/* INSERT QUERY NO: 580 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
580, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 945, 579
);

/* INSERT QUERY NO: 581 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
581, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 946, 580
);

/* INSERT QUERY NO: 582 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
582, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 947, 581
);

/* INSERT QUERY NO: 583 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
583, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 948, 582
);

/* INSERT QUERY NO: 584 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
584, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 949, 583
);

/* INSERT QUERY NO: 585 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
585, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 950, 584
);

/* INSERT QUERY NO: 586 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
586, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 951, 585
);

/* INSERT QUERY NO: 587 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
587, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 952, 586
);

/* INSERT QUERY NO: 588 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
588, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 953, 587
);

/* INSERT QUERY NO: 589 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
589, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 954, 588
);

/* INSERT QUERY NO: 590 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
590, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 955, 589
);

/* INSERT QUERY NO: 591 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
591, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 956, 590
);

/* INSERT QUERY NO: 592 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
592, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 957, 591
);

/* INSERT QUERY NO: 593 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
593, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 958, 592
);

/* INSERT QUERY NO: 594 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
594, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 959, 593
);

/* INSERT QUERY NO: 595 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
595, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 960, 594
);

/* INSERT QUERY NO: 596 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
596, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 961, 595
);

/* INSERT QUERY NO: 597 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
597, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 962, 596
);

/* INSERT QUERY NO: 598 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
598, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 963, 597
);

/* INSERT QUERY NO: 599 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
599, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 964, 598
);

/* INSERT QUERY NO: 600 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
600, TO_DATE('18/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2018','DD/MM/YYYY'), 965, 599
);

/* INSERT QUERY NO: 601 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
601, TO_DATE('19/11/2015','DD/MM/YYYY'),TO_DATE('16/11/2018','DD/MM/YYYY'), 966, 600
);

/* INSERT QUERY NO: 602 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
602, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 967, 601
);

/* INSERT QUERY NO: 603 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
603, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 968, 602
);

/* INSERT QUERY NO: 604 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
604, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 969, 603
);

/* INSERT QUERY NO: 605 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
605, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 970, 604
);

/* INSERT QUERY NO: 606 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
606, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 971, 605
);

/* INSERT QUERY NO: 607 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
607, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 972, 606
);

/* INSERT QUERY NO: 608 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
608, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 973, 607
);

/* INSERT QUERY NO: 609 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
609, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 974, 608
);

/* INSERT QUERY NO: 610 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
610, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 975, 609
);

/* INSERT QUERY NO: 611 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
611, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 976, 610
);

/* INSERT QUERY NO: 612 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
612, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 977, 611
);

/* INSERT QUERY NO: 613 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
613, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 978, 612
);

/* INSERT QUERY NO: 614 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
614, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 979, 613
);

/* INSERT QUERY NO: 615 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
615, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 980, 614
);

/* INSERT QUERY NO: 616 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
616, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 981, 615
);

/* INSERT QUERY NO: 617 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
617, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 982, 616
);

/* INSERT QUERY NO: 618 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
618, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 983, 617
);

/* INSERT QUERY NO: 619 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
619, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 984, 618
);

/* INSERT QUERY NO: 620 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
620, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 985, 619
);

/* INSERT QUERY NO: 621 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
621, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 986, 620
);

/* INSERT QUERY NO: 622 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
622, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 987, 621
);

/* INSERT QUERY NO: 623 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
623, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 988, 622
);

/* INSERT QUERY NO: 624 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
624, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 989, 623
);

/* INSERT QUERY NO: 625 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
625, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 990, 624
);

/* INSERT QUERY NO: 626 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
626, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 991, 625
);

/* INSERT QUERY NO: 627 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
627, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 992, 626
);

/* INSERT QUERY NO: 628 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
628, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 993, 627
);

/* INSERT QUERY NO: 629 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
629, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 994, 628
);

/* INSERT QUERY NO: 630 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
630, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 995, 629
);

/* INSERT QUERY NO: 631 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
631, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 996, 630
);

/* INSERT QUERY NO: 632 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
632, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 997, 631
);

/* INSERT QUERY NO: 633 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
633, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 998, 632
);

/* INSERT QUERY NO: 634 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
634, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 999, 633
);

/* INSERT QUERY NO: 635 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
635, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1000, 634
);

/* INSERT QUERY NO: 636 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
636, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1001, 635
);

/* INSERT QUERY NO: 637 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
637, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1002, 636
);

/* INSERT QUERY NO: 638 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
638, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1003, 637
);

/* INSERT QUERY NO: 639 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
639, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1004, 638
);

/* INSERT QUERY NO: 640 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
640, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1005, 639
);

/* INSERT QUERY NO: 641 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
641, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1006, 640
);

/* INSERT QUERY NO: 642 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
642, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1007, 641
);

/* INSERT QUERY NO: 643 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
643, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1008, 642
);

/* INSERT QUERY NO: 644 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
644, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1009, 643
);

/* INSERT QUERY NO: 645 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
645, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1010, 644
);

/* INSERT QUERY NO: 646 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
646, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1011, 645
);

/* INSERT QUERY NO: 647 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
647, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1012, 646
);

/* INSERT QUERY NO: 648 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
648, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1013, 647
);

/* INSERT QUERY NO: 649 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
649, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1014, 648
);

/* INSERT QUERY NO: 650 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
650, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1015, 649
);

/* INSERT QUERY NO: 651 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
651, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1016, 650
);

/* INSERT QUERY NO: 652 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
652, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1017, 651
);

/* INSERT QUERY NO: 653 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
653, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1018, 652
);

/* INSERT QUERY NO: 654 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
654, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1019, 653
);

/* INSERT QUERY NO: 655 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
655, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1020, 654
);

/* INSERT QUERY NO: 656 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
656, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1021, 655
);

/* INSERT QUERY NO: 657 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
657, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1022, 656
);

/* INSERT QUERY NO: 658 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
658, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1023, 657
);

/* INSERT QUERY NO: 659 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
659, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1024, 658
);

/* INSERT QUERY NO: 660 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
660, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1025, 659
);

/* INSERT QUERY NO: 661 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
661, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1026, 660
);

/* INSERT QUERY NO: 662 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
662, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1027, 661
);

/* INSERT QUERY NO: 663 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
663, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1028, 662
);

/* INSERT QUERY NO: 664 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
664, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1029, 663
);

/* INSERT QUERY NO: 665 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
665, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1030, 664
);

/* INSERT QUERY NO: 666 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
666, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1031, 665
);

/* INSERT QUERY NO: 667 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
667, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1032, 666
);

/* INSERT QUERY NO: 668 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
668, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1033, 667
);

/* INSERT QUERY NO: 669 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
669, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1034, 668
);

/* INSERT QUERY NO: 670 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
670, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1035, 669
);

/* INSERT QUERY NO: 671 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
671, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1036, 670
);

/* INSERT QUERY NO: 672 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
672, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1037, 671
);

/* INSERT QUERY NO: 673 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
673, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1038, 672
);

/* INSERT QUERY NO: 674 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
674, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1039, 673
);

/* INSERT QUERY NO: 675 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
675, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1040, 674
);

/* INSERT QUERY NO: 676 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
676, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1041, 675
);

/* INSERT QUERY NO: 677 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
677, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1042, 676
);

/* INSERT QUERY NO: 678 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
678, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1043, 677
);

/* INSERT QUERY NO: 679 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
679, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1044, 678
);

/* INSERT QUERY NO: 680 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
680, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1045, 679
);

/* INSERT QUERY NO: 681 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
681, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1046, 680
);

/* INSERT QUERY NO: 682 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
682, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1047, 681
);

/* INSERT QUERY NO: 683 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
683, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1048, 682
);

/* INSERT QUERY NO: 684 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
684, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1049, 683
);

/* INSERT QUERY NO: 685 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
685, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1050, 684
);

/* INSERT QUERY NO: 686 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
686, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1051, 685
);

/* INSERT QUERY NO: 687 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
687, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1052, 686
);

/* INSERT QUERY NO: 688 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
688, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1053, 687
);

/* INSERT QUERY NO: 689 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
689, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1054, 688
);

/* INSERT QUERY NO: 690 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
690, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1055, 689
);

/* INSERT QUERY NO: 691 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
691, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1056, 690
);

/* INSERT QUERY NO: 692 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
692, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1057, 691
);

/* INSERT QUERY NO: 693 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
693, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1058, 692
);

/* INSERT QUERY NO: 694 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
694, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1059, 693
);

/* INSERT QUERY NO: 695 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
695, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1060, 694
);

/* INSERT QUERY NO: 696 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
696, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1061, 695
);

/* INSERT QUERY NO: 697 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
697, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1062, 696
);

/* INSERT QUERY NO: 698 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
698, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1063, 697
);

/* INSERT QUERY NO: 699 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
699, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1064, 698
);

/* INSERT QUERY NO: 700 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
700, TO_DATE('19/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1065, 699
);

/* INSERT QUERY NO: 701 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
701, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1066, 700
);

/* INSERT QUERY NO: 702 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
702, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1067, 701
);

/* INSERT QUERY NO: 703 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
703, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1068, 702
);

/* INSERT QUERY NO: 704 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
704, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1069, 703
);

/* INSERT QUERY NO: 705 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
705, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1070, 704
);

/* INSERT QUERY NO: 706 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
706, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1071, 705
);

/* INSERT QUERY NO: 707 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
707, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1072, 706
);

/* INSERT QUERY NO: 708 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
708, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1073, 707
);

/* INSERT QUERY NO: 709 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
709, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1074, 708
);

/* INSERT QUERY NO: 710 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
710, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1075, 709
);

/* INSERT QUERY NO: 711 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
711, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1076, 710
);

/* INSERT QUERY NO: 712 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
712, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1077, 711
);

/* INSERT QUERY NO: 713 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
713, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1078, 712
);

/* INSERT QUERY NO: 714 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
714, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1079, 713
);

/* INSERT QUERY NO: 715 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
715, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1080, 714
);

/* INSERT QUERY NO: 716 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
716, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1081, 715
);

/* INSERT QUERY NO: 717 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
717, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1082, 716
);

/* INSERT QUERY NO: 718 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
718, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1083, 717
);

/* INSERT QUERY NO: 719 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
719, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1084, 718
);

/* INSERT QUERY NO: 720 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
720, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1085, 719
);

/* INSERT QUERY NO: 721 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
721, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1086, 720
);

/* INSERT QUERY NO: 722 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
722, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1087, 721
);

/* INSERT QUERY NO: 723 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
723, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1088, 722
);

/* INSERT QUERY NO: 724 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
724, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1089, 723
);

/* INSERT QUERY NO: 725 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
725, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1090, 724
);

/* INSERT QUERY NO: 726 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
726, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1091, 725
);

/* INSERT QUERY NO: 727 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
727, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1092, 726
);

/* INSERT QUERY NO: 728 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
728, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1093, 727
);

/* INSERT QUERY NO: 729 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
729, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1094, 728
);

/* INSERT QUERY NO: 730 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
730, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1095, 729
);

/* INSERT QUERY NO: 731 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
731, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1096, 730
);

/* INSERT QUERY NO: 732 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
732, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1097, 731
);

/* INSERT QUERY NO: 733 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
733, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1098, 732
);

/* INSERT QUERY NO: 734 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
734, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1099, 733
);

/* INSERT QUERY NO: 735 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
735, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1100, 734
);

/* INSERT QUERY NO: 736 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
736, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1101, 735
);

/* INSERT QUERY NO: 737 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
737, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1102, 736
);

/* INSERT QUERY NO: 738 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
738, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1103, 737
);

/* INSERT QUERY NO: 739 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
739, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1104, 738
);

/* INSERT QUERY NO: 740 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
740, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1105, 739
);

/* INSERT QUERY NO: 741 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
741, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1106, 740
);

/* INSERT QUERY NO: 742 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
742, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1107, 741
);

/* INSERT QUERY NO: 743 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
743, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1108, 742
);

/* INSERT QUERY NO: 744 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
744, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1109, 743
);

/* INSERT QUERY NO: 745 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
745, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1110, 744
);

/* INSERT QUERY NO: 746 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
746, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1111, 745
);

/* INSERT QUERY NO: 747 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
747, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1112, 746
);

/* INSERT QUERY NO: 748 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
748, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1113, 747
);

/* INSERT QUERY NO: 749 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
749, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1114, 748
);

/* INSERT QUERY NO: 750 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
750, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1115, 749
);

/* INSERT QUERY NO: 751 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
751, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1116, 750
);

/* INSERT QUERY NO: 752 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
752, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1117, 751
);

/* INSERT QUERY NO: 753 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
753, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1118, 752
);

/* INSERT QUERY NO: 754 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
754, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1119, 753
);

/* INSERT QUERY NO: 755 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
755, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1120, 754
);

/* INSERT QUERY NO: 756 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
756, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1121, 755
);

/* INSERT QUERY NO: 757 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
757, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1122, 756
);

/* INSERT QUERY NO: 758 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
758, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1123, 757
);

/* INSERT QUERY NO: 759 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
759, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1124, 758
);

/* INSERT QUERY NO: 760 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
760, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1125, 759
);

/* INSERT QUERY NO: 761 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
761, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1126, 760
);

/* INSERT QUERY NO: 762 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
762, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1127, 761
);

/* INSERT QUERY NO: 763 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
763, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1128, 762
);

/* INSERT QUERY NO: 764 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
764, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1129, 763
);

/* INSERT QUERY NO: 765 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
765, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1130, 764
);

/* INSERT QUERY NO: 766 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
766, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1131, 765
);

/* INSERT QUERY NO: 767 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
767, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1132, 766
);

/* INSERT QUERY NO: 768 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
768, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1133, 767
);

/* INSERT QUERY NO: 769 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
769, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1134, 768
);

/* INSERT QUERY NO: 770 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
770, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1135, 769
);

/* INSERT QUERY NO: 771 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
771, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1136, 770
);

/* INSERT QUERY NO: 772 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
772, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1137, 771
);

/* INSERT QUERY NO: 773 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
773, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1138, 772
);

/* INSERT QUERY NO: 774 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
774, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1139, 773
);

/* INSERT QUERY NO: 775 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
775, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1140, 774
);

/* INSERT QUERY NO: 776 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
776, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1141, 775
);

/* INSERT QUERY NO: 777 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
777, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1142, 776
);

/* INSERT QUERY NO: 778 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
778, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1143, 777
);

/* INSERT QUERY NO: 779 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
779, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1144, 778
);

/* INSERT QUERY NO: 780 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
780, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1145, 779
);

/* INSERT QUERY NO: 781 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
781, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1146, 780
);

/* INSERT QUERY NO: 782 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
782, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1147, 781
);

/* INSERT QUERY NO: 783 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
783, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1148, 782
);

/* INSERT QUERY NO: 784 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
784, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1149, 783
);

/* INSERT QUERY NO: 785 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
785, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1150, 784
);

/* INSERT QUERY NO: 786 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
786, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1151, 785
);

/* INSERT QUERY NO: 787 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
787, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1152, 786
);

/* INSERT QUERY NO: 788 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
788, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1153, 787
);

/* INSERT QUERY NO: 789 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
789, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1154, 788
);

/* INSERT QUERY NO: 790 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
790, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1155, 789
);

/* INSERT QUERY NO: 791 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
791, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1156, 790
);

/* INSERT QUERY NO: 792 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
792, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1157, 791
);

/* INSERT QUERY NO: 793 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
793, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1158, 792
);

/* INSERT QUERY NO: 794 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
794, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1159, 793
);

/* INSERT QUERY NO: 795 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
795, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1160, 794
);

/* INSERT QUERY NO: 796 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
796, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1161, 795
);

/* INSERT QUERY NO: 797 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
797, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1162, 796
);

/* INSERT QUERY NO: 798 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
798, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1163, 797
);

/* INSERT QUERY NO: 799 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
799, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1164, 798
);

/* INSERT QUERY NO: 800 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
800, TO_DATE('20/11/2015','DD/MM/YYYY'), TO_DATE('16/11/2018','DD/MM/YYYY'), 1165, 799
);

/* INSERT QUERY NO: 801 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
801, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1166, 800
);

/* INSERT QUERY NO: 802 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
802, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1167, 801
);

/* INSERT QUERY NO: 803 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
803, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1168, 802
);

/* INSERT QUERY NO: 804 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
804, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1169, 803
);

/* INSERT QUERY NO: 805 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
805, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1170, 804
);

/* INSERT QUERY NO: 806 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
806, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1171, 805
);

/* INSERT QUERY NO: 807 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
807, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1172, 806
);

/* INSERT QUERY NO: 808 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
808, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1173, 807
);

/* INSERT QUERY NO: 809 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
809, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1174, 808
);

/* INSERT QUERY NO: 810 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
810, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1175, 809
);

/* INSERT QUERY NO: 811 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
811, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1176, 810
);

/* INSERT QUERY NO: 812 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
812, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1177, 811
);

/* INSERT QUERY NO: 813 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
813, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1178, 812
);

/* INSERT QUERY NO: 814 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
814, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1179, 813
);

/* INSERT QUERY NO: 815 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
815, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1180, 814
);

/* INSERT QUERY NO: 816 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
816, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1181, 815
);

/* INSERT QUERY NO: 817 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
817, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1182, 816
);

/* INSERT QUERY NO: 818 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
818, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1183, 817
);

/* INSERT QUERY NO: 819 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
819, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1184, 818
);

/* INSERT QUERY NO: 820 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
820, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1185, 819
);

/* INSERT QUERY NO: 821 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
821, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1186, 820
);

/* INSERT QUERY NO: 822 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
822, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1187, 821
);

/* INSERT QUERY NO: 823 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
823, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1188, 822
);

/* INSERT QUERY NO: 824 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
824, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1189, 823
);

/* INSERT QUERY NO: 825 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
825, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1190, 824
);

/* INSERT QUERY NO: 826 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
826, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1191, 825
);

/* INSERT QUERY NO: 827 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
827, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1192, 826
);

/* INSERT QUERY NO: 828 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
828, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1193, 827
);

/* INSERT QUERY NO: 829 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
829, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1194, 828
);

/* INSERT QUERY NO: 830 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
830, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1195, 829
);

/* INSERT QUERY NO: 831 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
831, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1196, 830
);

/* INSERT QUERY NO: 832 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
832, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1197, 831
);

/* INSERT QUERY NO: 833 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
833, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1198, 832
);

/* INSERT QUERY NO: 834 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
834, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1199, 833
);

/* INSERT QUERY NO: 835 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
835, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1200, 834
);

/* INSERT QUERY NO: 836 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
836, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1201, 835
);

/* INSERT QUERY NO: 837 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
837, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1202, 836
);

/* INSERT QUERY NO: 838 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
838, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1203, 837
);

/* INSERT QUERY NO: 839 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
839, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1204, 838
);

/* INSERT QUERY NO: 840 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
840, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1205, 839
);

/* INSERT QUERY NO: 841 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
841, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1206, 840
);

/* INSERT QUERY NO: 842 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
842, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1207, 841
);

/* INSERT QUERY NO: 843 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
843, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1208, 842
);

/* INSERT QUERY NO: 844 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
844, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1209, 843
);

/* INSERT QUERY NO: 845 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
845, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1210, 844
);

/* INSERT QUERY NO: 846 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
846, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1211, 845
);

/* INSERT QUERY NO: 847 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
847, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1212, 846
);

/* INSERT QUERY NO: 848 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
848, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1213, 847
);

/* INSERT QUERY NO: 849 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
849, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1214, 848
);

/* INSERT QUERY NO: 850 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
850, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1215, 849
);

/* INSERT QUERY NO: 851 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
851, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1216, 850
);

/* INSERT QUERY NO: 852 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
852, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1217, 851
);

/* INSERT QUERY NO: 853 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
853, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1218, 852
);

/* INSERT QUERY NO: 854 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
854, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1219, 853
);

/* INSERT QUERY NO: 855 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
855, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1220, 854
);

/* INSERT QUERY NO: 856 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
856, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1221, 855
);

/* INSERT QUERY NO: 857 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
857, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1222, 856
);

/* INSERT QUERY NO: 858 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
858, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1223, 857
);

/* INSERT QUERY NO: 859 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
859, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1224, 858
);

/* INSERT QUERY NO: 860 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
860, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1225, 859
);

/* INSERT QUERY NO: 861 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
861, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1226, 860
);

/* INSERT QUERY NO: 862 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
862, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1227, 861
);

/* INSERT QUERY NO: 863 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
863, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1228, 862
);

/* INSERT QUERY NO: 864 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
864, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1229, 863
);

/* INSERT QUERY NO: 865 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
865, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1230, 864
);

/* INSERT QUERY NO: 866 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
866, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1231, 865
);

/* INSERT QUERY NO: 867 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
867, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1232, 866
);

/* INSERT QUERY NO: 868 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
868, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1233, 867
);

/* INSERT QUERY NO: 869 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
869, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1234, 868
);

/* INSERT QUERY NO: 870 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
870, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1235, 869
);

/* INSERT QUERY NO: 871 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
871, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1236, 870
);

/* INSERT QUERY NO: 872 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
872, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1237, 871
);

/* INSERT QUERY NO: 873 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
873, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1238, 872
);

/* INSERT QUERY NO: 874 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
874, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1239, 873
);

/* INSERT QUERY NO: 875 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
875, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1240, 874
);

/* INSERT QUERY NO: 876 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
876, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1241, 875
);

/* INSERT QUERY NO: 877 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
877, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1242, 876
);

/* INSERT QUERY NO: 878 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
878, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1243, 877
);

/* INSERT QUERY NO: 879 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
879, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1244, 878
);

/* INSERT QUERY NO: 880 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
880, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1245, 879
);

/* INSERT QUERY NO: 881 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
881, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1246, 880
);

/* INSERT QUERY NO: 882 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
882, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1247, 881
);

/* INSERT QUERY NO: 883 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
883, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1248, 882
);

/* INSERT QUERY NO: 884 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
884, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1249, 883
);

/* INSERT QUERY NO: 885 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
885, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1250, 884
);

/* INSERT QUERY NO: 886 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
886, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1251, 885
);

/* INSERT QUERY NO: 887 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
887, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1252, 886
);

/* INSERT QUERY NO: 888 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
888, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1253, 887
);

/* INSERT QUERY NO: 889 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
889, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1254, 888
);

/* INSERT QUERY NO: 890 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
890, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1255, 889
);

/* INSERT QUERY NO: 891 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
891, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1256, 890
);

/* INSERT QUERY NO: 892 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
892, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1257, 891
);

/* INSERT QUERY NO: 893 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
893, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1258, 892
);

/* INSERT QUERY NO: 894 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
894, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1259, 893
);

/* INSERT QUERY NO: 895 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
895, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1260, 894
);

/* INSERT QUERY NO: 896 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
896, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1261, 895
);

/* INSERT QUERY NO: 897 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
897, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1262, 896
);

/* INSERT QUERY NO: 898 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
898, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1263, 897
);

/* INSERT QUERY NO: 899 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
899, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1264, 898
);

/* INSERT QUERY NO: 900 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
900, TO_DATE('21/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1265, 899
);

/* INSERT QUERY NO: 901 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
901, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1266, 900
);

/* INSERT QUERY NO: 902 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
902, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1267, 901
);

/* INSERT QUERY NO: 903 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
903, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1268, 902
);

/* INSERT QUERY NO: 904 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
904, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1269, 903
);

/* INSERT QUERY NO: 905 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
905, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1270, 904
);

/* INSERT QUERY NO: 906 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
906, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1271, 905
);

/* INSERT QUERY NO: 907 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
907, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1272, 906
);

/* INSERT QUERY NO: 908 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
908, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1273, 907
);

/* INSERT QUERY NO: 909 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
909, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1274, 908
);

/* INSERT QUERY NO: 910 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
910, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1275, 909
);

/* INSERT QUERY NO: 911 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
911, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1276, 910
);

/* INSERT QUERY NO: 912 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
912, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1277, 911
);

/* INSERT QUERY NO: 913 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
913, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1278, 912
);

/* INSERT QUERY NO: 914 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
914, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1279, 913
);

/* INSERT QUERY NO: 915 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
915, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1280, 914
);

/* INSERT QUERY NO: 916 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
916, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1281, 915
);

/* INSERT QUERY NO: 917 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
917, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1282, 916
);

/* INSERT QUERY NO: 918 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
918, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1283, 917
);

/* INSERT QUERY NO: 919 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
919, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1284, 918
);

/* INSERT QUERY NO: 920 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
920, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1285, 919
);

/* INSERT QUERY NO: 921 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
921, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1286, 920
);

/* INSERT QUERY NO: 922 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
922, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1287, 921
);

/* INSERT QUERY NO: 923 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
923, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1288, 922
);

/* INSERT QUERY NO: 924 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
924, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1289, 923
);

/* INSERT QUERY NO: 925 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
925, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1290, 924
);

/* INSERT QUERY NO: 926 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
926, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1291, 925
);

/* INSERT QUERY NO: 927 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
927, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1292, 926
);

/* INSERT QUERY NO: 928 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
928, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1293, 927
);

/* INSERT QUERY NO: 929 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
929, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1294, 928
);

/* INSERT QUERY NO: 930 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
930, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1295, 929
);

/* INSERT QUERY NO: 931 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
931, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1296, 930
);

/* INSERT QUERY NO: 932 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
932, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1297, 931
);

/* INSERT QUERY NO: 933 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
933, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1298, 932
);

/* INSERT QUERY NO: 934 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
934, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1299, 933
);

/* INSERT QUERY NO: 935 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
935, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1300, 934
);

/* INSERT QUERY NO: 936 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
936, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1301, 935
);

/* INSERT QUERY NO: 937 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
937, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1302, 936
);

/* INSERT QUERY NO: 938 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
938, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1303, 937
);

/* INSERT QUERY NO: 939 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
939, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1304, 938
);

/* INSERT QUERY NO: 940 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
940, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1305, 939
);

/* INSERT QUERY NO: 941 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
941, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1306, 940
);

/* INSERT QUERY NO: 942 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
942, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1307, 941
);

/* INSERT QUERY NO: 943 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
943, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1308, 942
);

/* INSERT QUERY NO: 944 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
944, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1309, 943
);

/* INSERT QUERY NO: 945 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
945, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1310, 944
);

/* INSERT QUERY NO: 946 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
946, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1311, 945
);

/* INSERT QUERY NO: 947 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
947, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1312, 946
);

/* INSERT QUERY NO: 948 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
948, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1313, 947
);

/* INSERT QUERY NO: 949 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
949, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1314, 948
);

/* INSERT QUERY NO: 950 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
950, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1315, 949
);

/* INSERT QUERY NO: 951 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
951, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1316, 950
);

/* INSERT QUERY NO: 952 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
952, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1317, 951
);

/* INSERT QUERY NO: 953 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
953, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1318, 952
);

/* INSERT QUERY NO: 954 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
954, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1319, 953
);

/* INSERT QUERY NO: 955 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
955, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1320, 954
);

/* INSERT QUERY NO: 956 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
956, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1321, 955
);

/* INSERT QUERY NO: 957 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
957, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1322, 956
);

/* INSERT QUERY NO: 958 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
958, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1323, 957
);

/* INSERT QUERY NO: 959 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
959, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1324, 958
);

/* INSERT QUERY NO: 960 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
960, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1325, 959
);

/* INSERT QUERY NO: 961 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
961, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1326, 960
);

/* INSERT QUERY NO: 962 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
962, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1327, 961
);

/* INSERT QUERY NO: 963 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
963, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1328, 962
);

/* INSERT QUERY NO: 964 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
964, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1329, 963
);

/* INSERT QUERY NO: 965 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
965, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1330, 964
);

/* INSERT QUERY NO: 966 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
966, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1331, 965
);

/* INSERT QUERY NO: 967 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
967, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1332, 966
);

/* INSERT QUERY NO: 968 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
968, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1333, 967
);

/* INSERT QUERY NO: 969 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
969, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1334, 968
);

/* INSERT QUERY NO: 970 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
970, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1335, 969
);

/* INSERT QUERY NO: 971 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
971, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1336, 970
);

/* INSERT QUERY NO: 972 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
972, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1337, 971
);

/* INSERT QUERY NO: 973 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
973, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1338, 972
);

/* INSERT QUERY NO: 974 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
974, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1339, 973
);

/* INSERT QUERY NO: 975 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
975, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1340, 974
);

/* INSERT QUERY NO: 976 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
976, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1341, 975
);

/* INSERT QUERY NO: 977 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
977, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1342, 976
);

/* INSERT QUERY NO: 978 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
978, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1343, 977
);

/* INSERT QUERY NO: 979 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
979, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1344, 978
);

/* INSERT QUERY NO: 980 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
980, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1345, 979
);

/* INSERT QUERY NO: 981 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
981, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1346, 980
);

/* INSERT QUERY NO: 982 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
982, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1347, 981
);

/* INSERT QUERY NO: 983 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
983, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1348, 982
);

/* INSERT QUERY NO: 984 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
984, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1349, 983
);

/* INSERT QUERY NO: 985 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
985, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1350, 984
);

/* INSERT QUERY NO: 986 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
986, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1351, 985
);

/* INSERT QUERY NO: 987 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
987, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1352, 986
);

/* INSERT QUERY NO: 988 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
988, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1353, 987
);

/* INSERT QUERY NO: 989 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
989, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1354, 988
);

/* INSERT QUERY NO: 990 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
990, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1355, 989
);

/* INSERT QUERY NO: 991 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
991, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1356, 990
);

/* INSERT QUERY NO: 992 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
992, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1357, 991
);

/* INSERT QUERY NO: 993 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
993, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1358, 992
);

/* INSERT QUERY NO: 994 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
994, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1359, 993
);

/* INSERT QUERY NO: 995 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
995, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1360, 994
);

/* INSERT QUERY NO: 996 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
996, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1361, 995
);

/* INSERT QUERY NO: 997 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
997, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1362, 996
);

/* INSERT QUERY NO: 998 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
998, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1363, 997
);

/* INSERT QUERY NO: 999 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
999, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1364, 998
);

/* INSERT QUERY NO: 1000 */
INSERT INTO Polizas(NoPoliza, InicioPoliza, FinPoliza, NoMotor, NoAccidente)
VALUES
(
1000, TO_DATE('22/11/2015','DD/MM/YYYY'), TO_DATE('17/11/2018','DD/MM/YYYY'), 1365, 999
);


