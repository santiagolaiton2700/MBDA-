--------------------------------------TUPLA NO OK-----------------------------------
INSERT INTO POLIZAS(NoPoliza,InicioPoliza,FinPoliza,NoMotor,NoAccidente) VALUES(100,TO_DATE('DD/MM/YYYY','27/02/2000'),TO_DATE('DD/MM/YYYY','27/02/1900'),4853,474739);
INSERT INTO LoteProducciones(CodigoInicio, CodigoFin, InicioLote, FinLote, Descripcion) VALUES (838, 838838, TO_DATE('4/2/2000','DD/MM/YYYY'), TO_DATE('4/2/2001','DD/MM/YYYY'), 'Sedan');
INSERT INTO Conductores(Cedula, Nombre, Apellido, TiLicencia, NoLicencia, Rh, FechaNacimiento, LugarNacimiento, Correo, Telefono, Pasivo, Activo)VALUES(52505619, 'Noelani', 'Yeatman', 'C2', 'N11149', 'AB+', TO_DATE('4/5/1989','DD/MM/YYYY'), 'CALI', 'CORREO1149@gmail.com', 4036670123, -11122, -21121);
