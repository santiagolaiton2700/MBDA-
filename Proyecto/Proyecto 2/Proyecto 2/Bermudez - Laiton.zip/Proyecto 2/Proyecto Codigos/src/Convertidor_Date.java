import java.util.*;
public class Convertidor_Date {

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		while (scan.hasNextLine()) {
			   String line = scan.nextLine();
	    System.out.println(line);
			}
		
	}
}
