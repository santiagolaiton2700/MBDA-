-------------------------REGISTRAR VERSION------------------------------------------------------------------------------------
-------------------------El nombre de la version no se debe repetir.---------------------------
CREATE OR REPLACE TRIGGER TR_NOMBRE_VERSION
BEFORE INSERT
ON VERSION
FOR EACH ROW 
DECLARE 
x NUMBER;
BEGIN
SELECT COUNT(NOMBRE) INTO x FROM VERSION WHERE NOMBRE=:NEW.NOMBRE;
IF (x>=1) THEN 
RAISE_APPLICATION_ERROR(-20009,'Este nombre ya esta asignado');
END IF;
END;
/
------------------El unico dato que se puede modificar es la fecha--------------------
CREATE OR REPLACE TRIGGER TR_VERSION_FECHA
BEFORE UPDATE OF NOMBRE,NOMBRESEGMENTO,ID_MIEMBRO
ON VERSION
FOR EACH ROW
BEGIN 
RAISE_APPLICATION_ERROR(-20010,'Este valor no se puede modificar');
END;
/
------------------La version no se puede eliminar----------------------------
CREATE OR REPLACE TRIGGER TR_ELIMINAR_VERSION
BEFORE DELETE
ON VERSION
FOR EACH ROW
BEGIN 
RAISE_APPLICATION_ERROR(-20011,'La version no se puede eliminar');
END;
/
--------------------El nombre del segmento no se puede modificar---------------------------
CREATE OR REPLACE TRIGGER TR_MOD_SEGMENTO
BEFORE UPDATE OF TIPO,NUMEROREGISTRO
ON SEGMENTO
FOR EACH ROW
BEGIN 
RAISE_APPLICATION_ERROR(-20013,'El nombre del segmento no se puede modificar');
END;
/
--------------------El segmento no se puede eliminar---------------------------------------
CREATE OR REPLACE TRIGGER TR_ELIMINAR_SEGMENTO
BEFORE DELETE
ON SEGMENTO
FOR EACH ROW
BEGIN 
RAISE_APPLICATION_ERROR(-20012,'El segmento no se puede eliminar');
END;
/

