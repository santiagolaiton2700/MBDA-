-----------------------------------Mantener Carrera---------------------------------------------------------------------------
-----------------------------------El nombre del punto no se debe repetir dentro de una carrera---------------------------
CREATE OR REPLACE TRIGGER TR_PUNTO_CARRERA 
BEFORE INSERT 
ON PUNTO 
FOR EACH ROW
DECLARE
x NUMBER;
BEGIN
SELECT COUNT(orden) INTO x FROM PUNTO JOIN CARRERA ON (PUNTO.CODIGOCA=CARRERA.CODIGO) WHERE PUNTO.NOMBRE=:NEW.NOMBRE;
IF x>=1 THEN 
RAISE_APPLICATION_ERROR(-20007,'Este nombre ya fue asignado a el punto');
END IF;
END;
/
-----------------------------------Los puntos no se pueden eliminar-----------------------------------------
CREATE OR REPLACE TRIGGER TR_PUNTO_NO_ELIMINAR
BEFORE DELETE
ON PUNTO
FOR EACH ROW
BEGIN
RAISE_APPLICATION_ERROR(-20003,'No se puede eliminar el punto');
END;
/
----------------------------------El orden se debe generar autom�ticamente 1�--------------------------------
CREATE OR REPLACE TRIGGER TR_ORDEN_PUNTO 
BEFORE INSERT 
ON PUNTO 
FOR EACH ROW
DECLARE
x NUMBER;
BEGIN
SELECT COUNT(ORDEN)+1 INTO x FROM PUNTO;
:NEW.ORDEN:= x;
END;
/
-------------------------S�lo debe existir un punto de partida y un punto de llegada Si no se dice el tipo del punto se asume que es meta volante a no ser que sea el primer punto que es el de partida-----------------------
CREATE OR REPLACE TRIGGER TR_PUNTO_INIFIN
BEFORE INSERT
ON Punto
FOR EACH ROW
DECLARE
x NUMBER;
y NUMBER;
z VARCHAR(1);
BEGIN
SELECT COUNT(TIPO)INTO x FROM PUNTO JOIN CARRERA ON(CARRERA.CODIGO=PUNTO.CODIGOCA) WHERE PUNTO.TIPO='P';
SELECT COUNT(TIPO)INTO y FROM PUNTO JOIN CARRERA ON(CARRERA.CODIGO=PUNTO.CODIGOCA) WHERE PUNTO.TIPO='L';
IF (x>1 OR y>1)THEN
RAISE_APPLICATION_ERROR(-20004,'Esta carrera tiene un punto de partida o de llegada');
SELECT TIPO INTO z FROM PUNTO JOIN CARRERA ON(CARRERA.CODIGO=PUNTO.CODIGOCA) WHERE PUNTO.TIPO='P';
ELSE IF(:New.tipo='' and z!='P' )then
:NEW.Tipo:='M';

END IF;
END IF;
END;
/
-------------------------Si no se conoce la duraci�n m�xima se asume una velocidad de 60 km/hora----------------------
CREATE OR REPLACE TRIGGER TR_TIEMPOLIITE
BEFORE INSERT
ON PUNTO
FOR EACH ROW
BEGIN
IF (:NEW.TIEMPOLIMITE ='')THEN
:NEW.TIEMPOLIMITE:=60;
END IF;
END;
/
----------------------------Los �nicos datos que se pueden modificar son el tipo y la duraci�n.-----------------------
CREATE OR REPLACE TRIGGER TR_MODI_TIPO_DURACION
BEFORE UPDATE OF ORDEN,NOMBRE,DISTANCIA,CODIGOCA,NOMBRESEGMENTO
ON PUNTO
FOR EACH ROW
BEGIN
RAISE_APPLICATION_ERROR(-20005,'solo se puede modificar el tipo y la duracion');
END;
/
--------------------------------No se puede modificar el tipo de partida----------------------------
CREATE OR REPLACE TRIGGER TR_MODIFICAR_TIPO_PARTIDA
BEFORE UPDATE OF TIPO
ON PUNTO
FOR EACH ROW 
BEGIN
RAISE_APPLICATION_ERROR(-20006,'No se puede actualizar el punto');
END;
/


