-----------------MIEMBRO------------------------------------------------------
INSERT INTO MIEMBRO(ID,IDT,IDN,PAIS,CORREO)VALUES(788,'CC',100116936444444,'COLOMBIA','SAAGULAICU@HOTMAIL.COM');
------------------PERSONA----------------------------------------------------
INSERT INTO PERSONA(NOMBRE,IDMIEMBRO,RAZONSOCIAL)VALUES('SANTIAGO LAITON',788,'COLPATRIA');
----------------EMPRESA-------------------------------------------------------
INSERT INTO EMPRESA(RAZONSOCIAL,IDMIEMBRO)VALUES('COMSILAS.A.S',788);
------------------REGISTRO----------------------------------------------------
INSERT INTO REGISTRO (NUMERO,FECHA,TIEMPO,POSICION,REVISION,DIFICULTAD,FOTO,COMENTARIO) VALUES (200,TO_DATE('2017-05-14','YYYY-MM-DD'),207777777,1,'BIEN','A','www.MONTAÑA.PDF','NO HUBO ACCIDENTES');
------------------CICLISTA---------------------------------------------------
INSERT INTO CICLISTA(NACIMIENTO,CATEGORIA,IDMIEMBRO,NUMEROREGISTRO)VALUES(TO_DATE('27/02/2000','DD/MM/YYYY'),5,788,200);
------------------SEGMENTO----------------------------------------------------
INSERT INTO SEGMENTO (NOMBRE,TIPO,NUMEROREGISTRO)VALUES('ETAPA 1','M',200);
------------------FOTOS-----------------------------------------------------
INSERT INTO FOTO (NUMEROREGISTRO,FOTO) VALUES (200,'www.MONTANA.PDF');
------------------VERSION----------------------------------------------------
INSERT INTO VERSION (NOMBRE,FECHA,NOMBRESEGMENTO,ID_MIEMBRO)VALUES('201CO',TO_DATE('2012-06-24','YYYY-MM-DD'),'ETAPA 1',788);
--------------------PARTICIPA----------------------------------------------
INSERT INTO PARTICIPA(IDMIEMBRO,NOMBREVERSION)VALUES(788,'201CO');
------------------ORGANIZADO------------------------------------------------
INSERT INTO ORGANIZADO (RAZONSOCIAL,NOMBREVERSION)VALUES('COMSILAS.A.S','201CO');
--------------------CARRERA--------------------------------------------------
INSERT INTO CARRERA(CODIGO,NOMBRE,PAIS,CATEGORIA,PERIODICIDAD,NOMBREVERSION)VALUES('123ABBBBBBBBBBBBBBBB','TOUR F','FRANCIA',2,'ANUAL', '201CO');
-------------------PUNTO-----------------------------------------------------
INSERT INTO PUNTO (ORDEN,NOMBRE,TIPO,DISTANCIA,TIEMPOLIMITE,CODIGOCA,NOMBRESEGMENTO)VALUES(10,'PUNTO 3','P',15,125,'123ABBBBBBBBBBBBBBBB','ETAPA 1' );