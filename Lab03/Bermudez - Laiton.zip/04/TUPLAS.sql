---------------------------------TUPLAS-------------------------------------------
-------------La distancia siempre debe ser mayor a 1 km y La velocidad m�xima en cicla es de 100 km/hora -------------------------------------------
ALTER TABLE PUNTO ADD CONSTRAINT TU_DISTANCIA_VELOCIDAD CHECK (DISTANCIA>1 AND DISTANCIA/TIEMPOLIMITE<=100);


ALTER TABLE PUNTO DROP CONSTRAINT TU_DISTANCIA_VELOCIDAD;