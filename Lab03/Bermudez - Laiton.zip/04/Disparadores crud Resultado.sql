------------------- REGISTRAR-RESULTADO------------------------------------
----El n�mero-- ----y la fecha se asignan autom�ticamente------
CREATE OR REPLACE TRIGGER TR_CODIGO_RESULTADO 
BEFORE INSERT
ON REGISTRO 
FOR EACH ROW 
DECLARE
x number;
BEGIN 
SELECT COUNT(NUMERO)+1 INTO x FROM REGISTRO;
:NEW.NUMERO:= x;
END;
/
 ---- La fecha se asignan autom�ticamente------
CREATE OR REPLACE TRIGGER TR_FECHA_REGISTRO
BEFORE INSERT
ON REGISTRO
FOR EACH ROW
DECLARE 
x NUMBER;
BEGIN
x:= ROUND(TO_NUMBER(SYSDATE -:NEW.FECHA));
END;
/

CREATE OR REPLACE TRIGGER TR_TRIGGER_REVISION
BEFORE UPDATE OF NUMERO,FECHA,TIEMPO,POSICION,DIFICULTAD
ON REGISTRO 
FOR EACH ROW 
BEGIN 
RAISE_APPLICATION_ERROR(-2000,'NO SE PUEDE ACTUALIZAR EL NUMERO');
END;
/ 

CREATE OR REPLACE TRIGGER TR_TRIGGER_ELIMINAR_REGISTRO
BEFORE DELETE
ON REGISTRO
FOR EACH ROW 
DECLARE
x date;
fechat date;
BEGIN
x:=sysdate;
SELECT(fecha) into fechat FROM registro where numero=:new.numero;
IF (x-fechat>1) then
RAISE_APPLICATION_ERROR(-20001,'No se puede eliminar');
END IF;
END;
/

--------------------No pueden quedar dos ciclistas con la misma posici�n------
CREATE OR REPLACE Trigger TR_ciclista_posicion
BEFORE INSERT 
ON REGISTRO 
FOR EACH ROW
DECLARE
x INTEGER;
BEGIN
SELECT count(POSICION)into x FROM REGISTRO JOIN CICLISTA ON (REGISTRO.NUMERO=CICLISTA.NUMEROREGISTRO)where numero=:new.numero;
IF(x>=1)then
RAISE_APPLICATION_ERROR(-20002,'No se puede insertar porque ya la posicion esta asignada');
END IF;
END;
/

----------Solo se pueden registrar resultados de ciclistas que hayan participado en la version de la carrera a la que pertenece el segmento.--------------


----------Un ciclista solo puede tener un �nico registro en un segmento--------------------------------------------------
CREATE OR REPLACE TRIGGER TR_REGISTRO_CICLISTA
BEFORE INSERT 
ON REGISTRO
FOR EACH ROW
DECLARE
x INTEGER;
BEGIN 
SELECT COUNT(NUMERO) INTO x FROM REGISTRO JOIN CICLISTA ON (NUMERO=CICLISTA.NUMEROREGISTRO) JOIN SEGMENTO ON (NUMERO=segmento.numeroregistro) WHERE registro.NUMERO=ciclista.numeroregistro and registro.NUMERO=segmento.numeroregistro;
IF (x>=1) THEN 
RAISE_APPLICATION_ERROR(-20008,'No se puede insertar porque ya existe un registro del cilcista en segmento');
END IF;
END;
/